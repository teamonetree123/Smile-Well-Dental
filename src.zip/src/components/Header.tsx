import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Menu, X, Phone, MapPin, ChevronDown } from 'lucide-react';
import { Navigation } from './Navigation';
import { motion, AnimatePresence } from 'motion/react';
import logoImage from 'figma:asset/6f69479a68522ff44e828094ccbb3fdc86e5a46c.png';

interface HeaderProps {
  onNavigateToHome?: () => void;
  onNavigateToServices?: () => void;
  onNavigateToAbout?: () => void;
  onNavigateToLocation?: () => void;
  onNavigateToSpecificLocation?: (locationId: string) => void;
}

export function Header({ onNavigateToHome, onNavigateToServices, onNavigateToAbout, onNavigateToLocation, onNavigateToSpecificLocation }: HeaderProps = {}) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isServicesHovered, setIsServicesHovered] = useState(false);
  const [isLocationsHovered, setIsLocationsHovered] = useState(false);

  const locations = [
    {
      id: 'north-vancouver',
      name: 'North Vancouver',
      phone: '(778) 340-2897',
      address: 'Suite #202, 814 15th St West'
    },
    {
      id: 'surrey',
      name: 'Surrey', 
      phone: '(778) 877-3493',
      address: '15243 91 Ave #2'
    },
    {
      id: 'langley',
      name: 'Langley',
      phone: '(604) 546-2828', 
      address: 'A125 & A130 20487 65 Ave'
    }
  ];

  const dentalServices = [
    'General Dentistry',
    'Orthodontics',
    'Endodontics',
    'Periodontics',
    'Dental Implants',
    'Sedation Dentistry',
    'Preventive Dentistry',
    'Restorative Dentistry',
    'Cosmetic Dentistry',
    'Emergency Dentistry'
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-white'
      }`}
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      {/* Top Bar */}
      <motion.div 
        className="bg-primary text-white py-2 text-sm"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <motion.div 
              className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-6"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              {/* Mobile: Show stacked phone numbers */}
              <div className="sm:hidden space-y-1">
                <div className="flex items-center gap-1">
                  <Phone className="h-3 w-3" />
                  <span className="text-xs">North Vancouver: 778-340-2897</span>
                </div>
                <div className="flex items-center gap-1 ml-4">
                  <span className="text-xs">Surrey: 778-877-3493</span>
                </div>
                <div className="flex items-center gap-1 ml-4">
                  <span className="text-xs">Langley: 604-546-2828</span>
                </div>
              </div>
              
              {/* Desktop: Show horizontal layout */}
              <div className="hidden sm:flex items-center gap-4 text-xs">
                <div className="flex items-center gap-1">
                  <Phone className="h-3 w-3" />
                  <span>North Vancouver: 778-340-2897</span>
                </div>
                <div className="flex items-center gap-1">
                  <span>Surrey: 778-877-3493</span>
                </div>
                <div className="flex items-center gap-1">
                  <span>Langley: 604-546-2828</span>
                </div>
              </div>
            </motion.div>
            <motion.div 
              className="text-xs sm:text-sm"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <span className="hidden sm:inline">CDCP Supported • </span>
              <span>Evening & Weekend Hours Available</span>
            </motion.div>
          </div>
        </div>
      </motion.div>

      {/* Main Header */}
      <motion.div 
        className="bg-white border-b border-gray-100"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            {/* Left Navigation */}
            <motion.nav 
              className="hidden lg:flex items-center space-x-8 flex-1 justify-end"
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.5 }}
            >
              <button onClick={onNavigateToHome} className="text-gray-700 hover:text-primary transition-colors font-body">Home</button>
              <button onClick={onNavigateToAbout} className="text-gray-700 hover:text-primary transition-colors font-body">About</button>
              <div 
                className="relative"
                onMouseEnter={() => setIsServicesHovered(true)}
                onMouseLeave={() => setIsServicesHovered(false)}
              >
                <button 
                  className="flex items-center space-x-1 text-gray-700 hover:text-primary transition-colors focus:outline-none font-body"
                  onClick={onNavigateToServices}
                >
                  <span>Services</span>
                  <ChevronDown className="h-4 w-4" />
                </button>
                
                <AnimatePresence>
                  {isServicesHovered && (
                    <motion.div 
                      className="absolute top-full left-0 mt-2 w-56 bg-white rounded-lg shadow-xl border border-gray-100 p-2 z-50 max-h-80 overflow-y-auto"
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.2, ease: "easeOut" }}
                    >
                      {dentalServices.map((service, index) => (
                        <div 
                          key={index}
                          className="p-3 cursor-pointer hover:bg-primary/10 rounded-md transition-colors"
                          onClick={onNavigateToServices}
                        >
                          <div className="w-full">
                            <div className="font-medium text-gray-900 font-body text-sm">{service}</div>
                          </div>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.nav>

            {/* Mobile Menu Button - Left */}
            <motion.button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              whileTap={{ scale: 0.95 }}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </motion.button>

            {/* Centered Logo */}
            <motion.div 
              className="flex justify-center flex-1"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.4 }}
            >
              <img 
                src={logoImage} 
                alt="Smile Well Dental" 
                className="h-12 w-auto"
              />
            </motion.div>

            {/* Right Navigation */}
            <motion.nav 
              className="hidden lg:flex items-center space-x-8 flex-1"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.5 }}
            >
              <a href="#contact" className="text-gray-700 hover:text-primary transition-colors font-body">Contact</a>
              <div 
                className="relative"
                onMouseEnter={() => setIsLocationsHovered(true)}
                onMouseLeave={() => setIsLocationsHovered(false)}
              >
                <button 
                  className="flex items-center space-x-1 text-gray-700 hover:text-primary transition-colors focus:outline-none font-body"
                  onClick={onNavigateToLocation}
                >
                  <span>Location</span>
                  <ChevronDown className="h-4 w-4" />
                </button>
                
                <AnimatePresence>
                  {isLocationsHovered && (
                    <motion.div 
                      className="absolute top-full left-0 mt-2 w-48 bg-white rounded-lg shadow-xl border border-gray-100 p-2 z-50"
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.2, ease: "easeOut" }}
                    >
                      {locations.map((location) => (
                        <div 
                          key={location.id}
                          className="p-3 cursor-pointer hover:bg-primary/10 rounded-md transition-colors"
                          onClick={() => onNavigateToSpecificLocation?.(location.id)}
                        >
                          <div className="w-full">
                            <div className="font-medium text-gray-900 font-body">{location.name}</div>
                          </div>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
              <a href="#contact" className="text-gray-700 hover:text-primary transition-colors font-body">
                CDCP
              </a>
            </motion.nav>

            {/* Mobile CTA - Right */}
            <motion.div 
              className="lg:hidden"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              <Button size="sm" className="bg-primary hover:bg-secondary text-xs px-3 font-body">
                Book
              </Button>
            </motion.div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              className="lg:hidden bg-white border-t border-gray-100 shadow-lg"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
              <motion.div 
                className="px-4 py-4 space-y-4"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3, delay: 0.1 }}
              >
                <nav className="space-y-3">
                  {[
                    { name: 'Home', action: onNavigateToHome },
                    { name: 'About', action: onNavigateToAbout },
                    { name: 'Services', action: onNavigateToServices },
                    { name: 'Location', action: onNavigateToLocation },
                    { name: 'Contact', href: '#contact' }
                  ].map((item, index) => (
                    <motion.div
                      key={item.name}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: 0.1 + (index * 0.05) }}
                    >
                      {item.action ? (
                        <button
                          onClick={() => {
                            item.action();
                            setIsMenuOpen(false);
                          }}
                          className="block text-gray-700 hover:text-primary transition-colors py-2 w-full text-left font-body"
                        >
                          {item.name}
                        </button>
                      ) : (
                        <a
                          href={item.href}
                          className="block text-gray-700 hover:text-primary transition-colors py-2 font-body"
                          onClick={() => setIsMenuOpen(false)}
                        >
                          {item.name}
                        </a>
                      )}
                    </motion.div>
                  ))}
                  
                  {/* Mobile Services Submenu */}
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: 0.3 }}
                    className="border-t border-gray-100 pt-3 mt-3"
                  >
                    <div className="text-gray-900 font-body font-medium py-2 text-sm">Our Services:</div>
                    <div className="space-y-1 pl-4 max-h-40 overflow-y-auto">
                      {dentalServices.map((service, index) => (
                        <motion.button
                          key={service}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: 0.35 + (index * 0.03) }}
                          onClick={() => {
                            onNavigateToServices?.();
                            setIsMenuOpen(false);
                          }}
                          className="block w-full text-left p-2 text-sm text-gray-600 hover:text-primary hover:bg-primary/5 rounded transition-colors font-body"
                        >
                          {service}
                        </motion.button>
                      ))}
                    </div>
                  </motion.div>

                  {/* Mobile Locations Submenu */}
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: 0.4 }}
                    className="border-t border-gray-100 pt-3 mt-3"
                  >
                    <div className="text-gray-900 font-body font-medium py-2 text-sm">Our Locations:</div>
                    <div className="space-y-2 pl-4">
                      {locations.map((location, index) => (
                        <motion.div
                          key={location.name}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: 0.45 + (index * 0.05) }}
                          className="flex items-center justify-between p-2 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
                        >
                          <div>
                            <div className="text-sm font-body font-medium text-gray-900">{location.name}</div>
                            <div className="text-xs text-gray-600 font-body">{location.address}</div>
                          </div>
                          <a 
                            href={`tel:${location.phone.replace(/[^\d]/g, '')}`}
                            className="text-xs text-primary hover:text-secondary transition-colors font-body font-medium"
                            onClick={() => setIsMenuOpen(false)}
                          >
                            {location.phone}
                          </a>
                        </motion.div>
                      ))}
                    </div>
                  </motion.div>
                </nav>
                <motion.div 
                  className="space-y-2 pt-4 border-t border-gray-100"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.5 }}
                >
                  <div className="space-y-2">
                    <div className="grid grid-cols-1 gap-2">
                      <Button variant="outline" size="sm" className="w-full border-primary text-primary hover:bg-primary hover:text-white text-xs font-body">
                        North Vancouver: 778-340-2897
                      </Button>
                      <Button variant="outline" size="sm" className="w-full border-primary text-primary hover:bg-primary hover:text-white text-xs font-body">
                        Surrey: 778-877-3493
                      </Button>
                      <Button variant="outline" size="sm" className="w-full border-primary text-primary hover:bg-primary hover:text-white text-xs font-body">
                        Langley: 604-546-2828
                      </Button>
                    </div>
                  </div>
                  <Button className="w-full bg-primary hover:bg-secondary font-body">
                    Book Consultation
                  </Button>
                </motion.div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.header>
  );
}