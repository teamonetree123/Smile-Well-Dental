import { motion } from 'motion/react';
import { MapPin, Navigation, Bus, Car } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';

const locationDirections = [
  {
    name: 'North Vancouver',
    address: 'Suite #202, 814 15th St West',
    city: 'North Vancouver, BC V7M 1T2',
    directions: {
      driving: 'Take Highway 1 West to Exit 14 (Lonsdale Ave), turn right on 15th Street West',
      transit: 'Take SeaBus to Lonsdale Quay, then bus #229 to 15th Street West',
      landmarks: 'Located near Lonsdale Avenue, above Save-On-Foods'
    },
    googleMapsUrl: 'https://maps.google.com/?q=814+15th+St+West,+North+Vancouver,+BC'
  },
  {
    name: 'Surrey',
    address: '15243 91 Ave #2',
    city: 'Surrey, BC V3R 8P8',
    directions: {
      driving: 'Take Highway 10 to 152nd Street, turn south to 91st Avenue',
      transit: 'Take SkyTrain to Surrey Central, then bus #321 to 91st Avenue',
      landmarks: 'Located in Guildford area, near Central City Shopping Centre'
    },
    googleMapsUrl: 'https://maps.google.com/?q=15243+91+Ave,+Surrey,+BC'
  },
  {
    name: 'Langley',
    address: 'A125 & A130 20487 65 Ave',
    city: 'Langley, BC V2Y 3J7',
    directions: {
      driving: 'Take Highway 1 to 200th Street exit, turn south to 64th Avenue, then east to 65th Avenue',
      transit: 'Take bus #502 from Surrey Central or #364 from Langley Centre',
      landmarks: 'Located in Willoughby Town Centre area'
    },
    googleMapsUrl: 'https://maps.google.com/?q=20487+65+Ave,+Langley,+BC'
  }
];

export function Directions() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
              <Navigation className="h-6 w-6 text-primary" />
            </div>
            <h2 className="font-heading text-gray-900">
              Getting to <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Our Clinics
              </span>
            </h2>
          </div>
          <p className="text-lg text-gray-700 font-body max-w-3xl mx-auto">
            Find detailed directions to each of our three convenient locations. Whether you're driving 
            or using public transit, we've made it easy to reach us.
          </p>
        </motion.div>

        <div className="space-y-12">
          {locationDirections.map((location, index) => (
            <motion.div
              key={location.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="border-gray-200 hover:shadow-xl transition-all duration-300">
                <CardContent className="p-8">
                  <div className="grid lg:grid-cols-2 gap-8">
                    {/* Location Info */}
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                          <MapPin className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-body font-medium text-gray-900">{location.name}</h3>
                          <p className="text-gray-600 font-body text-sm">{location.address}</p>
                          <p className="text-gray-600 font-body text-sm">{location.city}</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-start gap-3">
                          <Car className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                          <div>
                            <h4 className="font-body font-medium text-gray-900 mb-1">By Car</h4>
                            <p className="text-gray-600 font-body text-sm">{location.directions.driving}</p>
                          </div>
                        </div>

                        <div className="flex items-start gap-3">
                          <Bus className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                          <div>
                            <h4 className="font-body font-medium text-gray-900 mb-1">By Transit</h4>
                            <p className="text-gray-600 font-body text-sm">{location.directions.transit}</p>
                          </div>
                        </div>

                        <div className="flex items-start gap-3">
                          <Navigation className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                          <div>
                            <h4 className="font-body font-medium text-gray-900 mb-1">Landmarks</h4>
                            <p className="text-gray-600 font-body text-sm">{location.directions.landmarks}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Map Placeholder & Actions */}
                    <div className="space-y-4">
                      <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center">
                        <div className="text-center">
                          <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                          <p className="text-gray-500 font-body text-sm">Interactive map coming soon</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <Button 
                          className="bg-primary hover:bg-secondary text-white font-body"
                          onClick={() => window.open(location.googleMapsUrl, '_blank')}
                        >
                          <Navigation className="mr-2 h-4 w-4" />
                          Get Directions
                        </Button>
                        <Button 
                          variant="outline"
                          className="border-primary text-primary hover:bg-primary hover:text-white font-body"
                        >
                          <MapPin className="mr-2 h-4 w-4" />
                          View on Map
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Additional Transportation Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <Card className="border-gray-200 bg-gray-50/50">
            <CardContent className="p-8">
              <h3 className="font-body font-medium text-gray-900 text-center mb-6">
                Transportation Tips
              </h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Car className="h-6 w-6 text-green-600" />
                  </div>
                  <h4 className="font-body font-medium text-gray-900 mb-2">Free Parking</h4>
                  <p className="text-gray-600 font-body text-sm">
                    Complimentary parking available at all locations
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Bus className="h-6 w-6 text-blue-600" />
                  </div>
                  <h4 className="font-body font-medium text-gray-900 mb-2">Transit Friendly</h4>
                  <p className="text-gray-600 font-body text-sm">
                    Close to major bus routes and SkyTrain stations
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <MapPin className="h-6 w-6 text-purple-600" />
                  </div>
                  <h4 className="font-body font-medium text-gray-900 mb-2">Easy Access</h4>
                  <p className="text-gray-600 font-body text-sm">
                    Ground floor or elevator access at all locations
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Navigation className="h-6 w-6 text-orange-600" />
                  </div>
                  <h4 className="font-body font-medium text-gray-900 mb-2">Clear Signage</h4>
                  <p className="text-gray-600 font-body text-sm">
                    Well-marked entrances and directional signs
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}