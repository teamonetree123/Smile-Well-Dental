import { motion } from 'motion/react';
import { Card, CardContent } from '../ui/card';

const serviceCategories = [
  {
    title: 'Preventive Care',
    services: [
      'Regular checkups and cleanings',
      'Fluoride treatments',
      'Dental sealants',
      'Oral cancer screenings',
      'X-rays and diagnostics'
    ]
  },
  {
    title: 'General Dentistry',
    services: [
      'Fillings and restorations',
      'Root canal therapy',
      'Tooth extractions',
      'Gum disease treatment',
      'Night guard fittings'
    ]
  },
  {
    title: 'Cosmetic Dentistry',
    services: [
      'Teeth whitening',
      'Porcelain veneers',
      'Dental bonding',
      'Smile makeovers',
      'Aesthetic consultations'
    ]
  },
  {
    title: 'Restorative Care',
    services: [
      'Dental crowns and bridges',
      'Dental implants',
      'Dentures (partial & complete)',
      'Implant-supported dentures',
      'Full mouth rehabilitation'
    ]
  },
  {
    title: 'Advanced Treatments',
    services: [
      'Invisalign clear aligners',
      'Sedation dentistry',
      'Laser dentistry',
      'Digital impressions',
      'Same-day crowns'
    ]
  },
  {
    title: 'Emergency Care',
    services: [
      'Same-day emergency appointments',
      'Pain relief treatments',
      'Urgent dental repairs',
      'After-hours emergency line',
      'Weekend availability'
    ]
  }
];

export function ServicesOffered() {
  return (
    <section className="py-20 bg-gray-50/50">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="mb-6 font-heading text-gray-900 text-[36px] font-bold">
            Comprehensive <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Dental Services
            </span>
          </h2>
          <p className="text-lg text-gray-700 font-body max-w-3xl mx-auto">
            All three locations offer our complete range of dental services, from routine checkups 
            to advanced treatments, ensuring you receive consistent, high-quality care wherever you visit.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {serviceCategories.map((category, index) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full border-gray-200 hover:shadow-xl transition-all duration-300 hover:border-primary/30">
                <CardContent className="p-6">
                  <h3 className="font-body font-medium text-gray-900 mb-4">{category.title}</h3>
                  
                  <ul className="space-y-2">
                    {category.services.map((service, serviceIndex) => (
                      <li key={serviceIndex} className="flex items-start gap-2">
                        <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-gray-600 font-body text-sm">{service}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <p className="text-gray-600 font-body">
            Can't find what you're looking for? Contact us to discuss your specific dental needs.
          </p>
        </motion.div>
      </div>
    </section>
  );
}