# Well Smile Dental Website Guidelines

## Design System

### Brand Colors
- Primary: #00B4D8 (Turquoise) - Use for main CTAs and primary elements
- Secondary: #0077B6 (Blue) - Use for secondary actions and accents
- Accent: #00D4AA (Mint Green) - Use sparingly for highlights
- Use white backgrounds with professional, clean layouts

### Typography
- Maintain consistent hierarchy with default typography from globals.css
- Use clear, professional language appropriate for healthcare
- Ensure accessibility with proper contrast ratios

### Components
- Use shadcn/ui components for consistency
- Implement proper hover states and transitions
- Ensure all interactive elements are accessible

## Content Guidelines

### Medical/Dental Content
- Use professional, trustworthy language
- Include clear calls-to-action for appointment booking
- Emphasize safety, expertise, and patient comfort
- Include trust signals (years of experience, patient testimonials, certifications)

### SEO Optimization
- Include relevant keywords for dental services
- Use proper heading structure (h1, h2, h3)
- Add structured data for local business
- Optimize for local search (location, contact info)

## Technical Guidelines

### Next.js Structure
- Use app directory structure
- Implement proper metadata for SEO
- Follow React best practices
- Ensure responsive design for all devices

### Performance
- Optimize images using ImageWithFallback component
- Use efficient layouts with flexbox/grid
- Minimize bundle size
- Implement proper loading states