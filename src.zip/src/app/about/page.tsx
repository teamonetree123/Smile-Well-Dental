import { Metadata } from 'next';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { CheckCircle, Users, Calendar, Smile, Award, Heart, Shield, Target, Star, MapPin, Phone, Mail } from 'lucide-react';
import { ImageWithFallback } from '../../components/figma/ImageWithFallback';
import { Header } from '../../components/Header';
import { Footer } from '../../components/Footer';
import { Navigation } from '../../components/Navigation';
import { AnimatedBackground } from '../../components/AnimatedBackground';

export const metadata: Metadata = {
  title: 'About Us | Smile Well Dental - Your Trusted Dental Care Team',
  description: 'Learn about Smile Well Dental\'s experienced team, our mission to provide exceptional dental care, and our state-of-the-art facilities across North Vancouver, Surrey, and Langley. CDCP supported with personalized, gentle dental services.',
  keywords: 'about smile well dental, dental team, experienced dentists, dental facility, dental care mission, professional dentists, dental clinic history, North Vancouver, Surrey, Langley, BC, CDCP',
  openGraph: {
    title: 'About Smile Well Dental - Your Trusted Dental Care Team',
    description: 'Meet our experienced dental team and learn about our commitment to providing exceptional, personalized dental care in a comfortable environment across BC.',
    url: 'https://smilewelldental.com/about',
  },
};

export default function AboutPage() {
  const stats = [
    { icon: Users, number: '8,500+', label: 'Happy Patients' },
    { icon: Calendar, number: '12+', label: 'Years Experience' },
    { icon: Smile, number: '97%', label: 'Success Rate' },
    { icon: CheckCircle, number: '4.9', label: 'Star Rating' },
  ];

  const values = [
    {
      icon: Heart,
      title: 'Compassionate Care',
      description: 'We treat every patient with kindness, empathy, and respect, ensuring comfort throughout your visit.'
    },
    {
      icon: Shield,
      title: 'Excellence & Safety',
      description: 'We maintain the highest standards of clinical excellence and follow strict safety protocols.'
    },
    {
      icon: Target,
      title: 'Personalized Treatment',
      description: 'Every treatment plan is customized to meet your unique needs and oral health goals.'
    },
    {
      icon: Award,
      title: 'Continuous Innovation',
      description: 'We invest in the latest dental technology and techniques to provide superior care.'
    },
  ];

  const teamMembers = [
    {
      name: 'Dr. Sarah Chen',
      title: 'Lead Dentist & Founder',
      specialization: 'General & Cosmetic Dentistry',
      experience: '15+ Years',
      education: 'DDS, University of British Columbia',
      image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80',
      bio: 'Dr. Chen founded Smile Well Dental with a vision to provide exceptional, personalized dental care across BC. She specializes in cosmetic dentistry and CDCP services.'
    },
    {
      name: 'Dr. Michael Thompson',
      title: 'Senior Dentist',
      specialization: 'Orthodontics & Periodontics',
      experience: '12+ Years',
      education: 'DDS, MSD, University of Toronto',
      image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80',
      bio: 'Dr. Thompson brings extensive expertise in orthodontics and periodontics. He is passionate about helping patients achieve optimal oral health through advanced treatment techniques.'
    },
    {
      name: 'Dr. Emily Rodriguez',
      title: 'Pediatric Dentist',
      specialization: 'Pediatric & Family Dentistry',
      experience: '10+ Years',
      education: 'DDS, Pediatric Residency Certification',
      image: 'https://images.unsplash.com/photo-1594824475303-23db99b5170b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80',
      bio: 'Dr. Rodriguez specializes in pediatric and family dentistry, creating positive dental experiences for children and families across our BC locations.'
    },
  ];

  const facilities = [
    'Digital X-ray technology',
    'Intraoral cameras',
    'Laser dentistry equipment',
    'CEREC same-day crowns',
    'Sterilization center',
    'Comfortable treatment rooms',
    'Emergency dental care setup',
    'CDCP billing system',
  ];

  return (
    <div className="min-h-screen bg-white relative">
      {/* Animated Background */}
      <AnimatedBackground />
      
      {/* Content with relative positioning */}
      <div className="relative z-10">
        {/* Header */}
        <Header />
        
        {/* Navigation */}
        <Navigation showBackButton={true} />
        
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary/10 via-white to-secondary/5 py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900">
                About Smile Well Dental
              </h1>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                For over 12 years, we've been transforming smiles and lives with exceptional dental care, 
                advanced technology, and CDCP support across North Vancouver, Surrey, and Langley.
              </p>
            </div>
          </div>
        </section>

        {/* Story Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div className="space-y-6">
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">
                  Our Story
                </h2>
                <p className="text-lg text-gray-600 leading-relaxed">
                  Smile Well Dental was founded in 2012 with a simple mission: to provide exceptional 
                  dental care that combines advanced technology with a personal touch. What started as 
                  a single clinic has grown into three comprehensive dental centers across BC, but our 
                  core values remain unchanged.
                </p>
                <p className="text-lg text-gray-600 leading-relaxed">
                  We believe that visiting the dentist should be a positive experience. That's why we've 
                  created warm, welcoming environments where patients feel comfortable and cared for. 
                  From routine cleanings to complex procedures, we approach every treatment with precision, 
                  gentleness, and respect for our patients' needs.
                </p>
                <p className="text-lg text-gray-600 leading-relaxed">
                  Today, we're proud to serve over 8,500 patients across our three locations and continue 
                  to set the standard for dental excellence in BC. As a CDCP provider, we're committed to 
                  making quality dental care accessible to all Canadians.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
                  alt="Smile Well Dental team"
                  className="w-full h-48 object-cover rounded-lg shadow-md"
                />
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1551601651-2a8555f1a136?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
                  alt="Modern dental office"
                  className="w-full h-48 object-cover rounded-lg shadow-md mt-8"
                />
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1606811971618-4486d14f3f99?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
                  alt="Dental consultation"
                  className="w-full h-48 object-cover rounded-lg shadow-md -mt-8"
                />
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
                  alt="Happy patient smile"
                  className="w-full h-48 object-cover rounded-lg shadow-md"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Our Track Record
              </h2>
              <p className="text-lg text-gray-600">
                Numbers that reflect our commitment to excellence
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="bg-primary/10 p-6 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                    <stat.icon className="h-10 w-10 text-primary" />
                  </div>
                  <div className="space-y-2">
                    <p className="text-4xl font-bold text-gray-900">{stat.number}</p>
                    <p className="text-gray-600">{stat.label}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Our Core Values
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                These principles guide every interaction we have with our patients and shape 
                the quality of care we provide.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <Card key={index} className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
                  <CardHeader className="pb-4">
                    <div className="bg-primary/10 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                      <value.icon className="h-8 w-8 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{value.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">{value.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Meet Our Expert Team
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Our experienced dentists and staff are dedicated to providing you with 
                the highest quality dental care in a comfortable, friendly environment.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {teamMembers.map((member, index) => (
                <Card key={index} className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-shadow">
                  <div className="aspect-square overflow-hidden">
                    <ImageWithFallback
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardHeader>
                    <CardTitle className="text-xl">{member.name}</CardTitle>
                    <p className="text-primary font-medium">{member.title}</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center text-sm text-gray-600">
                        <Award className="h-4 w-4 mr-2 text-primary" />
                        {member.specialization}
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Calendar className="h-4 w-4 mr-2 text-primary" />
                        {member.experience}
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <CheckCircle className="h-4 w-4 mr-2 text-primary" />
                        {member.education}
                      </div>
                    </div>
                    <p className="text-gray-600 text-sm leading-relaxed">{member.bio}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Facilities Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div className="space-y-6">
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">
                  State-of-the-Art Facilities
                </h2>
                <p className="text-lg text-gray-600 leading-relaxed">
                  Our modern dental facilities across North Vancouver, Surrey, and Langley are equipped 
                  with the latest technology to ensure accurate diagnoses, efficient treatments, and 
                  optimal patient comfort. We continuously invest in advanced equipment to provide you 
                  with the best possible care.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {facilities.map((facility, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                      <span className="text-gray-700">{facility}</span>
                    </div>
                  ))}
                </div>
                <Button size="lg" className="bg-primary hover:bg-secondary">
                  Schedule a Facility Tour
                </Button>
              </div>
              <div className="space-y-4">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1551601651-2a8555f1a136?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                  alt="Modern dental treatment room"
                  className="w-full h-64 object-cover rounded-lg shadow-md"
                />
                <div className="grid grid-cols-2 gap-4">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1606811971618-4486d14f3f99?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80"
                    alt="Advanced dental equipment"
                    className="w-full h-32 object-cover rounded-lg shadow-md"
                  />
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1629909615184-74d3c6baf4ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80"
                    alt="Comfortable waiting area"
                    className="w-full h-32 object-cover rounded-lg shadow-md"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-primary to-secondary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="space-y-6 text-white">
              <h2 className="text-3xl lg:text-4xl font-bold">
                Ready to Experience the Smile Well Difference?
              </h2>
              <p className="text-xl opacity-90 max-w-3xl mx-auto">
                Join thousands of satisfied patients who trust us with their oral health. 
                Schedule your appointment today and discover why we're the preferred choice for dental care across BC.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" variant="secondary" className="bg-white text-primary hover:bg-gray-100">
                  Schedule Appointment
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                  Call (778) 340-2897
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <Footer />
      </div>
    </div>
  );
}