import { motion } from 'motion/react';

export function AnimatedBackground() {
  // Create multiple floating elements with different shapes, sizes, and animation patterns
  const floatingElements = [
    // Large primary circles
    {
      type: 'circle',
      size: 'w-32 h-32',
      color: 'bg-primary/3',
      position: 'top-10 left-10',
      duration: 8,
      delay: 0,
    },
    {
      type: 'circle',
      size: 'w-24 h-24',
      color: 'bg-secondary/4',
      position: 'top-1/4 right-16',
      duration: 10,
      delay: 0.5,
    },
    {
      type: 'circle',
      size: 'w-20 h-20',
      color: 'bg-accent/5',
      position: 'bottom-1/3 left-20',
      duration: 7,
      delay: 1,
    },
    
    // Medium shapes
    {
      type: 'square',
      size: 'w-16 h-16',
      color: 'bg-primary/2',
      position: 'top-1/2 right-1/4',
      duration: 9,
      delay: 0.3,
    },
    {
      type: 'diamond',
      size: 'w-12 h-12',
      color: 'bg-secondary/3',
      position: 'bottom-1/4 right-12',
      duration: 6,
      delay: 0.8,
    },
    {
      type: 'triangle',
      size: 'w-14 h-14',
      color: 'bg-accent/4',
      position: 'top-2/3 left-1/3',
      duration: 7.5,
      delay: 1.2,
    },
    
    // Small decorative elements
    {
      type: 'circle',
      size: 'w-8 h-8',
      color: 'bg-primary/6',
      position: 'top-1/3 left-1/2',
      duration: 5,
      delay: 0.6,
    },
    {
      type: 'circle',
      size: 'w-6 h-6',
      color: 'bg-secondary/5',
      position: 'bottom-1/2 right-1/3',
      duration: 4.5,
      delay: 1.1,
    },
    {
      type: 'square',
      size: 'w-10 h-10',
      color: 'bg-accent/3',
      position: 'top-3/4 right-1/2',
      duration: 6.5,
      delay: 0.4,
    },
    
    // Very small accent dots
    {
      type: 'circle',
      size: 'w-4 h-4',
      color: 'bg-primary/8',
      position: 'top-1/5 right-1/5',
      duration: 4,
      delay: 1.5,
    },
    {
      type: 'circle',
      size: 'w-3 h-3',
      color: 'bg-secondary/7',
      position: 'bottom-1/5 left-1/4',
      duration: 4.2,
      delay: 1.8,
    },
    
    // Large background shapes (very subtle)
    {
      type: 'oval',
      size: 'w-40 h-20',
      color: 'bg-primary/1',
      position: 'top-1/2 left-0',
      duration: 12,
      delay: 2,
    },
    {
      type: 'oval',
      size: 'w-36 h-18',
      color: 'bg-secondary/1',
      position: 'bottom-1/4 right-0',
      duration: 11,
      delay: 2.5,
    },
  ];

  const renderShape = (element: any, index: number) => {
    const baseClasses = `absolute ${element.position} ${element.size} ${element.color} blur-sm`;
    
    const animations = {
      y: [-20, 20, -20],
      x: [-15, 15, -15],
      rotate: element.type === 'diamond' || element.type === 'square' ? [0, 5, -5, 0] : [0, 2, -2, 0],
      scale: [1, 1.05, 0.95, 1],
    };

    switch (element.type) {
      case 'circle':
        return (
          <motion.div
            key={index}
            className={`${baseClasses} rounded-full`}
            animate={animations}
            transition={{
              duration: element.duration,
              repeat: Infinity,
              ease: "easeInOut",
              delay: element.delay,
            }}
          />
        );
        
      case 'square':
        return (
          <motion.div
            key={index}
            className={`${baseClasses} rounded-lg`}
            animate={animations}
            transition={{
              duration: element.duration,
              repeat: Infinity,
              ease: "easeInOut",
              delay: element.delay,
            }}
          />
        );
        
      case 'diamond':
        return (
          <motion.div
            key={index}
            className={`${baseClasses} transform rotate-45`}
            animate={animations}
            transition={{
              duration: element.duration,
              repeat: Infinity,
              ease: "easeInOut",
              delay: element.delay,
            }}
          />
        );
        
      case 'triangle':
        return (
          <motion.div
            key={index}
            className={`absolute ${element.position}`}
            animate={animations}
            transition={{
              duration: element.duration,
              repeat: Infinity,
              ease: "easeInOut",
              delay: element.delay,
            }}
          >
            <div
              className={`w-0 h-0 border-l-7 border-r-7 border-b-12 border-l-transparent border-r-transparent ${element.color.replace('bg-', 'border-b-')} blur-sm`}
              style={{
                borderLeftWidth: '7px',
                borderRightWidth: '7px',
                borderBottomWidth: '12px',
              }}
            />
          </motion.div>
        );
        
      case 'oval':
        return (
          <motion.div
            key={index}
            className={`${baseClasses} rounded-full`}
            animate={animations}
            transition={{
              duration: element.duration,
              repeat: Infinity,
              ease: "easeInOut",
              delay: element.delay,
            }}
          />
        );
        
      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* Gradient overlay for depth */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.01] via-transparent to-secondary/[0.01]" />
      
      {/* Floating shapes */}
      {floatingElements.map((element, index) => renderShape(element, index))}
      
      {/* Subtle animated gradient orbs */}
      <motion.div
        className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-radial from-primary/[0.02] to-transparent rounded-full blur-3xl"
        animate={{
          scale: [1, 1.1, 1],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      
      <motion.div
        className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gradient-radial from-secondary/[0.02] to-transparent rounded-full blur-3xl"
        animate={{
          scale: [1, 1.15, 1],
          opacity: [0.2, 0.4, 0.2],
        }}
        transition={{
          duration: 7,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1.5,
        }}
      />
      
      <motion.div
        className="absolute top-1/2 right-1/2 w-64 h-64 bg-gradient-radial from-accent/[0.015] to-transparent rounded-full blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.25, 0.35, 0.25],
        }}
        transition={{
          duration: 5,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2.5,
        }}
      />
    </div>
  );
}