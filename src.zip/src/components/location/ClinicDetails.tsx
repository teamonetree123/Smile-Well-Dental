import { motion } from 'motion/react';
import { Clock, Phone, MapPin, Calendar } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';

const locations = [
  {
    name: 'North Vancouver',
    address: 'Suite #202, 814 15th St West',
    city: 'North Vancouver, BC V7M 1T2',
    phone: '(778) 340-2897',
    hours: {
      'Monday - Friday': '8:00 AM - 6:00 PM',
      'Saturday': '9:00 AM - 4:00 PM',
      'Sunday': 'Closed'
    }
  },
  {
    name: 'Surrey',
    address: '15243 91 Ave #2',
    city: 'Surrey, BC V3R 8P8',
    phone: '(778) 877-3493',
    hours: {
      'Monday - Friday': '8:00 AM - 6:00 PM',
      'Saturday': '9:00 AM - 4:00 PM',
      'Sunday': 'Closed'
    }
  },
  {
    name: 'Langley',
    address: 'A125 & A130 20487 65 Ave',
    city: 'Langley, BC V2Y 3J7',
    phone: '(604) 546-2828',
    hours: {
      'Monday - Friday': '8:00 AM - 6:00 PM',
      'Saturday': '9:00 AM - 4:00 PM',
      'Sunday': 'Closed'
    }
  }
];

export function ClinicDetails() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="mb-6 font-heading text-gray-900">
            Our <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Three Convenient Locations
            </span>
          </h2>
          <p className="text-lg text-gray-700 font-body max-w-3xl mx-auto">
            Visit any of our three modern dental clinics across the Lower Mainland. 
            Each location offers the same high-quality care and comprehensive services.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {locations.map((location, index) => (
            <motion.div
              key={location.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full border-gray-200 hover:shadow-xl transition-all duration-300 hover:border-primary/30">
                <CardContent className="p-8">
                  <div className="mb-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                        <MapPin className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="font-body text-gray-900">{location.name}</h3>
                    </div>
                    <div className="space-y-2 text-gray-600 font-body">
                      <p>{location.address}</p>
                      <p>{location.city}</p>
                    </div>
                  </div>

                  <div className="mb-6">
                    <div className="flex items-center gap-3 mb-4">
                      <Phone className="h-5 w-5 text-primary" />
                      <span className="font-body font-medium text-gray-900">Phone</span>
                    </div>
                    <a 
                      href={`tel:${location.phone.replace(/[^0-9]/g, '')}`}
                      className="text-primary hover:text-secondary transition-colors font-body font-medium"
                    >
                      {location.phone}
                    </a>
                  </div>

                  <div className="mb-8">
                    <div className="flex items-center gap-3 mb-4">
                      <Clock className="h-5 w-5 text-primary" />
                      <span className="font-body font-medium text-gray-900">Hours</span>
                    </div>
                    <div className="space-y-1">
                      {Object.entries(location.hours).map(([day, hours]) => (
                        <div key={day} className="flex justify-between text-sm font-body">
                          <span className="text-gray-600">{day}:</span>
                          <span className="text-gray-900 font-medium">{hours}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Button 
                      className="w-full bg-primary hover:bg-secondary text-white font-body"
                      size="lg"
                    >
                      <Calendar className="mr-2 h-4 w-4" />
                      Book Appointment
                    </Button>
                    <Button 
                      variant="outline"
                      className="w-full border-primary text-primary hover:bg-primary hover:text-white font-body"
                      size="lg"
                    >
                      <MapPin className="mr-2 h-4 w-4" />
                      Get Directions
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}