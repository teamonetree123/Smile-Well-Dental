import { motion } from 'motion/react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { ArrowRight, Shield, Heart, Smile, Clock, Award, Users } from 'lucide-react';

interface LocationSpecificServicesProps {
  locationId: string;
}

const locationServices = {
  'north-vancouver': {
    title: 'Comprehensive Dental Services in North Vancouver',
    subtitle: 'From routine cleanings to advanced treatments, we provide complete dental care for your family',
    featured: [
      {
        icon: Smile,
        title: 'Cosmetic Dentistry',
        description: 'Transform your smile with veneers, whitening, and smile makeovers',
        highlights: ['Porcelain Veneers', 'Professional Whitening', 'Smile Design']
      },
      {
        icon: Shield,
        title: 'Preventive Care',
        description: 'Keep your smile healthy with regular checkups and cleanings',
        highlights: ['Regular Cleanings', 'Fluoride Treatments', 'Oral Cancer Screening']
      },
      {
        icon: Heart,
        title: 'Family Dentistry',
        description: 'Gentle, comprehensive care for patients of all ages',
        highlights: ['Pediatric Care', 'Adult Dentistry', 'Senior Care']
      }
    ],
    additionalServices: [
      'Root Canal Therapy',
      'Dental Implants',
      'Emergency Dental Care',
      'Periodontal Treatment',
      'Oral Surgery',
      'Dentures & Partials'
    ],
    specialFocus: 'North Vancouver Specialties',
    locationFeature: 'Same-day emergency appointments available'
  },
  'surrey': {
    title: 'Advanced Dental Technology in Surrey',
    subtitle: 'Experience modern dentistry with digital imaging, laser treatments, and minimally invasive procedures',
    featured: [
      {
        icon: Award,
        title: 'Digital Dentistry',
        description: 'State-of-the-art digital imaging and CAD/CAM technology',
        highlights: ['Digital X-rays', 'Intraoral Cameras', '3D Imaging']
      },
      {
        icon: Shield,
        title: 'Laser Dentistry',
        description: 'Precise, comfortable treatments using advanced laser technology',
        highlights: ['Gum Therapy', 'Cavity Treatment', 'Soft Tissue Procedures']
      },
      {
        icon: Clock,
        title: 'Same-Day Treatments',
        description: 'Efficient care with digital impressions and in-office restorations',
        highlights: ['CEREC Crowns', 'Digital Impressions', 'Quick Turnaround']
      }
    ],
    additionalServices: [
      'Invisalign Treatment',
      'Dental Implants',
      'Sleep Apnea Treatment',
      'TMJ Therapy',
      'Wisdom Teeth Removal',
      'Bone Grafting'
    ],
    specialFocus: 'Surrey Technology Center',
    locationFeature: 'Latest digital dental technology available'
  },
  'langley': {
    title: 'Family-Centered Dental Care in Langley',
    subtitle: 'Creating positive dental experiences for the whole family in a comfortable, welcoming environment',
    featured: [
      {
        icon: Users,
        title: 'Family Dentistry',
        description: 'Comprehensive care designed for every member of your family',
        highlights: ['Children\'s Dentistry', 'Teen Orthodontics', 'Adult Care']
      },
      {
        icon: Heart,
        title: 'Gentle Approach',
        description: 'Anxiety-free dentistry with sedation options and comfort amenities',
        highlights: ['Sedation Dentistry', 'Comfort Amenities', 'Gentle Techniques']
      },
      {
        icon: Shield,
        title: 'Preventive Focus',
        description: 'Education and prevention to maintain long-term oral health',
        highlights: ['Patient Education', 'Preventive Plans', 'Home Care Guidance']
      }
    ],
    additionalServices: [
      'Children\'s Dentistry',
      'Orthodontic Consultation',
      'Dental Sealants',
      'Sports Guards',
      'Teeth Grinding Guards',
      'Oral Hygiene Education'
    ],
    specialFocus: 'Langley Family Care',
    locationFeature: 'Child-friendly environment with family scheduling'
  }
};

export function LocationSpecificServices({ locationId }: LocationSpecificServicesProps) {
  const services = locationServices[locationId as keyof typeof locationServices];

  if (!services) {
    return null;
  }

  return (
    <section className="bg-white">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center space-y-4 mb-16"
        >
          <h2 className="font-heading text-gray-900">
            {services.title}
          </h2>
          <p className="text-xl text-gray-600 font-body max-w-3xl mx-auto">
            {services.subtitle}
          </p>
        </motion.div>

        {/* Featured Services */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {services.featured.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full border-gray-200 hover:shadow-xl transition-all duration-300 hover:border-primary/30 group">
                <CardContent className="p-8">
                  <div className="space-y-6">
                    {/* Icon */}
                    <div className="w-16 h-16 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <service.icon className="h-8 w-8 text-primary" />
                    </div>

                    {/* Content */}
                    <div className="space-y-3">
                      <h3 className="font-body text-gray-900">{service.title}</h3>
                      <p className="text-gray-600 font-body leading-relaxed">
                        {service.description}
                      </p>
                    </div>

                    {/* Highlights */}
                    <div className="space-y-2">
                      {service.highlights.map((highlight, idx) => (
                        <div key={idx} className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                          <span className="text-sm text-gray-700 font-body">{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Location Special Feature */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl p-8 mb-16 border border-primary/20"
        >
          <div className="text-center space-y-4">
            <h3 className="font-heading text-gray-900">{services.specialFocus}</h3>
            <p className="text-lg text-primary font-body font-semibold">
              {services.locationFeature}
            </p>
          </div>
        </motion.div>

        {/* Additional Services */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="space-y-8"
        >
          <div className="text-center">
            <h3 className="font-body text-gray-900 mb-4">Additional Services Available</h3>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {services.additionalServices.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                viewport={{ once: true }}
                className="bg-white rounded-lg p-4 border border-gray-200 hover:border-primary/30 hover:shadow-md transition-all duration-300 text-center"
              >
                <p className="text-sm font-body text-gray-700">{service}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center space-y-6 mt-16"
        >
          <div className="space-y-4">
            <h3 className="font-body text-gray-900">Ready to Start Your Treatment?</h3>
            <p className="text-gray-600 font-body max-w-2xl mx-auto">
              Schedule a consultation to discuss your dental needs and create a personalized treatment plan.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-secondary text-white font-body">
              Schedule Consultation
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            
            <Button 
              variant="outline" 
              size="lg" 
              className="border-primary text-primary hover:bg-primary hover:text-white font-body"
            >
              Learn More About Services
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}