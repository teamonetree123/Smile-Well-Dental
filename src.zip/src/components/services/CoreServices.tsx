'use client';

import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { motion } from 'motion/react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { 
  Shield, 
  Stethoscope,
  Zap,
  CheckCircle
} from 'lucide-react';

export function CoreServices() {
  const coreServices = [
    {
      title: "New Patient Exams & Preventive Care",
      icon: Shield,
      color: "bg-primary",
      description: "Prevention is the foundation of lifelong oral health. During your first visit, we complete a comprehensive exam, digital X-rays as needed, oral cancer screening, and a personalized care plan.",
      services: [
        "Professional teeth cleaning and periodontal maintenance",
        "Fluoride and remineralization therapies",
        "Sealants for cavity-prone teeth",
        "Customized sport guards and night guards",
        "Home-care coaching tailored to your goals"
      ]
    },
    {
      title: "General Dentistry",
      icon: Stethoscope,
      color: "bg-secondary",
      description: "Small issues become big ones when ignored. We focus on conservative, durable treatment to stop decay, relieve pain, and protect tooth structure.",
      services: [
        "Tooth-coloured fillings (direct composite)",
        "Inlays, onlays, and full-coverage crowns",
        "Root canal therapy (endodontics) to save infected teeth",
        "Gum care and nonsurgical periodontal therapy",
        "TMJ evaluation and bite adjustments"
      ]
    },
    {
      title: "Emergency Dentistry",
      icon: Zap,
      color: "bg-gradient-to-r from-red-600 to-pink-600",
      description: "Toothache, broken tooth, lost filling, swelling, or dental trauma—we reserve time daily for urgent care. Call us and we'll guide you on the next best step.",
      services: [
        "Same-day emergency appointments",
        "Pain relief and urgent treatment",
        "Dental trauma care",
        "After-hours guidance and support"
      ]
    }
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div 
        className="text-center mb-16"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
      >
        <h2 className="text-3xl sm:text-4xl lg:text-5xl mb-6 font-heading text-gray-900">
          Essential <span className="text-primary">Dental Care</span>
        </h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto font-body">
          Foundation services for optimal oral health and emergency care when you need it most.
        </p>
      </motion.div>

      {/* Dental Care Image Section */}
      <motion.div 
        className="grid lg:grid-cols-2 gap-12 items-center mb-16"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
      >
        <div className="relative rounded-2xl overflow-hidden shadow-xl">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1663151064065-cb334788f77d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBjaGVja3VwJTIwZXhhbWluYXRpb258ZW58MXx8fHwxNzU2MzAyNzkwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Dental examination and checkup"
            className="w-full h-[400px] object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-secondary/10"></div>
        </div>
        <div className="relative rounded-2xl overflow-hidden shadow-xl">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1584516151140-f79fde30d55f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBjbGVhbmluZyUyMHByb2NlZHVyZXxlbnwxfHx8fDE3NTYzMDI3ODR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Professional dental cleaning procedure"
            className="w-full h-[400px] object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-secondary/10 to-primary/10"></div>
        </div>
      </motion.div>

      <div className="grid gap-8 lg:gap-12">
        {coreServices.map((service, index) => (
          <motion.div
            key={service.title}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            viewport={{ once: true }}
          >
            <Card className="overflow-hidden border-2 border-gray-100 hover:border-primary/30 transition-all duration-300 hover:shadow-lg">
              <CardHeader className="pb-4">
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-xl ${service.color} text-white shadow-lg flex-shrink-0`}>
                    <service.icon className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-xl sm:text-2xl font-heading text-gray-900 mb-3">
                      {service.title}
                    </CardTitle>
                    <p className="text-gray-600 font-body leading-relaxed">
                      {service.description}
                    </p>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="grid sm:grid-cols-2 gap-3">
                  {service.services.map((item, itemIndex) => (
                    <div key={itemIndex} className="flex items-start gap-3">
                      <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-gray-700 font-body">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}