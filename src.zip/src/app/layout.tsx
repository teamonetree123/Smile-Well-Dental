import type { Metadata } from 'next';
import '../styles/globals.css';

export const metadata: Metadata = {
  title: 'Smile Well Dental | Premium Dental Care in BC, Canada',
  description: 'Experience exceptional dental care with Smile Well Dental. From routine cleanings to advanced cosmetic procedures, our expert team provides personalized, gentle care across North Vancouver, Surrey, and Langley. CDCP supported. Book your appointment today!',
  keywords: 'dental care, dentist, dental clinic, teeth cleaning, cosmetic dentistry, orthodontics, dental implants, emergency dental care, family dentist, North Vancouver, Surrey, Langley, BC, Canada, CDCP, Canadian Dental Care Plan',
  authors: [{ name: 'Smile Well Dental' }],
  creator: 'Smile Well Dental',
  publisher: 'Smile Well Dental',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    title: 'Smile Well Dental | Premium Dental Care in BC, Canada',
    description: 'Experience exceptional dental care with our expert team. From routine cleanings to advanced cosmetic procedures across North Vancouver, Surrey, and Langley.',
    url: 'https://smilewelldental.com',
    siteName: 'Smile Well Dental',
    locale: 'en_CA',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Smile Well Dental | Premium Dental Care',
    description: 'Experience exceptional dental care with our expert team across BC.',
    creator: '@smilewelldental',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <link rel="canonical" href="https://smilewelldental.com" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
        <meta name="theme-color" content="#00B4D8" />
        
        {/* Structured Data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Dentist",
              "name": "Smile Well Dental",
              "description": "Premium dental care providing comprehensive services including preventive care, cosmetic dentistry, and emergency dental services across North Vancouver, Surrey, and Langley.",
              "url": "https://smilewelldental.com",
              "telephone": "+17783402897",
              "email": "info@smilewelldental.com",
              "address": [
                {
                  "@type": "PostalAddress",
                  "streetAddress": "Suite #202, 814 15th St West",
                  "addressLocality": "North Vancouver",
                  "addressRegion": "BC",
                  "postalCode": "V7P 1M8",
                  "addressCountry": "CA"
                },
                {
                  "@type": "PostalAddress",
                  "streetAddress": "15243 91 Ave #2",
                  "addressLocality": "Surrey",
                  "addressRegion": "BC",
                  "postalCode": "V3R 6A1",
                  "addressCountry": "CA"
                },
                {
                  "@type": "PostalAddress",
                  "streetAddress": "A125 & A130 20487 65 Ave",
                  "addressLocality": "Langley",
                  "addressRegion": "BC",
                  "postalCode": "V2Y 3J8",
                  "addressCountry": "CA"
                }
              ],
              "geo": [
                {
                  "@type": "GeoCoordinates",
                  "latitude": "49.322854",
                  "longitude": "-123.080636"
                },
                {
                  "@type": "GeoCoordinates",
                  "latitude": "49.168765",
                  "longitude": "-122.844726"
                },
                {
                  "@type": "GeoCoordinates",
                  "latitude": "49.104743",
                  "longitude": "-122.602831"
                }
              ],
              "openingHoursSpecification": [
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": ["Monday", "Wednesday", "Friday"],
                  "opens": "08:00",
                  "closes": "16:30"
                },
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": "Tuesday",
                  "opens": "08:00",
                  "closes": "12:00"
                }
              ],
              "serviceArea": [
                {
                  "@type": "City",
                  "name": "North Vancouver"
                },
                {
                  "@type": "City",
                  "name": "Surrey"
                },
                {
                  "@type": "City",
                  "name": "Langley"
                }
              ],
              "medicalSpecialty": "Dentistry",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.9",
                "reviewCount": "350"
              },
              "paymentAccepted": ["CDCP", "Cash", "Credit Card", "Insurance"],
              "priceRange": "$$",
              "hasOfferCatalog": {
                "@type": "OfferCatalog",
                "name": "Dental Services",
                "itemListElement": [
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Service",
                      "name": "Preventive Dentistry"
                    }
                  },
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Service",
                      "name": "Cosmetic Dentistry"
                    }
                  },
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Service",
                      "name": "Restorative Dentistry"
                    }
                  },
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Service",
                      "name": "Emergency Dental Care"
                    }
                  }
                ]
              }
            })
          }}
        />
      </head>
      <body className="antialiased">
        {children}
      </body>
    </html>
  );
}