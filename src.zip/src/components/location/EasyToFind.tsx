import { motion } from 'motion/react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export function EasyToFind() {
  return (
    <section className="py-20 bg-gray-50/50">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="mb-6 font-heading text-gray-900 font-bold text-[36px]">
              Easy to <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Find & Reach
              </span>
            </h2>
            <p className="text-lg text-gray-700 font-body mb-8">
              Our dental clinics are strategically located in easily accessible areas with excellent 
              transportation links. Whether you're driving or using public transit, reaching us is convenient.
            </p>

            <div className="grid sm:grid-cols-2 gap-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                viewport={{ once: true }}
              >
                <h4 className="font-body font-medium text-gray-900 mb-2">Ample Parking</h4>
                <p className="text-gray-600 font-body text-sm">
                  Free parking available at all locations with disabled access spaces.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <h4 className="font-body font-medium text-gray-900 mb-2">Public Transit</h4>
                <p className="text-gray-600 font-body text-sm">
                  Close to bus routes and SkyTrain stations for easy access.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                viewport={{ once: true }}
              >
                <h4 className="font-body font-medium text-gray-900 mb-2">Central Locations</h4>
                <p className="text-gray-600 font-body text-sm">
                  Located in busy commercial areas with shops and amenities nearby.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                viewport={{ once: true }}
              >
                <h4 className="font-body font-medium text-gray-900 mb-2">Clear Signage</h4>
                <p className="text-gray-600 font-body text-sm">
                  Well-marked entrances and clear directional signage for easy navigation.
                </p>
              </motion.div>
            </div>
          </motion.div>

          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBjbGluaWMlMjBidWlsZGluZ3xlbnwwfHx8fDE3MzQyMjg5MjV8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Smile Well Dental clinic building exterior"
                className="w-full h-[400px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent"></div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}