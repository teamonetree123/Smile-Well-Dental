import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { motion } from 'motion/react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { 
  Phone,
  CheckCircle,
  ShieldCheck,
  Heart
} from 'lucide-react';

export function Hero() {
  return (
    <section className="min-h-screen bg-gradient-to-br from-primary/5 via-white to-secondary/5 flex items-center">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="lg:text-left text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-12"
          >
            <motion.h1 
              className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl mb-6 font-heading text-gray-900"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Smile Well Dental
              </span> Services
            </motion.h1>
            
            <motion.div 
              className="max-w-4xl mx-auto space-y-4 mb-8"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <p className="text-lg sm:text-xl text-gray-700 font-body leading-relaxed">
                From prevention to full-mouth restoration, Smile Well Dental delivers compassionate, evidence-based care for patients of every age. Our team blends modern technology with a gentle touch to help you keep teeth healthy, restore what's damaged, and design confident, natural-looking smiles—right here in BC.
              </p>
              <p className="text-primary italic font-body">
                New patients welcome. Same-day emergency visits when available.
              </p>
            </motion.div>
            
            <motion.div 
              className="flex flex-wrap justify-center gap-4 mb-12"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <Badge className="bg-green-100 text-green-800 border-green-200 font-body px-4 py-2">
                <CheckCircle className="mr-2 h-4 w-4" />
                Evidence-Based Care
              </Badge>
              <Badge className="bg-blue-100 text-blue-800 border-blue-200 font-body px-4 py-2">
                <ShieldCheck className="mr-2 h-4 w-4" />
                Modern Technology
              </Badge>
              <Badge className="bg-purple-100 text-purple-800 border-purple-200 font-body px-4 py-2">
                <Heart className="mr-2 h-4 w-4" />
                Gentle Approach
              </Badge>
            </motion.div>

            <motion.div 
              className="flex justify-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              <Button 
                size="lg" 
                variant="outline"
                className="border-2 border-primary text-primary hover:bg-primary hover:text-white transition-all duration-300 px-8 py-6 text-lg font-body"
              >
                <Phone className="mr-2 h-5 w-5" />
                Call (778) 340-2897
              </Button>
            </motion.div>
          </motion.div>
          </div>

          {/* Image Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1642844819197-5f5f21b89ff8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBvZmZpY2V8ZW58MXx8fHwxNzU2MzAyNzg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Modern dental office with state-of-the-art equipment"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent"></div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}