import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  Calendar,
  AlertTriangle,
  Sparkles,
  CheckCircle,
  ArrowRight
} from 'lucide-react';
import { motion } from 'motion/react';

export function Transformations() {
  const transformationStages = [
    {
      icon: Calendar,
      stage: 'First Visit',
      title: 'Initial Assessment',
      description: 'Mobile, wiggling Teeth',
      detail: 'Comprehensive evaluation reveals the extent of dental issues requiring immediate attention.',
      color: 'from-red-50 to-red-100',
      iconColor: 'text-red-600',
      borderColor: 'border-red-200'
    },
    {
      icon: AlertTriangle,
      stage: 'Before Treatment',
      title: 'Treatment Planning',
      description: 'All need to be extracted',
      detail: 'Complete assessment shows full extraction is necessary for optimal long-term oral health.',
      color: 'from-orange-50 to-orange-100',
      iconColor: 'text-orange-600',
      borderColor: 'border-orange-200'
    },
    {
      icon: Sparkles,
      stage: 'New Life Begins',
      title: 'Rehabilitation Process',
      description: 'Full Mouth Rehabilitation',
      detail: 'Advanced surgical procedures and modern techniques begin the transformation journey.',
      color: 'from-blue-50 to-blue-100',
      iconColor: 'text-blue-600',
      borderColor: 'border-blue-200'
    },
    {
      icon: CheckCircle,
      stage: 'After Treatment',
      title: 'Complete Transformation',
      description: '"All in 6" – All teeth supported by 6 implants on each side',
      detail: 'Revolutionary implant technology provides a permanent, natural-looking smile solution.',
      color: 'from-green-50 to-green-100',
      iconColor: 'text-green-600',
      borderColor: 'border-green-200'
    }
  ];

  return (
    <section className="py-20 bg-white relative overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20 mb-4">
              Real Patient Results
            </Badge>
          </motion.div>
          
          <motion.h2 
            className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Smile Well Smile Transformations
          </motion.h2>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mb-6"></div>
          </motion.div>
          
          <motion.p 
            className="text-gray-600 text-lg leading-relaxed max-w-3xl mx-auto mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            viewport={{ once: true }}
          >
            Real patient results—subtle, natural, camera-ready. Photos shown with consent; 
            individual outcomes vary.
          </motion.p>
        </motion.div>

        {/* Transformation Timeline */}
        <div className="relative max-w-6xl mx-auto">
          {/* Timeline Line - Hidden on mobile, visible on larger screens */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-red-200 via-orange-200 via-blue-200 to-green-200 transform -translate-y-1/2 z-0"></div>
          
          {/* Timeline Stages */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10 auto-rows-fr">
            {transformationStages.map((stage, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: 0.6, 
                  delay: 0.6 + (index * 0.2),
                  type: "spring",
                  stiffness: 100
                }}
                viewport={{ once: true }}
                whileHover={{ 
                  y: -10, 
                  scale: 1.02,
                  transition: { duration: 0.2 }
                }}
                className="relative h-full"
              >

                
                <Card className={`h-full bg-gradient-to-br ${stage.color} ${stage.borderColor} border-2 hover:shadow-2xl transition-all duration-300 group relative overflow-hidden`}>
                  <CardContent className="p-6 text-center relative z-10 h-full flex flex-col">
                    {/* Background decoration */}
                    <div className="absolute top-0 right-0 w-20 h-20 bg-white/20 rounded-full -translate-y-6 translate-x-6 group-hover:scale-110 transition-transform duration-300" />
                    
                    {/* Stage Number */}
                    <motion.div 
                      className="inline-flex items-center justify-center w-8 h-8 bg-white/80 backdrop-blur-sm rounded-full mb-4 text-sm font-bold text-gray-700 relative z-10"
                      initial={{ scale: 0, rotate: -180 }}
                      whileInView={{ scale: 1, rotate: 0 }}
                      transition={{ 
                        duration: 0.5, 
                        delay: 0.8 + (index * 0.2),
                        type: "spring",
                        stiffness: 150
                      }}
                      viewport={{ once: true }}
                    >
                      {index + 1}
                    </motion.div>
                    
                    {/* Icon */}
                    <motion.div 
                      className={`w-16 h-16 bg-white/90 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-sm relative z-10 group-hover:bg-white transition-colors duration-300`}
                      initial={{ scale: 0, rotate: -180 }}
                      whileInView={{ scale: 1, rotate: 0 }}
                      transition={{ 
                        duration: 0.6, 
                        delay: 0.9 + (index * 0.2),
                        type: "spring",
                        stiffness: 150
                      }}
                      viewport={{ once: true }}
                    >
                      <stage.icon className={`h-8 w-8 ${stage.iconColor} transition-colors duration-300`} />
                    </motion.div>
                    
                    {/* Content */}
                    <div className="relative z-10 flex-1 flex flex-col">
                      <motion.p 
                        className="text-sm font-semibold text-gray-600 mb-2 uppercase tracking-wide"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: 1.0 + (index * 0.2) }}
                        viewport={{ once: true }}
                      >
                        {stage.stage}
                      </motion.p>
                      
                      <motion.h4 
                        className="text-lg font-bold text-gray-900 mb-3"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: 1.1 + (index * 0.2) }}
                        viewport={{ once: true }}
                      >
                        {stage.title}
                      </motion.h4>
                      
                      <motion.p 
                        className="text-gray-700 font-medium mb-3 text-sm"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: 1.2 + (index * 0.2) }}
                        viewport={{ once: true }}
                      >
                        {stage.description}
                      </motion.p>
                      
                      <motion.p 
                        className="text-gray-600 text-xs leading-relaxed mt-auto"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: 1.3 + (index * 0.2) }}
                        viewport={{ once: true }}
                      >
                        {stage.detail}
                      </motion.p>
                    </div>
                  </CardContent>
                </Card>

                {/* Arrow for mobile */}
                {index < transformationStages.length - 1 && (
                  <div className="lg:hidden flex justify-center mt-4 mb-4">
                    <ArrowRight className="h-6 w-6 text-gray-400" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>

        {/* Bottom CTA Section */}
        <motion.div 
          className="text-center mt-16 p-8 bg-gradient-to-r from-primary/5 to-secondary/5 rounded-3xl shadow-lg"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.8 }}
          viewport={{ once: true }}
        >
          <motion.h3 
            className="text-2xl font-bold text-gray-900 mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.9 }}
            viewport={{ once: true }}
          >
            Ready for Your Smile Transformation?
          </motion.h3>
          
          <motion.p 
            className="text-gray-600 mb-8 max-w-2xl mx-auto text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 2.0 }}
            viewport={{ once: true }}
          >
            Experience the life-changing results of modern dental implant technology. 
            Schedule your consultation to discover what's possible for your smile.
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 2.1 }}
            viewport={{ once: true }}
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                className="bg-primary hover:bg-secondary transition-all duration-300 px-8 shadow-lg"
              >
                Book Your Consultation
              </Button>
            </motion.div>
            
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-white transition-all duration-300 px-8 shadow-sm"
              >
                Learn About Implants
              </Button>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}