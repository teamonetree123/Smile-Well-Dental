import { motion } from 'motion/react';
import { Button } from '../ui/button';
import { Calendar, Phone, MapPin, Clock } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface LocationSpecificHeroProps {
  locationId: string;
}

const locationData = {
  'north-vancouver': {
    name: 'North Vancouver',
    title: 'Your Trusted North Vancouver Dental Team',
    subtitle: 'Professional dental care in the heart of North Vancouver',
    description: 'Located on 15th Street West, our North Vancouver clinic has been serving the community with comprehensive dental services since 2010. Our experienced team provides personalized care in a modern, comfortable environment.',
    image: 'https://images.unsplash.com/photo-1750583834596-4309dd630bcd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxOb3J0aCUyMFZhbmNvdXZlciUyMGRlbnRhbCUyMGNsaW5pYyUyMGJ1aWxkaW5nfGVufDF8fHx8MTc1NjMzMTMwMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    address: 'Suite #202, 814 15th St West',
    city: 'North Vancouver, BC V7M 1T2',
    phone: '(778) 340-2897',
    hours: 'Mon-Fri: 8AM-6PM, Sat: 9AM-4PM',
    specialties: ['Family Dentistry', 'Cosmetic Treatments', 'Emergency Care'],
    highlight: 'Serving North Vancouver families for over 13 years'
  },
  'surrey': {
    name: 'Surrey',
    title: 'Advanced Dental Care in Surrey',
    subtitle: 'Modern dentistry with a personal touch in Surrey',
    description: 'Our Surrey location on 91st Avenue combines state-of-the-art technology with compassionate care. We proudly serve the Surrey community with comprehensive dental services for the whole family.',
    image: 'https://images.unsplash.com/photo-1642844819197-5f5f21b89ff8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTdXJyZXklMjBkZW50YWwlMjBvZmZpY2UlMjBtb2Rlcm58ZW58MXx8fHwxNzU2MzMxMzAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    address: '15243 91 Ave #2',
    city: 'Surrey, BC V3R 8P8',
    phone: '(778) 877-3493',
    hours: 'Mon-Fri: 8AM-6PM, Sat: 9AM-4PM',
    specialties: ['Digital Dentistry', 'Preventive Care', 'Oral Surgery'],
    highlight: 'Latest technology and innovative treatments'
  },
  'langley': {
    name: 'Langley',
    title: 'Comprehensive Dental Services in Langley',
    subtitle: 'Quality dental care for Langley families',
    description: 'Located on 65th Avenue, our Langley clinic offers a full range of dental services in a welcoming, family-friendly environment. We are committed to helping you achieve optimal oral health.',
    image: 'https://images.unsplash.com/photo-1642552667018-354cd1d5f477?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxMYW5nbGV5JTIwZGVudGFsJTIwY2xpbmljJTIwZXh0ZXJpb3J8ZW58MXx8fHwxNzU2MzMxMzAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    address: 'A125 & A130 20487 65 Ave',
    city: 'Langley, BC V2Y 3J7',
    phone: '(604) 546-2828',
    hours: 'Mon-Fri: 8AM-6PM, Sat: 9AM-4PM',
    specialties: ['Family Dentistry', 'Pediatric Care', 'Restorative Dentistry'],
    highlight: 'Family-focused care in a comfortable setting'
  }
};

export function LocationSpecificHero({ locationId }: LocationSpecificHeroProps) {
  const location = locationData[locationId as keyof typeof locationData];

  if (!location) {
    return null;
  }

  return (
    <section className="relative bg-gradient-to-br from-blue-50/30 via-white to-primary/5 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%2300B4D8' fill-opacity='0.4'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          
          {/* Left Content */}
          <motion.div 
            className="space-y-8"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            {/* Location Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-primary font-body font-medium text-sm"
            >
              <MapPin className="h-4 w-4" />
              {location.name} Location
            </motion.div>

            {/* Main Heading */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="space-y-4"
            >
              <h1 className="font-heading text-gray-900 leading-tight">
                {location.title}
              </h1>
              <p className="text-xl text-gray-600 font-body font-medium">
                {location.subtitle}
              </p>
              <p className="text-gray-600 font-body leading-relaxed text-lg">
                {location.description}
              </p>
            </motion.div>

            {/* Highlight */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg p-6 border border-primary/20"
            >
              <p className="text-primary font-body font-semibold text-lg">
                {location.highlight}
              </p>
            </motion.div>

            {/* Quick Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.7 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
            >
              <div className="flex items-center gap-3 p-4 bg-white rounded-lg shadow-sm border border-gray-100">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                  <Phone className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 font-body">Call us</p>
                  <p className="font-body font-semibold text-gray-900">{location.phone}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-4 bg-white rounded-lg shadow-sm border border-gray-100">
                <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center">
                  <Clock className="h-5 w-5 text-secondary" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 font-body">Hours</p>
                  <p className="font-body font-semibold text-gray-900">{location.hours}</p>
                </div>
              </div>
            </motion.div>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button size="lg" className="bg-primary hover:bg-secondary text-white font-body shadow-lg">
                <Calendar className="mr-2 h-5 w-5" />
                Book Appointment
              </Button>
              
              <Button 
                variant="outline" 
                size="lg" 
                className="border-primary text-primary hover:bg-primary hover:text-white font-body"
              >
                <Phone className="mr-2 h-5 w-5" />
                Call {location.phone}
              </Button>
            </motion.div>

            {/* Specialties */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.9 }}
              className="space-y-3"
            >
              <p className="text-sm font-body font-medium text-gray-700">Our Specialties:</p>
              <div className="flex flex-wrap gap-2">
                {location.specialties.map((specialty, index) => (
                  <span 
                    key={index}
                    className="px-3 py-1 bg-accent/10 text-accent rounded-full text-sm font-body font-medium"
                  >
                    {specialty}
                  </span>
                ))}
              </div>
            </motion.div>
          </motion.div>

          {/* Right Image */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="relative"
          >
            <div className="relative overflow-hidden rounded-2xl shadow-2xl">
              <ImageWithFallback
                src={location.image}
                alt={`${location.name} dental clinic exterior`}
                className="w-full h-[600px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent" />
            </div>

            {/* Floating Address Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 1.0 }}
              className="absolute -bottom-6 left-6 right-6 bg-white rounded-xl shadow-xl p-6 border border-gray-100"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <MapPin className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-body font-semibold text-gray-900 mb-1">{location.name} Clinic</p>
                  <p className="text-gray-600 font-body text-sm">{location.address}</p>
                  <p className="text-gray-600 font-body text-sm">{location.city}</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-primary/5 to-transparent rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-secondary/5 to-transparent rounded-full blur-3xl" />
    </section>
  );
}