import { motion } from 'motion/react';
import { Card, CardContent } from '../ui/card';
import { MapPin, Clock, Users, Award, Heart, Star } from 'lucide-react';

interface LocationSpecificWhyChooseProps {
  locationId: string;
}

const locationReasons = {
  'north-vancouver': {
    title: 'Why North Vancouver Families Choose Smile Well Dental',
    subtitle: 'Trusted dental care in the heart of North Vancouver for over 13 years',
    reasons: [
      {
        icon: MapPin,
        title: 'Convenient North Van Location',
        description: 'Easy to reach on 15th Street West with ample parking and public transit access'
      },
      {
        icon: Clock,
        title: 'Flexible Scheduling',
        description: 'Evening and weekend appointments available to fit your busy North Shore lifestyle'
      },
      {
        icon: Users,
        title: 'Community-Focused Care',
        description: 'Proudly serving North Vancouver families and building lasting relationships since 2010'
      },
      {
        icon: Award,
        title: 'Experienced Team',
        description: '13+ years of combined experience providing exceptional dental care to local residents'
      },
      {
        icon: Heart,
        title: 'Gentle Approach',
        description: 'Anxiety-free dentistry with sedation options and comfort amenities for nervous patients'
      },
      {
        icon: Star,
        title: 'Insurance-Friendly',
        description: 'Direct billing available for most insurance plans and CDCP coverage'
      }
    ],
    stats: [
      { number: '13+', label: 'Years Serving North Van' },
      { number: '2000+', label: 'Happy Patients' },
      { number: '98%', label: 'Patient Satisfaction' },
      { number: '15', label: 'Years Combined Experience' }
    ],
    highlight: 'Located in the heart of North Vancouver with easy access from Lonsdale, Deep Cove, and Lynn Valley'
  },
  'surrey': {
    title: 'Why Surrey Residents Trust Smile Well Dental',
    subtitle: 'Advanced dental technology meets personalized care in Surrey',
    reasons: [
      {
        icon: Award,
        title: 'Latest Technology',
        description: 'Digital X-rays, intraoral cameras, and CEREC same-day crowns for efficient treatment'
      },
      {
        icon: Clock,
        title: 'Same-Day Services',
        description: 'Digital impressions and in-office restorations minimize your time away from work'
      },
      {
        icon: MapPin,
        title: 'Central Surrey Location',
        description: 'Conveniently located on 91st Avenue with easy access from Guildford and Newton'
      },
      {
        icon: Users,
        title: 'Modern Comfort',
        description: 'Spa-like amenities and modern facility designed for patient comfort and relaxation'
      },
      {
        icon: Heart,
        title: 'Comprehensive Care',
        description: 'Full range of services from preventive care to advanced restorative treatments'
      },
      {
        icon: Star,
        title: 'Digital Excellence',
        description: 'Paperless office with digital records and online appointment booking for convenience'
      }
    ],
    stats: [
      { number: '100%', label: 'Digital Technology' },
      { number: '1500+', label: 'Satisfied Patients' },
      { number: '95%', label: 'Same-Day Availability' },
      { number: '24/7', label: 'Online Booking' }
    ],
    highlight: 'Surrey\'s most technologically advanced dental practice with cutting-edge equipment and techniques'
  },
  'langley': {
    title: 'Why Langley Families Love Smile Well Dental',
    subtitle: 'Family-centered dental care in a warm, welcoming environment',
    reasons: [
      {
        icon: Users,
        title: 'Family-Friendly Environment',
        description: 'Kid-friendly design with play area and staff specially trained in pediatric care'
      },
      {
        icon: Heart,
        title: 'Gentle Pediatric Care',
        description: 'Specialized techniques and patience to make children comfortable during dental visits'
      },
      {
        icon: MapPin,
        title: 'Convenient Langley Location',
        description: 'Easy access from Walnut Grove, Willoughby, and surrounding Langley communities'
      },
      {
        icon: Clock,
        title: 'Family Scheduling',
        description: 'Block appointments for families and flexible hours to accommodate school schedules'
      },
      {
        icon: Award,
        title: 'Prevention-Focused',
        description: 'Emphasis on education and preventive care to establish lifelong healthy habits'
      },
      {
        icon: Star,
        title: 'Multi-Generational Care',
        description: 'Comprehensive services for patients from infancy through their golden years'
      }
    ],
    stats: [
      { number: '85%', label: 'Family Patients' },
      { number: '500+', label: 'Children Treated' },
      { number: '99%', label: 'Kids Recommend Us' },
      { number: '3', label: 'Generations Served' }
    ],
    highlight: 'Langley\'s premier family dental practice with specialized care for children and seniors'
  }
};

export function LocationSpecificWhyChoose({ locationId }: LocationSpecificWhyChooseProps) {
  const data = locationReasons[locationId as keyof typeof locationReasons];

  if (!data) {
    return null;
  }

  return (
    <section className="bg-gray-50/50">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center space-y-4 mb-16"
        >
          <h2 className="font-heading text-gray-900">
            {data.title}
          </h2>
          <p className="text-xl text-gray-600 font-body max-w-3xl mx-auto">
            {data.subtitle}
          </p>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-16"
        >
          {data.stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-4xl lg:text-5xl font-heading text-primary mb-2">
                {stat.number}
              </div>
              <div className="text-gray-600 font-body font-medium">
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>

        {/* Reasons Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {data.reasons.map((reason, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full border-gray-200 hover:shadow-lg transition-all duration-300 group">
                <CardContent className="p-8">
                  <div className="space-y-4">
                    {/* Icon */}
                    <div className="w-14 h-14 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <reason.icon className="h-7 w-7 text-primary" />
                    </div>

                    {/* Content */}
                    <div className="space-y-3">
                      <h3 className="font-body text-gray-900">{reason.title}</h3>
                      <p className="text-gray-600 font-body leading-relaxed">
                        {reason.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Highlight Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl p-8 border border-primary/20"
        >
          <p className="text-lg text-gray-700 font-body leading-relaxed max-w-4xl mx-auto">
            {data.highlight}
          </p>
        </motion.div>
      </div>
    </section>
  );
}