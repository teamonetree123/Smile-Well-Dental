import { motion } from 'motion/react';
import { Clock, Phone, MapPin, Calendar } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { ImageWithFallback } from '../figma/ImageWithFallback';

const locations = [
  {
    name: 'North Vancouver',
    address: 'Suite #202, 814 15th St West',
    city: 'North Vancouver, BC V7M 1T2',
    phone: '(778) 340-2897',
    image: 'https://images.unsplash.com/photo-1750583834596-4309dd630bcd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxOb3J0aCUyMFZhbmNvdXZlciUyMGRlbnRhbCUyMGNsaW5pYyUyMGJ1aWxkaW5nfGVufDF8fHx8MTc1NjMzMTMwMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    hours: {
      'Monday - Friday': '8:00 AM - 6:00 PM',
      'Saturday': '9:00 AM - 4:00 PM',
      'Sunday': 'Closed'
    }
  },
  {
    name: 'Surrey',
    address: '15243 91 Ave #2',
    city: 'Surrey, BC V3R 8P8',
    phone: '(778) 877-3493',
    image: 'https://images.unsplash.com/photo-1642844819197-5f5f21b89ff8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTdXJyZXklMjBkZW50YWwlMjBvZmZpY2UlMjBtb2Rlcm58ZW58MXx8fHwxNzU2MzMxMzAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    hours: {
      'Monday - Friday': '8:00 AM - 6:00 PM',
      'Saturday': '9:00 AM - 4:00 PM',
      'Sunday': 'Closed'
    }
  },
  {
    name: 'Langley',
    address: 'A125 & A130 20487 65 Ave',
    city: 'Langley, BC V2Y 3J7',
    phone: '(604) 546-2828',
    image: 'https://images.unsplash.com/photo-1642552667018-354cd1d5f477?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxMYW5nbGV5JTIwZGVudGFsJTIwY2xpbmljJTIwZXh0ZXJpb3J8ZW58MXx8fHwxNzU2MzMxMzAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    hours: {
      'Monday - Friday': '8:00 AM - 6:00 PM',
      'Saturday': '9:00 AM - 4:00 PM',
      'Sunday': 'Closed'
    }
  }
];

export function LocationHero() {
  return (
    <section className="min-h-screen bg-gradient-to-br from-primary/5 via-white to-secondary/5 flex items-center py-20">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Hero Content */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          {/* Text Content */}
          <div className="lg:text-left text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <motion.h1 
                className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl mb-6 font-heading text-gray-900"
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                Smile Well Dental — <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                  Location & Hours
                </span>
              </motion.h1>
              
              <motion.div 
                className="max-w-4xl mx-auto lg:mx-0"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
              >
                <p className="text-lg sm:text-xl text-gray-700 font-body leading-relaxed">
                  Welcome to Smile Well Dental. We provide preventive, general, restorative, orthodontic, cosmetic, and emergency dentistry under one roof—delivered with clear communication, gentle technique, and modern technology. New patients are always welcome.
                </p>
              </motion.div>
            </motion.div>
          </div>

          {/* Image Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBvZmZpY2UlMjBsb2NhdGlvbnxlbnwwfHx8fDE3MzQyMjg5MjV8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Smile Well Dental office location and exterior"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent"></div>
            </div>
          </motion.div>
        </div>

        {/* Clinic Location Cards - Integrated within Hero */}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {locations.map((location, index) => (
            <motion.div
              key={location.name}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 1 + index * 0.1 }}
            >
              <Card className="h-full border-gray-200 hover:shadow-xl transition-all duration-300 hover:border-primary/30 relative overflow-hidden group">
                {/* Hover Image */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500 z-0">
                  <ImageWithFallback
                    src={location.image}
                    alt={`${location.name} dental clinic`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-white via-white/80 to-white/60"></div>
                </div>
                
                <CardContent className="p-8 relative z-10">
                  <div className="mb-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                        <MapPin className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="font-body text-gray-900">{location.name}</h3>
                    </div>
                    <div className="space-y-2 text-gray-600 font-body">
                      <p>{location.address}</p>
                      <p>{location.city}</p>
                    </div>
                  </div>

                  <div className="mb-6">
                    <div className="flex items-center gap-3 mb-4">
                      <Phone className="h-5 w-5 text-primary" />
                      <span className="font-body font-medium text-gray-900">Phone</span>
                    </div>
                    <a 
                      href={`tel:${location.phone.replace(/[^0-9]/g, '')}`}
                      className="text-primary hover:text-secondary transition-colors font-body font-medium"
                    >
                      {location.phone}
                    </a>
                  </div>

                  <div className="mb-8">
                    <div className="flex items-center gap-3 mb-4">
                      <Clock className="h-5 w-5 text-primary" />
                      <span className="font-body font-medium text-gray-900">Hours</span>
                    </div>
                    <div className="space-y-1">
                      {Object.entries(location.hours).map(([day, hours]) => (
                        <div key={day} className="flex justify-between text-sm font-body">
                          <span className="text-gray-600">{day}:</span>
                          <span className="text-gray-900 font-medium">{hours}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Button 
                      className="w-full bg-primary hover:bg-secondary text-white font-body"
                      size="lg"
                    >
                      <Calendar className="mr-2 h-4 w-4" />
                      Learn More
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}