import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import cdcpFamilyImage from 'figma:asset/8d9334fbe0f40472190d775c29f776c7310ca240.png';

export function CDCP() {
  return (
    <section className="py-20 relative overflow-hidden">
      {/* Animated Background Shapes */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Large Circle - Top Left */}
        <motion.div
          className="absolute -top-10 -left-10 w-32 h-32 bg-primary/5 rounded-full"
          animate={{
            y: [0, -20, 0],
            x: [0, 15, 0],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        
        {/* Medium Circle - Top Right */}
        <motion.div
          className="absolute top-20 right-16 w-20 h-20 bg-secondary/8 rounded-full"
          animate={{
            y: [0, 25, 0],
            x: [0, -10, 0],
          }}
          transition={{
            duration: 4.5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1
          }}
        />
        
        {/* Triangle Shape - Left Side */}
        <motion.div
          className="absolute top-1/3 left-8 w-0 h-0 border-l-[20px] border-r-[20px] border-b-[35px] border-l-transparent border-r-transparent border-b-accent/6"
          animate={{
            y: [0, -15, 0],
            x: [0, 8, 0],
            rotate: [0, 5, 0]
          }}
          transition={{
            duration: 5.5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.5
          }}
        />
        
        {/* Square - Right Side */}
        <motion.div
          className="absolute bottom-1/3 right-12 w-16 h-16 bg-primary/4 rounded-lg"
          animate={{
            y: [0, 20, 0],
            x: [0, -12, 0],
            rotate: [0, -3, 0]
          }}
          transition={{
            duration: 7,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 2
          }}
        />
        
        {/* Small Circles - Scattered */}
        <motion.div
          className="absolute top-2/3 left-1/4 w-8 h-8 bg-secondary/6 rounded-full"
          animate={{
            y: [0, -12, 0],
            x: [0, 6, 0],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1.5
          }}
        />
        
        <motion.div
          className="absolute bottom-20 left-20 w-12 h-12 bg-accent/5 rounded-full"
          animate={{
            y: [0, 18, 0],
            x: [0, -8, 0],
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 3
          }}
        />
        
        {/* Diamond Shape - Center Right */}
        <motion.div
          className="absolute top-1/2 right-1/4 w-6 h-6 bg-primary/7 transform rotate-45"
          animate={{
            y: [0, -25, 0],
            x: [0, 10, 0],
            rotate: [45, 50, 45]
          }}
          transition={{
            duration: 6.5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.8
          }}
        />
        
        {/* Oval Shape - Bottom */}
        <motion.div
          className="absolute bottom-10 right-1/3 w-24 h-12 bg-secondary/4 rounded-full"
          animate={{
            y: [0, 15, 0],
            x: [0, -15, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 2.5
          }}
        />
        
        {/* Additional Small Decorative Elements */}
        <motion.div
          className="absolute top-10 left-1/3 w-4 h-4 bg-accent/8 rounded-full"
          animate={{
            y: [0, -8, 0],
            x: [0, 4, 0],
          }}
          transition={{
            duration: 3.5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 4
          }}
        />
        
        <motion.div
          className="absolute bottom-1/4 right-8 w-10 h-4 bg-primary/3 rounded-full"
          animate={{
            y: [0, 12, 0],
            x: [0, -6, 0],
          }}
          transition={{
            duration: 4.8,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1.2
          }}
        />
      </div>

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Canadian Dental Care Plan
          </h2>
          <div className="w-16 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            At Smile Well Dental we accept CDCP patients. Experience comprehensive dental care with your government benefits.
          </p>
        </motion.div>

        {/* Main Content - 2 Column Layout */}
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            
            {/* Left Column - Image */}
            <motion.div 
              className="relative order-2 lg:order-1"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src={cdcpFamilyImage}
                  alt="Happy family with dental care"
                  className="w-full h-auto object-cover"
                />
              </div>
            </motion.div>

            {/* Right Column - Benefits Grid */}
            <motion.div 
              className="space-y-6 order-1 lg:order-2"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <div className="grid gap-6">
                {/* CDCP Experts */}
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card className="border-l-4 border-l-primary bg-white hover:shadow-lg transition-all duration-300 hover:border-l-secondary">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                            <span className="text-2xl">👨‍⚕️</span>
                          </div>
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-gray-900 mb-2">
                            CDCP Experts
                          </h3>
                          <p className="text-gray-600 leading-relaxed">
                            Our team is fully trained in CDCP procedures and will help maximize your benefits while minimizing your costs.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Modern Facility */}
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card className="border-l-4 border-l-primary bg-white hover:shadow-lg transition-all duration-300 hover:border-l-secondary">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                            <span className="text-2xl">🏥</span>
                          </div>
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-gray-900 mb-2">
                            Modern Facility
                          </h3>
                          <p className="text-gray-600 leading-relaxed">
                            State-of-the-art equipment and technology ensure you receive the highest quality dental care available.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Flexible Scheduling */}
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card className="border-l-4 border-l-primary bg-white hover:shadow-lg transition-all duration-300 hover:border-l-secondary">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                            <span className="text-2xl">📅</span>
                          </div>
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-gray-900 mb-2">
                            Flexible Scheduling
                          </h3>
                          <p className="text-gray-600 leading-relaxed">
                            Convenient appointment times to fit your busy schedule, including evening and weekend options.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Comprehensive Services */}
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card className="border-l-4 border-l-primary bg-white hover:shadow-lg transition-all duration-300 hover:border-l-secondary">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                            <span className="text-2xl">🦷</span>
                          </div>
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-gray-900 mb-2">
                            Comprehensive Services
                          </h3>
                          <p className="text-gray-600 leading-relaxed">
                            From routine cleanings to implants and Invisalign®, we provide complete care in-house—so you rarely need outside referrals.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </motion.div>
          </div>

          {/* CTA Section */}
          <motion.div 
            className="text-center mt-16 p-8 bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Ready to Use Your CDCP Benefits?
            </h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Book your appointment today and let our CDCP experts help you get the dental care you deserve.
            </p>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                className="bg-primary hover:bg-secondary text-white px-8 py-4 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
              >
                Book Your CDCP Appointment
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}