import { motion } from 'motion/react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Phone, Calendar, MapPin, Clock } from 'lucide-react';

export function Contact() {
  const locations = [
    {
      name: 'North Vancouver',
      phone: '(778) 340-2897',
      address: 'Suite #202, 814 15th St West',
      city: 'North Vancouver, BC'
    },
    {
      name: 'Surrey', 
      phone: '(778) 877-3493',
      address: '15243 91 Ave #2',
      city: 'Surrey, BC'
    },
    {
      name: 'Langley',
      phone: '(604) 546-2828', 
      address: 'A125 & A130 20487 65 Ave',
      city: 'Langley, BC'
    }
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
      {/* Main CTA */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="mb-12"
      >
        <Card className="border-0 shadow-xl bg-gradient-to-br from-primary to-secondary text-white overflow-hidden">
          <CardContent className="p-12 text-center relative">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 left-0 w-32 h-32 bg-white rounded-full -translate-x-16 -translate-y-16"></div>
              <div className="absolute bottom-0 right-0 w-48 h-48 bg-white rounded-full translate-x-24 translate-y-24"></div>
            </div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
              className="relative z-10"
            >
              <h2 className="mb-0 font-[Inter] text-[36px] font-bold">Ready to Meet Us?</h2>
              <p className="text-xl mb-8 text-white/90 max-w-2xl mx-auto font-body">
                We'd love to be your long-term dental home. Call us or request an appointment online. Bring your questions—we'll bring clarity, options, and a plan that fits your goals.
              </p>
              
              <motion.div 
                className="flex flex-col sm:flex-row items-center justify-center gap-4"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                viewport={{ once: true }}
              >
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    size="lg"
                    className="bg-white text-primary hover:bg-gray-100 font-semibold px-8 py-6 text-lg font-body shadow-lg"
                    onClick={() => window.location.href = 'tel:+17783402897'}
                  >
                    <Phone className="h-5 w-5 mr-2" />
                    Call (778) 340-2897
                  </Button>
                </motion.div>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-2 border-white text-white hover:bg-white hover:text-primary font-semibold px-8 py-6 text-lg font-body"
                    onClick={() => window.location.href = '#contact'}
                  >
                    <Calendar className="h-5 w-5 mr-2" />
                    Book Online
                  </Button>
                </motion.div>
              </motion.div>
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Location Cards */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.3 }}
        viewport={{ once: true }}
        className="mb-12"
      >
        <div className="text-center mb-8">
          <motion.h3 
            className="mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            viewport={{ once: true }}
          >
            Visit Us at Any Location
          </motion.h3>
          <motion.p 
            className="text-gray-600 font-body"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            viewport={{ once: true }}
          >
            Three convenient locations across BC to serve you better
          </motion.p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {locations.map((location, index) => (
            <motion.div
              key={location.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.9 + (index * 0.1) }}
              viewport={{ once: true }}
            >
              <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm hover:shadow-xl transition-all duration-300 group h-full">
                <CardContent className="p-6 text-center">
                  <motion.div
                    className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform duration-300"
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <MapPin className="h-8 w-8 text-white" />
                  </motion.div>
                  
                  <h4 className="text-primary mb-3">{location.name}</h4>
                  
                  <div className="space-y-2 text-sm text-gray-600 mb-4 font-body">
                    <p>{location.address}</p>
                    <p>{location.city}</p>
                    
                    <div className="flex items-center justify-center space-x-2 text-gray-900 font-medium">
                      <Phone className="h-4 w-4 text-primary" />
                      <span>{location.phone}</span>
                    </div>
                    
                    <div className="flex items-center justify-center space-x-2 text-gray-500">
                      <Clock className="h-4 w-4 text-secondary" />
                      <span>Mon-Fri: 8am-6pm</span>
                    </div>
                  </div>

                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Button 
                      size="sm" 
                      className="bg-primary/10 text-primary border border-primary/30 hover:bg-primary hover:text-white transition-all duration-300 w-full font-body"
                      onClick={() => window.location.href = `tel:${location.phone.replace(/[^\d]/g, '')}`}
                    >
                      <Phone className="h-4 w-4 mr-2" />
                      Call Now
                    </Button>
                  </motion.div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Final Message */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.4 }}
        viewport={{ once: true }}
        className="text-center"
      >
        <Card className="border-0 shadow-lg bg-gradient-to-r from-accent/10 to-primary/10 p-6">
          <CardContent className="p-0">
            <motion.p 
              className="text-lg text-gray-700 font-body italic"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              viewport={{ once: true }}
            >
              "Your smile is our mission. Your comfort is our priority. Your health is our commitment."
            </motion.p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}