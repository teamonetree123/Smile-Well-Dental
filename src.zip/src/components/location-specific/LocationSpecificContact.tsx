import { motion } from 'motion/react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { MapPin, Phone, Clock, Car, Mail, MessageSquare } from 'lucide-react';

interface LocationSpecificContactProps {
  locationId: string;
}

const locationContact = {
  'north-vancouver': {
    name: 'North Vancouver',
    address: 'Suite #202, 814 15th St West',
    city: 'North Vancouver, BC V7M 1T2',
    phone: '(778) 340-2897',
    email: 'northvan@smilewell.ca',
    hours: {
      'Monday - Friday': '8:00 AM - 6:00 PM',
      'Saturday': '9:00 AM - 4:00 PM',
      'Sunday': 'Closed',
      'Emergency': '24/7 On-Call Service'
    },
    parking: 'Free parking available in building lot and street parking',
    transit: 'Accessible via TransLink buses #229, #230, and #239. Lonsdale Quay 10 minutes away.',
    directions: 'Located between Lonsdale Avenue and Capilano Road, easily accessible from Highway 1 and Lions Gate Bridge.',
    emergencyNote: 'For dental emergencies after hours, call our main number and follow the prompts for emergency service.',
    mapEmbedId: 'north-vancouver-clinic'
  },
  'surrey': {
    name: 'Surrey',
    address: '15243 91 Ave #2',
    city: 'Surrey, BC V3R 8P8',
    phone: '(778) 877-3493',
    email: 'surrey@smilewell.ca',
    hours: {
      'Monday - Friday': '8:00 AM - 6:00 PM',
      'Saturday': '9:00 AM - 4:00 PM',
      'Sunday': 'Closed',
      'Emergency': '24/7 On-Call Service'
    },
    parking: 'Large private parking lot with wheelchair accessible spaces',
    transit: 'Surrey Central SkyTrain station 15 minutes away. Multiple bus routes including #321, #335.',
    directions: 'Located on 91st Avenue between 152nd and 156th Streets, with easy access from Highway 10 and Fraser Highway.',
    emergencyNote: 'Same-day emergency appointments often available. Call as early as possible for urgent care.',
    mapEmbedId: 'surrey-clinic'
  },
  'langley': {
    name: 'Langley',
    address: 'A125 & A130 20487 65 Ave',
    city: 'Langley, BC V2Y 3J7',
    phone: '(604) 546-2828',
    email: 'langley@smilewell.ca',
    hours: {
      'Monday - Friday': '8:00 AM - 6:00 PM',
      'Saturday': '9:00 AM - 4:00 PM',
      'Sunday': 'Closed',
      'Emergency': '24/7 On-Call Service'
    },
    parking: 'Free parking in front of clinic with family-friendly spaces',
    transit: 'Langley Centre bus loop nearby with connections throughout Langley and to SkyTrain.',
    directions: 'Located on 65th Avenue near 204th Street, easily accessible from Langley Bypass and Highway 1.',
    emergencyNote: 'Family-friendly emergency care available. We accommodate children and parents together during urgent visits.',
    mapEmbedId: 'langley-clinic'
  }
};

export function LocationSpecificContact({ locationId }: LocationSpecificContactProps) {
  const contact = locationContact[locationId as keyof typeof locationContact];

  if (!contact) {
    return null;
  }

  return (
    <section className="bg-gray-50/50">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center space-y-4 mb-16"
        >
          <h2 className="font-heading text-gray-900">
            Contact Our {contact.name} Clinic
          </h2>
          <p className="text-xl text-gray-600 font-body max-w-3xl mx-auto">
            Get in touch to schedule your appointment or ask any questions about our services
          </p>
        </motion.div>

        {/* Contact Info Grid */}
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          
          {/* Left - Contact Details */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            {/* Address & Phone */}
            <Card>
              <CardContent className="p-8">
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <MapPin className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-body text-gray-900 mb-2">Visit Our Clinic</h3>
                      <p className="text-gray-600 font-body">{contact.address}</p>
                      <p className="text-gray-600 font-body">{contact.city}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Phone className="h-6 w-6 text-secondary" />
                    </div>
                    <div>
                      <h3 className="font-body text-gray-900 mb-2">Call Us</h3>
                      <a 
                        href={`tel:${contact.phone.replace(/[^0-9]/g, '')}`}
                        className="text-primary hover:text-secondary transition-colors font-body font-semibold text-lg"
                      >
                        {contact.phone}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Mail className="h-6 w-6 text-accent" />
                    </div>
                    <div>
                      <h3 className="font-body text-gray-900 mb-2">Email Us</h3>
                      <a 
                        href={`mailto:${contact.email}`}
                        className="text-primary hover:text-secondary transition-colors font-body font-medium"
                      >
                        {contact.email}
                      </a>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Hours */}
            <Card>
              <CardContent className="p-8">
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Clock className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-body text-gray-900">Office Hours</h3>
                </div>
                <div className="space-y-3">
                  {Object.entries(contact.hours).map(([day, hours]) => (
                    <div key={day} className="flex justify-between items-center">
                      <span className="text-gray-600 font-body">{day}:</span>
                      <span className={`font-body font-medium ${day === 'Emergency' ? 'text-primary' : 'text-gray-900'}`}>
                        {hours}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Directions & Parking */}
            <Card>
              <CardContent className="p-8">
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Car className="h-6 w-6 text-secondary" />
                    </div>
                    <div>
                      <h3 className="font-body text-gray-900 mb-2">Parking & Transit</h3>
                      <p className="text-gray-600 font-body text-sm mb-2">{contact.parking}</p>
                      <p className="text-gray-600 font-body text-sm">{contact.transit}</p>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-body font-medium text-gray-900 mb-2">Directions</h4>
                    <p className="text-gray-600 font-body text-sm">{contact.directions}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Right - Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <Card>
              <CardContent className="p-8">
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <MessageSquare className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-body text-gray-900">Send Us a Message</h3>
                    <p className="text-gray-600 font-body text-sm">We'll get back to you within 24 hours</p>
                  </div>
                </div>

                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-body font-medium text-gray-700 mb-2">
                        First Name
                      </label>
                      <Input 
                        type="text" 
                        placeholder="Your first name"
                        className="font-body"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-body font-medium text-gray-700 mb-2">
                        Last Name
                      </label>
                      <Input 
                        type="text" 
                        placeholder="Your last name"
                        className="font-body"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-body font-medium text-gray-700 mb-2">
                      Email
                    </label>
                    <Input 
                      type="email" 
                      placeholder="your.email@example.com"
                      className="font-body"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-body font-medium text-gray-700 mb-2">
                      Phone
                    </label>
                    <Input 
                      type="tel" 
                      placeholder="(604) 123-4567"
                      className="font-body"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-body font-medium text-gray-700 mb-2">
                      How can we help you?
                    </label>
                    <Textarea 
                      placeholder="Tell us about your dental needs or any questions you have..."
                      rows={4}
                      className="font-body"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    size="lg" 
                    className="w-full bg-primary hover:bg-secondary text-white font-body"
                  >
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Emergency Note */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl p-8 border border-primary/20 text-center"
        >
          <div className="space-y-4">
            <h3 className="font-body text-gray-900">Dental Emergency?</h3>
            <p className="text-lg text-gray-700 font-body max-w-3xl mx-auto">
              {contact.emergencyNote}
            </p>
            <Button size="lg" className="bg-primary hover:bg-secondary text-white font-body">
              <Phone className="mr-2 h-5 w-5" />
              Call for Emergency Care
            </Button>
          </div>
        </motion.div>

        {/* Map Placeholder */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mt-16 bg-gray-200 rounded-2xl h-96 flex items-center justify-center"
        >
          <div className="text-center space-y-2">
            <MapPin className="h-12 w-12 text-gray-400 mx-auto" />
            <p className="text-gray-600 font-body">Interactive map loading...</p>
            <p className="text-sm text-gray-500 font-body">{contact.address}, {contact.city}</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}