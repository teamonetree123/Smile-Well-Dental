import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { 
  Shield, 
  Stethoscope, 
  Zap,
  ArrowRight,
  CheckCircle,
  Calendar,
  Phone
} from 'lucide-react';
import { motion } from 'motion/react';

interface ServicesProps {
  onNavigateToServices: () => void;
}

export function Services({ onNavigateToServices }: ServicesProps) {
  const coreServices = [
    {
      title: "New Patient Exams & Preventive Care",
      icon: Shield,
      color: "bg-primary",
      description: "Prevention is the foundation of lifelong oral health. Comprehensive exams, digital X-rays, oral cancer screening, and personalized care plans.",
      features: [
        "Professional teeth cleaning",
        "Fluoride and remineralization therapies", 
        "Sealants for cavity-prone teeth",
        "Customized sport guards and night guards"
      ]
    },
    {
      title: "General Dentistry",
      icon: Stethoscope,
      color: "bg-secondary",
      description: "Conservative, durable treatment to stop decay, relieve pain, and protect tooth structure with modern techniques.",
      features: [
        "Tooth-coloured fillings",
        "Inlays, onlays, and crowns",
        "Root canal therapy",
        "Gum care and periodontal therapy"
      ]
    },
    {
      title: "Emergency Dentistry",
      icon: Zap,
      color: "bg-gradient-to-r from-red-600 to-pink-600",
      description: "Same-day emergency appointments for toothache, broken teeth, lost fillings, swelling, or dental trauma.",
      features: [
        "Same-day emergency appointments",
        "Pain relief and urgent treatment",
        "Dental trauma care",
        "After-hours guidance and support"
      ]
    }
  ];

  return (
    <section className="relative py-20 bg-white">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center space-y-4 mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          viewport={{ once: true }}
        >
          <motion.h2 
            className="text-3xl lg:text-4xl font-bold text-gray-900 mb-8 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
            viewport={{ once: true }}
          >
            Essential <span className="text-primary">Dental Care</span>
          </motion.h2>
          <motion.p 
            className="text-lg text-gray-600 max-w-3xl mx-auto font-body"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Foundation services for optimal oral health and emergency care when you need it most. 
            From prevention to full-mouth restoration, we deliver compassionate, evidence-based care.
          </motion.p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {coreServices.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ 
                duration: 0.3, 
                delay: index * 0.05,
                ease: "easeOut"
              }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
            >
              <Card className="bg-white hover:shadow-xl transition-all duration-300 group h-full border-2 border-gray-100 hover:border-primary/30">
                <CardHeader className="space-y-4">
                  <div className="flex items-start gap-4">
                    <motion.div 
                      className={`p-3 rounded-xl ${service.color} text-white shadow-lg flex-shrink-0`}
                      initial={{ scale: 0, rotate: -180 }}
                      whileInView={{ scale: 1, rotate: 0 }}
                      transition={{ duration: 0.5, delay: (index * 0.1) + 0.3 }}
                      viewport={{ once: true }}
                    >
                      <service.icon className="h-6 w-6" />
                    </motion.div>
                    <div className="flex-1">
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5, delay: (index * 0.1) + 0.4 }}
                        viewport={{ once: true }}
                      >
                        <CardTitle className="font-heading text-gray-900 mb-3">
                          {service.title}
                        </CardTitle>
                        <CardDescription className="text-gray-600 font-body leading-relaxed">
                          {service.description}
                        </CardDescription>
                      </motion.div>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <motion.div 
                    className="space-y-3"
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    transition={{ duration: 0.5, delay: (index * 0.1) + 0.5 }}
                    viewport={{ once: true }}
                  >
                    {service.features.map((feature, featureIndex) => (
                      <motion.div 
                        key={featureIndex} 
                        className="flex items-start gap-3"
                        initial={{ opacity: 0, x: -10 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ 
                          duration: 0.3, 
                          delay: (index * 0.1) + 0.6 + (featureIndex * 0.05) 
                        }}
                        viewport={{ once: true }}
                      >
                        <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-gray-700 font-body">{feature}</span>
                      </motion.div>
                    ))}
                  </motion.div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* View All Services Button */}
        <motion.div 
          className="mt-12 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.1, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button 
              size="lg" 
              onClick={onNavigateToServices}
              className="bg-primary hover:bg-secondary text-white px-8 py-4 font-body"
            >
              View All Services
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>
          <motion.p 
            className="text-gray-600 mt-4 font-body"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.1, delay: 0.3 }}
            viewport={{ once: true }}
          >
            Explore our complete range of dental treatments and procedures
          </motion.p>
        </motion.div>

        {/* CTA Section */}
        <motion.div 
          className="mt-16 rounded-2xl p-8 text-center text-white bg-gradient-to-r from-primary to-secondary"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <motion.h3 
            className="font-heading mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            viewport={{ once: true }}
          >
            Ready to Transform Your Smile?
          </motion.h3>
          <motion.p 
            className="text-lg mb-6 opacity-90 font-body"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            viewport={{ once: true }}
          >
            Schedule a consultation today and discover how we can help you achieve 
            the smile of your dreams with our comprehensive dental services.
          </motion.p>
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            viewport={{ once: true }}
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                variant="secondary"
                className="bg-white text-primary hover:bg-gray-100 font-body"
              >
                <Calendar className="mr-2 h-5 w-5" />
                Book Consultation
              </Button>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                variant="outline"
                className="text-white border-white bg-transparent hover:bg-white hover:text-primary transition-colors duration-200 font-body"
              >
                <Phone className="mr-2 h-5 w-5" />
                Call (778) 340-2897
              </Button>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}