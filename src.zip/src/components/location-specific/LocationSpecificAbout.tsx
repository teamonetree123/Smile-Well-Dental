import { motion } from 'motion/react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Users, Award, Heart, Clock, MapPin, Phone } from 'lucide-react';

interface LocationSpecificAboutProps {
  locationId: string;
}

const locationAbout = {
  'north-vancouver': {
    title: 'About Our North Vancouver Dental Team',
    subtitle: 'Meet the dedicated professionals serving North Vancouver families since 2010',
    story: 'Our North Vancouver clinic opened in 2010 with a mission to provide exceptional dental care to the North Shore community. Located in the heart of North Vancouver on 15th Street West, we have built lasting relationships with families throughout the area, from Lonsdale to Deep Cove and Lynn Valley.',
    teamImage: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0ZWFtJTIwTm9ydGglMjBWYW5jb3V2ZXJ8ZW58MHx8fHwxNzM0MjI4OTI1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    features: [
      {
        icon: Users,
        title: 'Experienced Team',
        description: 'Dr. Sarah Chen leads our team with 15+ years of experience in family and cosmetic dentistry'
      },
      {
        icon: Award,
        title: 'Community Recognition',
        description: 'Recipient of North Vancouver Chamber of Commerce Excellence in Healthcare Award 2022'
      },
      {
        icon: Heart,
        title: 'Patient-Centered Care',
        description: 'Personalized treatment plans focused on your comfort and long-term oral health'
      },
      {
        icon: Clock,
        title: 'Convenient Hours',
        description: 'Extended evening and weekend hours to accommodate North Shore work schedules'
      }
    ],
    philosophy: 'We believe in building lasting relationships with our patients through honest communication, gentle care, and comprehensive treatment options. Our North Vancouver team is committed to serving our community with integrity and excellence.',
    communityInvolvement: 'Proud sponsors of North Vancouver Minor Hockey and active participants in local health fairs and school dental education programs.',
    address: 'Suite #202, 814 15th St West, North Vancouver, BC V7M 1T2',
    phone: '(778) 340-2897'
  },
  'surrey': {
    title: 'About Our Surrey Dental Practice',
    subtitle: 'Innovative dental care combining advanced technology with personalized service',
    story: 'Our Surrey location represents the future of dental care, featuring the latest in digital dentistry technology. We opened in 2015 to serve the growing Surrey community with state-of-the-art treatments and modern amenities designed for patient comfort.',
    teamImage: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0ZWFtJTIwU3VycmV5fGVufDB8fHx8MTczNDIyODkyNXww&ixlib=rb-4.1.0&q=80&w=1080',
    features: [
      {
        icon: Award,
        title: 'Technology Leaders',
        description: 'First practice in Surrey to offer CEREC same-day crowns and 3D digital imaging'
      },
      {
        icon: Clock,
        title: 'Efficient Care',
        description: 'Digital workflows reduce treatment time and improve accuracy for better outcomes'
      },
      {
        icon: Users,
        title: 'Specialized Training',
        description: 'Our team regularly attends continuing education in the latest dental technologies'
      },
      {
        icon: Heart,
        title: 'Modern Comfort',
        description: 'Spa-like environment with massage chairs, noise-cancelling headphones, and aromatherapy'
      }
    ],
    philosophy: 'We embrace innovation while maintaining a personal touch. Our Surrey team combines cutting-edge technology with compassionate care to deliver exceptional results efficiently and comfortably.',
    communityInvolvement: 'Supporting Surrey schools through dental education programs and participating in community health screenings at local events.',
    address: '15243 91 Ave #2, Surrey, BC V3R 8P8',
    phone: '(778) 877-3493'
  },
  'langley': {
    title: 'About Our Langley Family Practice',
    subtitle: 'Three generations of families trust us for comprehensive, gentle dental care',
    story: 'Our Langley clinic has been a cornerstone of family dental care since 2008. Located on 65th Avenue, we specialize in creating positive dental experiences for patients of all ages, from toddlers to grandparents, in a warm and welcoming environment.',
    teamImage: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0ZWFtJTIwTGFuZ2xleXxlbnwwfHx8fDE3MzQyMjg5MjV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    features: [
      {
        icon: Users,
        title: 'Multi-Generational Care',
        description: 'Specialized training in pediatric, adult, and geriatric dentistry for comprehensive family care'
      },
      {
        icon: Heart,
        title: 'Child-Friendly Environment',
        description: 'Colorful play area, treasure box rewards, and staff specially trained in working with children'
      },
      {
        icon: Award,
        title: 'Prevention Focus',
        description: 'Emphasis on education and preventive care to establish lifelong healthy oral habits'
      },
      {
        icon: Clock,
        title: 'Family Scheduling',
        description: 'Convenient block appointments for families and flexible scheduling around school hours'
      }
    ],
    philosophy: 'We believe in making dental care a positive experience for the whole family. Our gentle approach, patient education, and focus on prevention help create healthy smiles that last a lifetime.',
    communityInvolvement: 'Active in Langley schools with dental hygiene education programs and sponsor of youth sports teams throughout the community.',
    address: 'A125 & A130 20487 65 Ave, Langley, BC V2Y 3J7',
    phone: '(604) 546-2828'
  }
};

export function LocationSpecificAbout({ locationId }: LocationSpecificAboutProps) {
  const about = locationAbout[locationId as keyof typeof locationAbout];

  if (!about) {
    return null;
  }

  return (
    <section className="bg-white">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center space-y-4 mb-16"
        >
          <h2 className="font-heading text-gray-900">
            {about.title}
          </h2>
          <p className="text-xl text-gray-600 font-body max-w-3xl mx-auto">
            {about.subtitle}
          </p>
        </motion.div>

        {/* Story Section */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-20">
          
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <div className="space-y-4">
              <h3 className="font-body text-gray-900">Our Story</h3>
              <p className="text-gray-600 font-body leading-relaxed text-lg">
                {about.story}
              </p>
              <p className="text-gray-600 font-body leading-relaxed">
                {about.philosophy}
              </p>
            </div>

            {/* Contact Info */}
            <div className="bg-gray-50 rounded-lg p-6 space-y-4">
              <h4 className="font-body text-gray-900">Visit Our Clinic</h4>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                  <p className="text-gray-700 font-body">{about.address}</p>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5 text-primary flex-shrink-0" />
                  <a 
                    href={`tel:${about.phone.replace(/[^0-9]/g, '')}`}
                    className="text-primary hover:text-secondary transition-colors font-body font-medium"
                  >
                    {about.phone}
                  </a>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right Image */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="relative overflow-hidden rounded-2xl shadow-xl">
              <ImageWithFallback
                src={about.teamImage}
                alt={`${locationId} dental team`}
                className="w-full h-[400px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent" />
            </div>
          </motion.div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {about.features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full border-gray-200 hover:shadow-lg transition-all duration-300 group">
                <CardContent className="p-6 text-center">
                  <div className="space-y-4">
                    {/* Icon */}
                    <div className="w-12 h-12 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform duration-300">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>

                    {/* Content */}
                    <div className="space-y-2">
                      <h4 className="font-body text-gray-900">{feature.title}</h4>
                      <p className="text-sm text-gray-600 font-body leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Community Involvement */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl p-8 border border-primary/20 mb-12"
        >
          <div className="space-y-4">
            <h3 className="font-body text-gray-900">Community Involvement</h3>
            <p className="text-gray-700 font-body leading-relaxed max-w-3xl mx-auto">
              {about.communityInvolvement}
            </p>
          </div>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center space-y-6"
        >
          <div className="space-y-4">
            <h3 className="font-body text-gray-900">Ready to Meet Our Team?</h3>
            <p className="text-gray-600 font-body max-w-2xl mx-auto">
              Experience the difference of personalized dental care. Schedule a consultation to meet our team and tour our facility.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-secondary text-white font-body">
              Schedule a Tour
            </Button>
            
            <Button 
              variant="outline" 
              size="lg" 
              className="border-primary text-primary hover:bg-primary hover:text-white font-body"
            >
              Call {about.phone}
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}