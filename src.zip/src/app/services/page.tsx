'use client';

import { Header } from '../../components/Header';
import { Footer } from '../../components/Footer';
import { MobileBottomNav } from '../../components/MobileBottomNav';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { ImageWithFallback } from '../../components/figma/ImageWithFallback';
import { motion, useScroll, useTransform } from 'motion/react';
import { useRef } from 'react';
import { 
  Smile, 
  Shield, 
  Star, 
  Clock, 
  Award, 
  Phone, 
  Calendar,
  CheckCircle,
  Heart,
  Zap,
  Users,
  Camera,
  Sparkles,
  Stethoscope
} from 'lucide-react';

export default function ServicesPage() {
  const containerRef = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  const services = [
    {
      category: "Preventive Care",
      icon: Shield,
      color: "bg-primary",
      description: "Keep your smile healthy with our comprehensive preventive treatments",
      treatments: [
        {
          name: "Regular Cleanings & Checkups",
          description: "Professional dental cleanings every 6 months to prevent cavities and gum disease",
          duration: "60-90 minutes",
          price: "Starting at $150",
          features: ["Thorough plaque removal", "Gum health assessment", "Oral cancer screening", "Fluoride treatment"]
        },
        {
          name: "Digital X-Rays",
          description: "Advanced digital imaging for accurate diagnosis with 90% less radiation",
          duration: "15-20 minutes",
          price: "Starting at $75",
          features: ["Instant results", "Enhanced image quality", "Safe radiation levels", "Detailed analysis"]
        },
        {
          name: "Fluoride Treatments",
          description: "Strengthen tooth enamel and prevent decay with professional fluoride application",
          duration: "15 minutes",
          price: "Starting at $40",
          features: ["Cavity prevention", "Enamel strengthening", "Safe for all ages", "Quick application"]
        },
        {
          name: "Dental Sealants",
          description: "Protective coating for molars to prevent cavities in hard-to-reach areas",
          duration: "30 minutes",
          price: "Starting at $60 per tooth",
          features: ["Long-lasting protection", "Painless procedure", "Ideal for children", "Cavity prevention"]
        }
      ]
    },
    {
      category: "Restorative Dentistry",
      icon: Heart,
      color: "bg-secondary",
      description: "Restore your smile's function and beauty with advanced restorative treatments",
      treatments: [
        {
          name: "Dental Fillings",
          description: "Natural-looking composite fillings that blend seamlessly with your teeth",
          duration: "45-60 minutes",
          price: "Starting at $180",
          features: ["Mercury-free materials", "Natural appearance", "Same-day treatment", "Long-lasting results"]
        },
        {
          name: "Dental Crowns",
          description: "Custom-crafted crowns to restore damaged teeth to full function and beauty",
          duration: "2 visits, 60 minutes each",
          price: "Starting at $1,200",
          features: ["Porcelain or ceramic options", "Custom color matching", "Durable protection", "Natural feel"]
        },
        {
          name: "Dental Bridges",
          description: "Replace missing teeth with fixed bridges for a complete, functional smile",
          duration: "2-3 visits",
          price: "Starting at $2,500",
          features: ["Permanent solution", "Natural appearance", "Restored chewing ability", "Prevents teeth shifting"]
        },
        {
          name: "Root Canal Therapy",
          description: "Save infected teeth with gentle, pain-free root canal treatment",
          duration: "90-120 minutes",
          price: "Starting at $800",
          features: ["Pain relief", "Tooth preservation", "Advanced techniques", "High success rate"]
        }
      ]
    },
    {
      category: "Cosmetic Dentistry",
      icon: Sparkles,
      color: "bg-accent",
      description: "Transform your smile with our aesthetic dental treatments",
      treatments: [
        {
          name: "Professional Teeth Whitening",
          description: "Brighten your smile up to 8 shades with our safe, effective whitening system",
          duration: "60-90 minutes",
          price: "Starting at $400",
          features: ["Immediate results", "Safe for enamel", "Custom whitening trays", "Long-lasting effects"]
        },
        {
          name: "Porcelain Veneers",
          description: "Ultra-thin porcelain shells for a perfect, Hollywood-worthy smile",
          duration: "2-3 visits",
          price: "Starting at $1,000 per tooth",
          features: ["Natural appearance", "Stain resistant", "Minimal tooth reduction", "Lifetime warranty"]
        },
        {
          name: "Invisalign Clear Aligners",
          description: "Straighten your teeth discreetly with virtually invisible aligners",
          duration: "12-18 months average",
          price: "Starting at $3,500",
          features: ["Nearly invisible", "Removable design", "Comfortable fit", "Predictable results"]
        },
        {
          name: "Dental Bonding",
          description: "Quick and affordable solution for chipped, cracked, or gapped teeth",
          duration: "30-60 minutes",
          price: "Starting at $300 per tooth",
          features: ["Same-day results", "Conservative treatment", "Natural color matching", "Minimal preparation"]
        }
      ]
    },
    {
      category: "Specialized Treatments",
      icon: Stethoscope,
      color: "bg-gray-600",
      description: "Advanced dental solutions for complex oral health needs",
      treatments: [
        {
          name: "Dental Implants",
          description: "Permanent tooth replacement that looks, feels, and functions like natural teeth",
          duration: "3-6 months process",
          price: "Starting at $3,000",
          features: ["Permanent solution", "Bone preservation", "Natural function", "98% success rate"]
        },
        {
          name: "Periodontal Therapy",
          description: "Comprehensive treatment for gum disease to restore oral health",
          duration: "Multiple visits",
          price: "Starting at $400",
          features: ["Non-surgical options", "Advanced techniques", "Gum health restoration", "Ongoing maintenance"]
        },
        {
          name: "Oral Surgery",
          description: "Expert surgical procedures including wisdom tooth extraction",
          duration: "45-120 minutes",
          price: "Starting at $300",
          features: ["Sedation options", "Expert surgeons", "Minimal discomfort", "Fast recovery"]
        },
        {
          name: "TMJ Treatment",
          description: "Relief from jaw pain and dysfunction with customized treatment plans",
          duration: "60 minutes consultation",
          price: "Starting at $200",
          features: ["Custom night guards", "Pain relief", "Improved function", "Non-invasive options"]
        }
      ]
    }
  ];

  const trustIndicators = [
    {
      icon: Award,
      title: "20+ Years Experience",
      description: "Trusted dental care since 2003"
    },
    {
      icon: Users,
      title: "15,000+ Happy Patients",
      description: "Serving the Lower Mainland"
    },
    {
      icon: Star,
      title: "4.9/5 Star Rating",
      description: "Consistently excellent reviews"
    },
    {
      icon: Shield,
      title: "CDCP Supported",
      description: "Canadian Dental Care Plan accepted"
    }
  ];

  return (
    <div ref={containerRef} className="relative bg-gradient-to-br from-white via-gray-50/30 to-blue-50/20 min-h-screen">
      <div className="relative z-10">
        <Header />
        
        <main className="relative pt-32">
          {/* Hero Section */}
          <motion.section 
            className="relative py-20"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.1, ease: "easeOut" }}
          >
            <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.1, delay: 0.1 }}
                >
                  <Badge className="bg-primary/10 text-primary border-primary/20 mb-6">
                    <Smile className="mr-1 h-3 w-3" />
                    Comprehensive Dental Care
                  </Badge>
                </motion.div>
                
                <motion.h1 
                  className="mb-6 text-gray-800 max-w-4xl mx-auto"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.1, delay: 0.2 }}
                >
                  Complete Dental Services for Your Perfect Smile
                </motion.h1>
                
                <motion.p 
                  className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.1, delay: 0.3 }}
                >
                  From preventive care to cosmetic transformations, our experienced team provides comprehensive dental treatments using the latest technology and techniques. All services available at our North Vancouver, Surrey, and Langley locations.
                </motion.p>
                
                <motion.div 
                  className="flex flex-col sm:flex-row gap-4 justify-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.1, delay: 0.4 }}
                >
                  <Button size="lg" className="bg-primary hover:bg-secondary">
                    <Calendar className="mr-2 h-5 w-5" />
                    Book Your Consultation
                  </Button>
                  <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white">
                    <Phone className="mr-2 h-5 w-5" />
                    Call Now: 778-340-2897
                  </Button>
                </motion.div>
              </div>
            </div>
          </motion.section>

          {/* Trust Indicators */}
          <motion.section 
            className="relative py-16 bg-white/80 backdrop-blur-sm"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.1, ease: "easeOut" }}
            viewport={{ once: true, margin: "100px" }}
          >
            <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
                {trustIndicators.map((indicator, index) => (
                  <motion.div 
                    key={indicator.title}
                    className="text-center"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.1, delay: index * 0.05 }}
                    viewport={{ once: true }}
                  >
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
                      <indicator.icon className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="mb-2 text-gray-800">{indicator.title}</h3>
                    <p className="text-sm text-gray-600">{indicator.description}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.section>

          {/* Services Categories */}
          {services.map((category, categoryIndex) => (
            <motion.section 
              key={category.category}
              className="relative py-20"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.1, ease: "easeOut" }}
              viewport={{ once: true, margin: "100px" }}
            >
              <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
                {/* Category Header */}
                <motion.div 
                  className="text-center mb-16"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.1, delay: 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className={`inline-flex items-center justify-center w-20 h-20 ${category.color} rounded-full mb-6`}>
                    <category.icon className="h-10 w-10 text-white" />
                  </div>
                  <h2 className="mb-4 text-gray-800">{category.category}</h2>
                  <p className="text-xl text-gray-600 max-w-3xl mx-auto">{category.description}</p>
                </motion.div>

                {/* Treatments Grid */}
                <div className="grid lg:grid-cols-2 gap-8 mb-12">
                  {category.treatments.map((treatment, treatmentIndex) => (
                    <motion.div
                      key={treatment.name}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.1, delay: treatmentIndex * 0.05 }}
                      viewport={{ once: true }}
                    >
                      <Card className="h-full hover:shadow-lg transition-all duration-300 border-gray-200">
                        <CardHeader className="pb-4">
                          <div className="flex items-center justify-between mb-2">
                            <CardTitle className="text-xl text-gray-800">{treatment.name}</CardTitle>
                            <Badge variant="outline" className="text-primary border-primary/30">
                              {treatment.price}
                            </Badge>
                          </div>
                          <p className="text-gray-600">{treatment.description}</p>
                          <div className="flex items-center gap-4 text-sm text-gray-500 mt-2">
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              {treatment.duration}
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="space-y-2 mb-6">
                            {treatment.features.map((feature, featureIndex) => (
                              <div key={featureIndex} className="flex items-center gap-2">
                                <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                                <span className="text-sm text-gray-600">{feature}</span>
                              </div>
                            ))}
                          </div>
                          <Button className="w-full bg-primary hover:bg-secondary">
                            <Calendar className="mr-2 h-4 w-4" />
                            Book {treatment.name}
                          </Button>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>

                {/* Category CTA */}
                {categoryIndex < services.length - 1 && (
                  <motion.div 
                    className="text-center py-8 border-t border-gray-200"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.1, delay: 0.2 }}
                    viewport={{ once: true }}
                  >
                    <p className="text-gray-600 mb-4">
                      Ready to get started with {category.category.toLowerCase()}?
                    </p>
                    <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white">
                      <Phone className="mr-2 h-5 w-5" />
                      Call for Consultation
                    </Button>
                  </motion.div>
                )}
              </div>
            </motion.section>
          ))}

          {/* Insurance & Payment Options */}
          <motion.section 
            className="relative py-20 bg-white/80 backdrop-blur-sm"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.1, ease: "easeOut" }}
            viewport={{ once: true, margin: "100px" }}
          >
            <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-12">
                <h2 className="mb-6 text-gray-800">Insurance & Payment Options</h2>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                  We make quality dental care accessible with flexible payment options and insurance support
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                <motion.div 
                  className="text-center p-8 bg-white rounded-xl shadow-sm border border-gray-200"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.1, delay: 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-accent/10 rounded-full mb-4">
                    <Shield className="h-8 w-8 text-accent" />
                  </div>
                  <h3 className="mb-4 text-gray-800">CDCP Supported</h3>
                  <p className="text-gray-600 mb-4">
                    We're proud to support the Canadian Dental Care Plan, making dental care more accessible for eligible patients.
                  </p>
                  <Badge className="bg-accent/10 text-accent border-accent/20">
                    Government Program
                  </Badge>
                </motion.div>

                <motion.div 
                  className="text-center p-8 bg-white rounded-xl shadow-sm border border-gray-200"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.1, delay: 0.15 }}
                  viewport={{ once: true }}
                >
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
                    <Heart className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="mb-4 text-gray-800">Insurance Coverage</h3>
                  <p className="text-gray-600 mb-4">
                    We work with most major insurance providers and will help you maximize your benefits for all treatments.
                  </p>
                  <Badge className="bg-primary/10 text-primary border-primary/20">
                    Direct Billing Available
                  </Badge>
                </motion.div>

                <motion.div 
                  className="text-center p-8 bg-white rounded-xl shadow-sm border border-gray-200"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.1, delay: 0.2 }}
                  viewport={{ once: true }}
                >
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-secondary/10 rounded-full mb-4">
                    <Zap className="h-8 w-8 text-secondary" />
                  </div>
                  <h3 className="mb-4 text-gray-800">Flexible Payment</h3>
                  <p className="text-gray-600 mb-4">
                    Multiple payment options including payment plans to make your dental care affordable and convenient.
                  </p>
                  <Badge className="bg-secondary/10 text-secondary border-secondary/20">
                    0% Interest Options
                  </Badge>
                </motion.div>
              </div>
            </div>
          </motion.section>

          {/* Final CTA */}
          <motion.section 
            className="relative py-20"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.1, ease: "easeOut" }}
            viewport={{ once: true, margin: "100px" }}
          >
            <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center bg-gradient-to-r from-primary to-secondary rounded-2xl p-12 text-white">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.1, delay: 0.1 }}
                  viewport={{ once: true }}
                >
                  <h2 className="mb-6 text-white">Ready to Transform Your Smile?</h2>
                  <p className="text-xl mb-8 text-white/90 max-w-3xl mx-auto">
                    Book your consultation today and discover how our comprehensive dental services can give you the healthy, beautiful smile you deserve.
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                      <Calendar className="mr-2 h-5 w-5" />
                      Book Free Consultation
                    </Button>
                    <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                      <Phone className="mr-2 h-5 w-5" />
                      Call Now: 778-340-2897
                    </Button>
                  </div>
                  
                  <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                    <div className="flex items-center justify-center gap-2">
                      <CheckCircle className="h-4 w-4" />
                      <span>Free Consultation</span>
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      <CheckCircle className="h-4 w-4" />
                      <span>CDCP Accepted</span>
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      <CheckCircle className="h-4 w-4" />
                      <span>Flexible Payment Plans</span>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </motion.section>
        </main>

        <Footer />
        <MobileBottomNav />
      </div>

      {/* Simple Scroll Progress Indicator */}
      <motion.div 
        className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-secondary to-accent z-[100] origin-left shadow-lg"
        style={{ scaleX: scrollYProgress }}
      />
    </div>
  );
}