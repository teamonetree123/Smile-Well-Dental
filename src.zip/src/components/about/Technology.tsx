import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Shield, Heart, Zap, Eye } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export function Technology() {
  const techFeatures = [
    {
      icon: Shield,
      title: 'Our Technology',
      description: 'We use digital X-rays for lower radiation exposure, 3D digital scanning for mess-free impressions, and intraoral cameras so you can see exactly what we see. When indicated, we coordinate guided implant planning with trusted specialists to deliver precise outcomes.',
      gradient: 'from-accent to-primary'
    },
    {
      icon: Heart,
      title: 'Comfort & Safety',
      description: 'Your comfort is non-negotiable. We offer gentle local anesthesia, nitrous oxide, and oral sedation (for suitable cases). Our sterilization protocols meet or exceed current guidelines, and our team is trained for your safety at every step.',
      gradient: 'from-secondary to-accent'
    }
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="text-center mb-12"
      >
        <motion.h2 
          className="mb-0 font-[Inter] text-[36px] font-bold"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
        >
          Technology & Patient Care
        </motion.h2>
        <motion.p 
          className="text-xl text-gray-600 max-w-3xl mx-auto font-body"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
        >
          Advanced technology meets compassionate care for optimal patient outcomes and comfort.
        </motion.p>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-8 mb-12">
        {techFeatures.map((feature, index) => (
          <motion.div
            key={feature.title}
            initial={{ opacity: 0, x: index === 0 ? -30 : 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.6 + (index * 0.2) }}
            viewport={{ once: true }}
          >
            <Card className="h-full border-0 shadow-xl bg-white/80 backdrop-blur-sm hover:shadow-2xl transition-all duration-300 group">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <motion.div 
                    className={`w-12 h-12 bg-gradient-to-br ${feature.gradient} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <feature.icon className="h-6 w-6 text-white" />
                  </motion.div>
                  <span>{feature.title}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <motion.p 
                  className="leading-relaxed font-body"
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  transition={{ duration: 0.6, delay: 0.8 + (index * 0.2) }}
                  viewport={{ once: true }}
                >
                  {feature.description}
                </motion.p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Technology Showcase */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.4 }}
        viewport={{ once: true }}
      >
        <Card className="border-0 shadow-xl bg-gradient-to-br from-primary/5 to-secondary/5 overflow-hidden">
          <CardContent className="p-0">
            <div className="grid lg:grid-cols-2 gap-0">
              <motion.div 
                className="p-8 lg:p-12 flex flex-col justify-center"
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                viewport={{ once: true }}
              >
                <div className="flex items-center space-x-3 mb-6">
                  <motion.div
                    className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center"
                    whileHover={{ scale: 1.1, rotate: 180 }}
                    transition={{ duration: 0.6 }}
                  >
                    <Eye className="h-8 w-8 text-white" />
                  </motion.div>
                  <div>
                    <h3 className="text-gray-900">See What We See</h3>
                    <p className="text-primary font-body">Advanced Diagnostic Technology</p>
                  </div>
                </div>
                
                <motion.p 
                  className="text-gray-700 mb-6 font-body leading-relaxed"
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  transition={{ duration: 0.6, delay: 0.8 }}
                  viewport={{ once: true }}
                >
                  Our intraoral cameras and digital imaging allow you to see exactly what we see, making diagnosis clear and treatment decisions collaborative. This transparency builds trust and helps you understand your oral health like never before.
                </motion.p>

                <motion.div 
                  className="flex items-center space-x-4"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 1.0 }}
                  viewport={{ once: true }}
                >
                  <div className="flex items-center space-x-2">
                    <Zap className="h-5 w-5 text-accent" />
                    <span className="text-sm font-body text-gray-600">Digital X-rays</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Shield className="h-5 w-5 text-secondary" />
                    <span className="text-sm font-body text-gray-600">3D Scanning</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Eye className="h-5 w-5 text-primary" />
                    <span className="text-sm font-body text-gray-600">Intraoral Cameras</span>
                  </div>
                </motion.div>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.8 }}
                viewport={{ once: true }}
                className="relative"
              >
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1551190822-a9333d879b1f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc1NjMwMjc4NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Advanced dental technology and equipment"
                  className="w-full h-[400px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-l from-primary/10 to-transparent"></div>
              </motion.div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}