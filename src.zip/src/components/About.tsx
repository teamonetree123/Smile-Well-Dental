import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from './ui/carousel';
import { 
  Award, 
  Users, 
  Clock, 
  Shield,
  CheckCircle,
  Star,
  Heart,
  TrendingUp
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { motion } from 'motion/react';
import Autoplay from "embla-carousel-autoplay";
import drShinImage from 'figma:asset/a631e5c693388ece808143d8ec01f571fce9e452.png';
import drZhangImage from 'figma:asset/4eb6a1e9577b6050a5737c4e836503a44b562233.png';
import drJeongImage from 'figma:asset/9bd3fa17a1c814eb6f79a231be0cd03bc0c511c2.png';
import drKwackImage from 'figma:asset/afe09f1357c62d3a79ca9df01dcc33c37f635c71.png';

const values = [
  {
    icon: Award,
    title: 'Excellence in Care',
    description: 'Award-winning dental professionals committed to delivering the highest quality treatments with precision and compassion.'
  },
  {
    icon: Users,
    title: 'Patient-Centered Approach',
    description: 'Every treatment plan is customized to your unique needs, ensuring personalized care that puts your comfort first.'
  },
  {
    icon: Clock,
    title: 'Convenient Scheduling',
    description: 'Flexible appointment times and three convenient locations to fit your busy lifestyle across BC.'
  },
  {
    icon: Shield,
    title: 'Advanced Technology',
    description: 'State-of-the-art equipment and modern techniques ensure safe, effective, and comfortable dental procedures.'
  },
  {
    icon: Heart,
    title: 'Compassionate Team',
    description: 'Our caring staff creates a welcoming environment where patients feel relaxed and confident about their dental care.'
  },
  {
    icon: TrendingUp,
    title: 'Continuous Innovation',
    description: 'We stay current with the latest dental advances to provide you with the most effective and minimally invasive treatments.'
  }
];

const team = [
  {
    name: 'Dr. Shin',
    image: drShinImage,
    credentials: 'DDS, MSc',
    role: 'Lead Dentist & Practice Owner',
    description: 'With over 15 years of experience, Dr. Shin specializes in comprehensive dental care and aesthetic dentistry, ensuring every patient receives exceptional treatment.'
  },
  {
    name: 'Dr. Zhang',
    image: drZhangImage,
    credentials: 'DDS, PhD',
    role: 'Orthodontist & Implant Specialist',
    description: 'Dr. Zhang brings expertise in orthodontics and dental implants, combining advanced techniques with compassionate care for optimal patient outcomes.'
  },
  {
    name: 'Dr. Jeong',
    image: drJeongImage,
    credentials: 'DDS, MSc',
    role: 'Periodontal Specialist',
    description: 'Specializing in gum health and periodontal treatment, Dr. Jeong helps patients maintain healthy foundations for their beautiful smiles.'
  },
  {
    name: 'Dr. Kwack',
    image: drKwackImage,
    credentials: 'DDS, MSc',
    role: 'Cosmetic & Restorative Dentist',
    description: 'Dr. Kwack excels in cosmetic and restorative procedures, transforming smiles with artistic precision and cutting-edge techniques.'
  }
];

const testimonials = [
  {
    name: 'Sarah Johnson',
    text: 'The team at Smile Well Dental made my dental anxiety disappear. Professional, caring, and the results exceeded my expectations!',
    rating: 5,
    date: 'November 2024'
  },
  {
    name: 'Michael Chen',
    text: 'Outstanding service from consultation to follow-up. The CDCP support made quality dental care affordable for my family.',
    rating: 5,
    date: 'October 2024'
  },
  {
    name: 'Emily Rodriguez',
    text: 'Dr. Shin and the team transformed my smile completely. The technology and expertise here are truly impressive.',
    rating: 5,
    date: 'September 2024'
  },
  {
    name: 'David Thompson',
    text: 'Convenient locations, friendly staff, and excellent results. Smile Well Dental has earned my trust and recommendation.',
    rating: 5,
    date: 'August 2024'
  }
];

interface AboutProps {
  onNavigateToAbout?: () => void;
}

export function About({ onNavigateToAbout }: AboutProps = {}) {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div 
          className="text-center space-y-4 mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
              Your smile is our mission
            </Badge>
          </motion.div>
          <motion.h2 
            className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            About Smile Well Dental
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            viewport={{ once: true }}
          >
            Compassionate, comprehensive, and community-focused dental care. 
            We combine dentistry with care, community, and transformation across our three BC locations.
          </motion.p>
        </motion.div>

        {/* CDCP Section */}
        <motion.div 
          className="mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <Card className="bg-gradient-to-r from-primary/5 to-secondary/5 border-primary/20">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.7, delay: 0.4 }}
                  viewport={{ once: true }}
                >
                  <motion.div 
                    className="flex items-center space-x-2 mb-4"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.5 }}
                    viewport={{ once: true }}
                  >
                    <Shield className="h-8 w-8 text-primary" />
                    <h3 className="text-2xl font-bold text-gray-900">Canadian Dental Care Plan (CDCP)</h3>
                  </motion.div>
                  <motion.p 
                    className="text-gray-600 mb-4"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.6 }}
                    viewport={{ once: true }}
                  >
                    We are CDCP experts, trained to help you maximize your benefits and reduce your dental costs. 
                    All our branches are CDCP-supported to provide you with the best possible care.
                  </motion.p>
                  <div className="space-y-2">
                    {['Maximize your CDCP benefits', 'Reduce out-of-pocket costs', 'Expert guidance through the process'].map((item, index) => (
                      <motion.div 
                        key={index}
                        className="flex items-center space-x-2"
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5, delay: 0.7 + (index * 0.1) }}
                        viewport={{ once: true }}
                      >
                        <CheckCircle className="h-5 w-5 text-primary" />
                        <span className="text-gray-700">{item}</span>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
                <motion.div 
                  className="text-center"
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.7, delay: 0.6 }}
                  viewport={{ once: true }}
                >
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1598256989800-fe5f95da9787?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBpbnN1cmFuY2UlMjBoZWFsdGhjYXJlJTIwYmVuZWZpdHN8ZW58MXx8fHwxNzU2MjM1OTM2fDA&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Canadian Dental Care Plan Benefits"
                    className="rounded-lg shadow-lg w-full max-w-md mx-auto"
                  />
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Values */}
        <motion.div 
          className="mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <motion.h3 
            className="text-2xl font-bold text-center text-gray-900 mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            Why Choose Smile Well Dental?
          </motion.h3>
          <motion.div 
            className="max-w-5xl mx-auto"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.6 }}
            viewport={{ once: true }}
          >
            <Carousel
              plugins={[
                Autoplay({
                  delay: 4000,
                  stopOnInteraction: true,
                  stopOnMouseEnter: true,
                }),
              ]}
              opts={{
                align: "start",
                loop: true,
              }}
              className="w-full"
            >
              <CarouselContent className="-ml-2 md:-ml-4">
                {values.map((value, index) => (
                  <CarouselItem key={index} className="pl-2 md:pl-4 basis-full sm:basis-1/2 lg:basis-1/3">
                    <motion.div
                      whileHover={{ y: -5 }}
                    >
                      <Card className="text-center hover:shadow-lg transition-all duration-300 h-full">
                        <CardContent className="p-6 flex flex-col h-full">
                          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                            <value.icon className="h-8 w-8 text-primary" />
                          </div>
                          <h4 className="text-lg font-semibold text-gray-900 mb-2">{value.title}</h4>
                          <p className="text-gray-600 text-sm flex-grow">{value.description}</p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="hidden sm:flex -left-12" />
              <CarouselNext className="hidden sm:flex -right-12" />
            </Carousel>
          </motion.div>
        </motion.div>

        {/* Team */}
        <motion.div 
          className="mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <motion.h3 
            className="text-2xl font-bold text-center text-gray-900 mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            Meet Our Expert Team
          </motion.h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
            {team.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 + (index * 0.1) }}
                viewport={{ once: true }}
                whileHover={{ y: -10 }}
              >
                <Card className="text-center hover:shadow-xl transition-all duration-300 bg-white h-full">
                  <CardContent className="p-8">
                    <motion.div 
                      className="mb-6"
                      initial={{ opacity: 0, scale: 0.8 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.5, delay: 0.8 + (index * 0.1) }}
                      viewport={{ once: true }}
                    >
                      <img
                        src={member.image}
                        alt={member.name}
                        className="w-32 h-32 rounded-full mx-auto object-cover object-top shadow-lg border-4 border-primary/10"
                      />
                    </motion.div>
                    <motion.div 
                      className="space-y-3"
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 1.0 + (index * 0.1) }}
                      viewport={{ once: true }}
                    >
                      <h4 className="text-xl font-bold text-gray-900">{member.name}</h4>
                      <p className="text-primary font-semibold">{member.credentials}</p>
                      <p className="text-secondary font-medium">{member.role}</p>
                      <p className="text-gray-600 text-sm leading-relaxed">{member.description}</p>
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
          <motion.div 
            className="text-center mt-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1.2 }}
            viewport={{ once: true }}
          >
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Our experienced team of dental professionals is dedicated to providing 
              exceptional care with the latest techniques and technologies. Each doctor brings 
              years of expertise and a commitment to patient-centered care.
            </p>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                className="bg-primary hover:bg-secondary transition-colors duration-200"
              >
                Schedule Consultation
              </Button>
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Testimonials */}
        <motion.div 
          className="mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <motion.h3 
            className="text-2xl font-bold text-center text-gray-900 mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            What Our Patients Say
          </motion.h3>
          <div className="grid md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 + (index * 0.2) }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <Card className="hover:shadow-lg transition-all duration-300">
                  <CardContent className="p-6">
                    <motion.div 
                      className="flex items-center space-x-1 mb-4"
                      initial={{ opacity: 0, scale: 0.8 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.5, delay: 0.8 + (index * 0.2) }}
                      viewport={{ once: true }}
                    >
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, scale: 0 }}
                          whileInView={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 0.3, delay: 1.0 + (index * 0.2) + (i * 0.1) }}
                          viewport={{ once: true }}
                        >
                          <Star className="h-5 w-5 text-yellow-400 fill-current" />
                        </motion.div>
                      ))}
                    </motion.div>
                    <p className="text-gray-600 mb-4 italic">"{testimonial.text}"</p>
                    <div className="border-t pt-4">
                      <p className="font-semibold text-gray-900">{testimonial.name}</p>
                      <p className="text-sm text-gray-500">{testimonial.date}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div 
          className="text-center bg-gray-50 rounded-2xl p-8"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <motion.h3 
            className="text-2xl font-bold text-gray-900 mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            Ready to Experience the Smile Well Difference?
          </motion.h3>
          <motion.p 
            className="text-gray-600 mb-6 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            viewport={{ once: true }}
          >
            Join thousands of satisfied patients who trust us with their dental care. 
            Book your consultation today and discover why we're BC's preferred dental clinic.
          </motion.p>
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            viewport={{ once: true }}
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button size="lg" className="bg-primary hover:bg-secondary">
                Book Consultation
              </Button>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                variant="outline" 
                className="border-primary text-primary hover:bg-primary hover:text-white"
                onClick={onNavigateToAbout}
              >
                Learn More About Us
              </Button>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}