'use client';

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '../ui/accordion';
import { motion } from 'motion/react';

export function FAQ() {
  const faqs = [
    {
      question: "How often should I get a checkup?",
      answer: "Most patients do well with a visit every six months. If you're managing gum disease or higher cavity risk, we may recommend a personalized interval."
    },
    {
      question: "Do you see children?",
      answer: "Yes. We provide gentle, prevention-first care for kids and partner with parents on healthy habits."
    },
    {
      question: "Are implants right for me?",
      answer: "Implants work for many adults with healthy gums and adequate bone. We'll review your medical history, imaging, and goals before recommending treatment."
    },
    {
      question: "Is whitening safe?",
      answer: "Professional whitening under dental supervision is safe for most people. We customize strength and method to minimize sensitivity."
    },
    {
      question: "What if I'm nervous?",
      answer: "Tell us—no judgment. We'll pace the appointment, explain each step, and offer sedation options when appropriate."
    },
    {
      question: "Do you accept emergency walk-ins?",
      answer: "Call ahead whenever possible so we can prioritize you. Same-day appointments are offered when our schedule allows."
    }
  ];

  return (
    <div className="py-20 bg-gray-50/30">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl mb-6 font-heading text-gray-900">
            Frequently Asked <span className="text-primary">Questions</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto font-body">
            Get answers to common questions about our dental services and what to expect during your visit.
          </p>
        </motion.div>

        <motion.div 
          className="w-full"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="border border-gray-200 rounded-lg px-6"
              >
                <AccordionTrigger className="text-left font-heading text-lg text-gray-900 hover:text-primary">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-600 font-body leading-relaxed pt-2">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </div>
  );
}