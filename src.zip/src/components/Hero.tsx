import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Award, Users, ThumbsUp, Clock, Star, Shield, Heart } from 'lucide-react';
import { motion, useScroll, useTransform, useSpring } from 'motion/react';
import { useRef } from 'react';

export function Hero() {
  const containerRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });

  // Parallax transforms with different speeds for layered effect
  const backgroundY = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const contentY = useTransform(scrollYProgress, [0, 1], ["0%", "20%"]);
  const floatingElementsY = useTransform(scrollYProgress, [0, 1], ["0%", "-30%"]);
  const imageY = useTransform(scrollYProgress, [0, 1], ["0%", "15%"]);
  
  // Smooth spring animations
  const smoothBackground = useSpring(backgroundY, { stiffness: 300, damping: 30 });
  const smoothContent = useSpring(contentY, { stiffness: 400, damping: 40 });
  const smoothFloating = useSpring(floatingElementsY, { stiffness: 200, damping: 25 });
  const smoothImage = useSpring(imageY, { stiffness: 350, damping: 35 });

  // Scale and opacity transforms for presentation effect
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 0.95]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0.3]);

  return (
    <section 
      ref={containerRef}
      className="relative h-screen min-h-[800px] overflow-hidden"
    >
      {/* Parallax Background Layers */}
      <motion.div 
        className="absolute inset-0 bg-gradient-to-br from-white via-gray-50 to-blue-50"
        style={{ y: smoothBackground }}
      />
      
      {/* Animated Background Shapes */}
      <motion.div 
        className="absolute inset-0"
        style={{ y: smoothFloating }}
      >
        {/* Large floating circles */}
        <motion.div 
          className="absolute top-20 -right-32 w-96 h-96 bg-gradient-to-br from-primary/5 to-secondary/10 rounded-full blur-3xl"
          animate={{ 
            rotate: 360,
            scale: [1, 1.1, 1]
          }}
          transition={{ 
            rotate: { duration: 50, repeat: Infinity, ease: "linear" },
            scale: { duration: 8, repeat: Infinity, ease: "easeInOut" }
          }}
        />
        
        <motion.div 
          className="absolute bottom-32 -left-32 w-80 h-80 bg-gradient-radial from-accent/8 to-transparent rounded-full blur-2xl"
          animate={{ 
            rotate: -360,
            scale: [1, 1.2, 1]
          }}
          transition={{ 
            rotate: { duration: 60, repeat: Infinity, ease: "linear" },
            scale: { duration: 10, repeat: Infinity, ease: "easeInOut" }
          }}
        />

        {/* Floating medical icons */}
        <motion.div 
          className="absolute top-40 left-20 text-primary/20"
          animate={{ 
            y: [-20, 20, -20],
            rotate: [0, 5, -5, 0]
          }}
          transition={{ 
            duration: 6, 
            repeat: Infinity, 
            ease: "easeInOut" 
          }}
        >
          <Shield size={48} />
        </motion.div>

        <motion.div 
          className="absolute top-60 right-32 text-secondary/20"
          animate={{ 
            y: [20, -20, 20],
            rotate: [0, -5, 5, 0]
          }}
          transition={{ 
            duration: 8, 
            repeat: Infinity, 
            ease: "easeInOut",
            delay: 2
          }}
        >
          <Heart size={40} />
        </motion.div>

        <motion.div 
          className="absolute bottom-40 right-20 text-accent/20"
          animate={{ 
            y: [-15, 15, -15],
            rotate: [0, 10, -10, 0]
          }}
          transition={{ 
            duration: 7, 
            repeat: Infinity, 
            ease: "easeInOut",
            delay: 1
          }}
        >
          <Star size={36} />
        </motion.div>
      </motion.div>

      {/* Main Content with Parallax */}
      <motion.div 
        className="relative z-10 h-full flex items-center"
        style={{ 
          y: smoothContent,
          scale,
          opacity
        }}
      >
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            
            {/* Content Section */}
            <motion.div 
              className="space-y-8"
              initial={{ opacity: 0, x: -100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            >
              {/* Trust Badge */}
              <motion.div 
                className="flex items-center space-x-2"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >

              </motion.div>

              {/* Main Heading */}
              <div className="space-y-4">
                <motion.h1 
                  className="text-5xl sm:text-6xl lg:text-7xl leading-tight"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.6, ease: "easeOut" }}
                >
                  <motion.span 
                    className="block text-gray-900 mb-2"
                    initial={{ opacity: 0, x: -50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.6, delay: 0.8 }}
                  >
                    Smile Well Dental:
                  </motion.span>
                  <motion.span 
                    className="block bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent"
                    initial={{ opacity: 0, x: -50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.6, delay: 1.0 }}
                  >
                    Your Premier Dental Experience
                  </motion.span>
                </motion.h1>

                <motion.p 
                  className="text-xl text-gray-600 max-w-2xl leading-relaxed"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 1.2 }}
                >
                  Transform your smile with cutting-edge dental care in British Columbia. 
                  We combine advanced technology, compassionate service, and proven expertise 
                  to deliver exceptional results you'll love.
                </motion.p>
              </div>

              {/* Stats Row */}
              <motion.div 
                className="grid grid-cols-3 gap-8 py-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 1.4 }}
              >
                <div className="text-center">
                  <motion.div 
                    className="text-3xl font-bold text-primary"
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  >
                    15+
                  </motion.div>
                  <div className="text-sm text-gray-600">Years Experience</div>
                </div>
                <div className="text-center">
                  <motion.div 
                    className="text-3xl font-bold text-secondary"
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                  >
                    10k+
                  </motion.div>
                  <div className="text-sm text-gray-600">Happy Patients</div>
                </div>
                <div className="text-center">
                  <motion.div 
                    className="text-3xl font-bold text-accent"
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                  >
                    98%
                  </motion.div>
                  <div className="text-sm text-gray-600">Satisfaction</div>
                </div>
              </motion.div>

              {/* CTA Buttons */}
              <motion.div 
                className="flex flex-col sm:flex-row gap-4"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 1.6 }}
              >
                <motion.div
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                >
                  <Button 
                    size="lg" 
                    className="bg-gradient-to-r from-primary to-secondary hover:from-secondary hover:to-primary text-white shadow-lg hover:shadow-xl transition-all duration-300 px-8 py-6 text-lg"
                  >
                    Book Your Consultation
                  </Button>
                </motion.div>
                
                <motion.div
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                >
                  <Button 
                    size="lg" 
                    variant="outline" 
                    className="border-2 border-primary text-primary hover:bg-primary hover:text-white transition-all duration-300 px-8 py-6 text-lg shadow-md hover:shadow-lg"
                  >
                    Call (778) 340-2897
                  </Button>
                </motion.div>
              </motion.div>
            </motion.div>

            {/* Image Section with Enhanced Parallax */}
            <motion.div 
              className="relative"
              style={{ y: smoothImage }}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
            >
              {/* Main Image */}
              <motion.div 
                className="relative z-20"
                initial={{ opacity: 0, scale: 0.8, rotateY: -15 }}
                animate={{ opacity: 1, scale: 1, rotateY: 0 }}
                transition={{ duration: 1, delay: 0.8, ease: "easeOut" }}
                whileHover={{ 
                  scale: 1.02,
                  rotateY: 2,
                  z: 50
                }}
              >
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1629909613638-0e4a1fad8f81?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBjbGluaWMlMjBwcm9mZXNzaW9uYWwlMjBtb2Rlcm58ZW58MXx8fHwxNzU2MjM0OTc1fDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Smile Well Dental - Modern dental clinic"
                  className="rounded-3xl shadow-2xl w-full transform-gpu"
                />
              </motion.div>
              
              {/* Enhanced Decorative Elements */}
              <motion.div 
                className="absolute -top-8 -right-8 w-32 h-32 bg-gradient-to-br from-primary/20 to-secondary/30 rounded-full blur-2xl"
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 1.2 }}
                animate={{
                  scale: [1, 1.2, 1],
                  rotate: [0, 180, 360]
                }}
                transition={{
                  scale: { duration: 4, repeat: Infinity, ease: "easeInOut" },
                  rotate: { duration: 20, repeat: Infinity, ease: "linear" }
                }}
              />
              
              <motion.div 
                className="absolute -bottom-8 -left-8 w-40 h-40 bg-gradient-radial from-accent/20 to-transparent rounded-full blur-xl"
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 1.4 }}
                animate={{
                  scale: [1, 1.3, 1],
                  rotate: [0, -180, -360]
                }}
                transition={{
                  scale: { duration: 5, repeat: Infinity, ease: "easeInOut" },
                  rotate: { duration: 25, repeat: Infinity, ease: "linear" }
                }}
              />

              {/* Floating Quality Badges */}
              <motion.div 
                className="absolute -top-4 left-8 bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-xl border border-primary/20"
                initial={{ opacity: 0, y: 20, rotate: -5 }}
                animate={{ opacity: 1, y: 0, rotate: 0 }}
                transition={{ duration: 0.8, delay: 1.6 }}
                animate={{
                  y: [-5, 5, -5],
                  rotate: [-2, 2, -2]
                }}
                transition={{
                  duration: 6,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <div className="flex items-center space-x-2">
                  <Star className="h-5 w-5 text-primary fill-current" />
                  <span className="text-sm font-semibold text-gray-800">5.0 Rating</span>
                </div>
              </motion.div>

              <motion.div 
                className="absolute -bottom-4 right-8 bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-xl border border-secondary/20"
                initial={{ opacity: 0, y: -20, rotate: 5 }}
                animate={{ opacity: 1, y: 0, rotate: 0 }}
                transition={{ duration: 0.8, delay: 1.8 }}
                animate={{
                  y: [5, -5, 5],
                  rotate: [2, -2, 2]
                }}
                transition={{
                  duration: 7,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 1
                }}
              >
                <div className="flex items-center space-x-2">
                  <ThumbsUp className="h-5 w-5 text-secondary" />
                  <span className="text-sm font-semibold text-gray-800">Certified</span>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-gray-400"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 2 }}
        animate={{
          y: [0, 10, 0]
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      >
        <div className="flex flex-col items-center space-y-2">
          <span className="text-sm font-medium">Scroll to explore</span>
          <motion.div 
            className="w-6 h-10 border-2 border-gray-300 rounded-full flex justify-center"
            initial={{ opacity: 0.5 }}
            animate={{ opacity: 1 }}
          >
            <motion.div 
              className="w-1 h-3 bg-primary rounded-full mt-2"
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            />
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
}