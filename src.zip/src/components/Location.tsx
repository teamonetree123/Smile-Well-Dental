import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  MapPin, 
  Phone, 
  Clock, 
  Navigation,
  Star,
  Award
} from 'lucide-react';
import { motion } from 'motion/react';

export function Location() {
  const locations = [
    {
      name: 'North Vancouver',
      address: 'Suite #202, 814 15th St West',
      city: 'North Vancouver, BC',
      phone: '(778) 340-2897',
      hours: {
        'Mon/Wed/Fri': '8:00 AM – 4:30 PM',
        'Tuesday': '8:00 AM – 12:00 PM',
        'Thu/Sat/Sun': 'Closed'
      },
      features: ['Central Location', 'Modern Facilities', 'CDCP Supported'],
      mapEmbed: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2603.2745087890787!2d-123.08063662354434!3d49.322854871330266!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54867108c67b2903%3A0x6efcad4b0b6f75a1!2s814%2015th%20St%20W%20%23202%2C%20North%20Vancouver%2C%20BC%20V7P%201M8%2C%20Canada!5e0!3m2!1sen!2sus!4v1705543210987!5m2!1sen!2sus"
    },
    {
      name: 'Surrey',
      address: '15243 91 Ave #2',
      city: 'Surrey, BC',
      phone: '(778) 340-2897',
      hours: {
        'Mon/Wed/Fri': '8:00 AM – 4:30 PM',
        'Tuesday': '8:00 AM – 12:00 PM',
        'Thu/Sat/Sun': 'Closed'
      },
      features: ['Family Friendly', 'Evening Hours', 'Full Services'],
      mapEmbed: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2613.1234567890123!2d-122.84472628354456!3d49.1687654321098!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5485d9b3c8f9e5a7%3A0x1234567890abcdef!2s15243%2091%20Ave%20%232%2C%20Surrey%2C%20BC%20V3R%206A1%2C%20Canada!5e0!3m2!1sen!2sus!4v1705543300123!5m2!1sen!2sus"
    },
    {
      name: 'Langley',
      address: 'A125 & A130 20487 65 Ave',
      city: 'Langley, BC',
      phone: '(778) 340-2897',
      hours: {
        'Mon/Wed/Fri': '8:00 AM – 4:30 PM',
        'Tuesday': '8:00 AM – 12:00 PM',
        'Thu/Sat/Sun': 'Closed'
      },
      features: ['Weekend Hours', 'Parking Available', 'Comprehensive Care'],
      mapEmbed: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2609.765432109876!2d-122.60283128354298!3d49.10474321098765!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5485c8b2a7f6e4d3%3A0xabcdef1234567890!2s20487%2065%20Ave%2C%20Langley%2C%20BC%20V2Y%203J8%2C%20Canada!5e0!3m2!1sen!2sus!4v1705543400456!5m2!1sen!2sus"
    }
  ];

  const trustStats = [
    { icon: Award, number: '20+', label: 'Awards for Care' },
    { icon: Star, number: '5K+', label: 'Happy Patients' },
    { icon: Phone, number: '99%', label: 'Satisfaction' },
    { icon: Clock, number: '25+', label: 'Years Experience' }
  ];

  return (
    <section id="location" className="py-20 bg-gray-50">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div 
          className="text-center space-y-4 mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
              Three Convenient Locations
            </Badge>
          </motion.div>
          <motion.h2 
            className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            Visit Us Across BC
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            viewport={{ once: true }}
          >
            Find the Smile Well Dental location nearest you. All our clinics offer the same 
            high-quality care with modern facilities and flexible scheduling.
          </motion.p>
        </motion.div>

        {/* Trust Indicators */}
        <motion.div 
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          {trustStats.map((stat, index) => (
            <motion.div 
              key={index}
              className="text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 + (index * 0.1) }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
            >
              <motion.div 
                className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg mx-auto mb-2"
                initial={{ scale: 0, rotate: -180 }}
                whileInView={{ scale: 1, rotate: 0 }}
                transition={{ duration: 0.5, delay: 0.6 + (index * 0.1) }}
                viewport={{ once: true }}
              >
                <stat.icon className="h-6 w-6 text-primary" />
              </motion.div>
              <motion.div 
                className="text-2xl font-bold text-gray-900"
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.8 + (index * 0.1) }}
                viewport={{ once: true }}
              >
                {stat.number}
              </motion.div>
              <div className="text-sm text-gray-600">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>

        {/* Locations */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <Tabs defaultValue="north-vancouver" className="w-full">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              viewport={{ once: true }}
            >
              <TabsList className="grid w-full grid-cols-3 mb-8 bg-gray-100">
                {locations.map((location, index) => (
                  <TabsTrigger 
                    key={index} 
                    value={location.name.toLowerCase().replace(/\s+/g, '-')}
                    className="data-[state=active]:bg-primary data-[state=active]:text-white"
                  >
                    {location.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </motion.div>
            
            {locations.map((location, index) => (
              <TabsContent 
                key={index} 
                value={location.name.toLowerCase().replace(/\s+/g, '-')}
                className="mt-0"
              >
                <motion.div 
                  className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  viewport={{ once: true }}
                >
                  {/* Location Info */}
                  <motion.div
                    initial={{ opacity: 0, x: -30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.7, delay: 0.4 }}
                    viewport={{ once: true }}
                    whileHover={{ y: -5 }}
                  >
                    <Card className="bg-white hover:shadow-xl transition-all duration-300">
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <MapPin className="h-5 w-5 text-primary" />
                          <span className="text-xl text-gray-900">{location.name}</span>
                        </CardTitle>
                        <CardDescription className="space-y-1">
                          <span className="block text-gray-600">{location.address}</span>
                          <span className="block text-gray-600">{location.city}</span>
                        </CardDescription>
                      </CardHeader>
                      
                      <CardContent className="space-y-6">
                        {/* Contact Info */}
                        <motion.div 
                          className="space-y-3"
                          initial={{ opacity: 0, y: 20 }}
                          whileInView={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.5, delay: 0.6 }}
                          viewport={{ once: true }}
                        >
                          <div className="flex items-center space-x-2">
                            <Phone className="h-4 w-4 text-primary" />
                            <span className="text-gray-700">{location.phone}</span>
                          </div>
                          
                          <div className="space-y-2">
                            <div className="flex items-center space-x-2">
                              <Clock className="h-4 w-4 text-primary" />
                              <span className="text-gray-700 font-medium">Hours:</span>
                            </div>
                            <div className="ml-6 space-y-1 text-sm">
                              {Object.entries(location.hours).map(([days, hours], hourIndex) => (
                                <motion.div 
                                  key={days} 
                                  className="flex justify-between"
                                  initial={{ opacity: 0, x: -10 }}
                                  whileInView={{ opacity: 1, x: 0 }}
                                  transition={{ duration: 0.3, delay: 0.8 + (hourIndex * 0.05) }}
                                  viewport={{ once: true }}
                                >
                                  <span className="text-gray-600">{days}:</span>
                                  <span className="text-gray-700">{hours}</span>
                                </motion.div>
                              ))}
                            </div>
                          </div>
                        </motion.div>

                        {/* Features */}
                        <motion.div 
                          className="space-y-2"
                          initial={{ opacity: 0, y: 20 }}
                          whileInView={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.5, delay: 0.7 }}
                          viewport={{ once: true }}
                        >
                          <h4 className="font-medium text-gray-900">Features:</h4>
                          <div className="flex flex-wrap gap-2">
                            {location.features.map((feature, featureIndex) => (
                              <motion.div
                                key={featureIndex}
                                initial={{ opacity: 0, scale: 0.8 }}
                                whileInView={{ opacity: 1, scale: 1 }}
                                transition={{ duration: 0.3, delay: 0.9 + (featureIndex * 0.05) }}
                                viewport={{ once: true }}
                              >
                                <Badge 
                                  variant="secondary" 
                                  className="bg-primary/10 text-primary border-primary/20 text-xs"
                                >
                                  {feature}
                                </Badge>
                              </motion.div>
                            ))}
                          </div>
                        </motion.div>

                        {/* Actions */}
                        <motion.div 
                          className="space-y-3 pt-4 border-t"
                          initial={{ opacity: 0, y: 20 }}
                          whileInView={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.5, delay: 0.8 }}
                          viewport={{ once: true }}
                        >
                          <motion.div
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                          >
                            <Button 
                              className="w-full bg-primary hover:bg-secondary"
                              size="sm"
                            >
                              Book at {location.name}
                            </Button>
                          </motion.div>
                          <div className="grid grid-cols-2 gap-2">
                            <motion.div
                              whileHover={{ scale: 1.02 }}
                              whileTap={{ scale: 0.98 }}
                            >
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className="border-primary text-primary hover:bg-primary hover:text-white"
                              >
                                <Phone className="h-4 w-4 mr-1" />
                                Call
                              </Button>
                            </motion.div>
                            <motion.div
                              whileHover={{ scale: 1.02 }}
                              whileTap={{ scale: 0.98 }}
                            >
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="border-primary text-primary hover:bg-primary hover:text-white"
                              >
                                <Navigation className="h-4 w-4 mr-1" />
                                Directions
                              </Button>
                            </motion.div>
                          </div>
                        </motion.div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  {/* Map */}
                  <motion.div
                    initial={{ opacity: 0, x: 30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.7, delay: 0.6 }}
                    viewport={{ once: true }}
                    whileHover={{ y: -5 }}
                  >
                    <Card className="bg-white hover:shadow-xl transition-all duration-300 flex flex-col h-[500px]">
                      <CardContent className="p-0 flex-1 flex">
                        <div className="relative w-full flex-1 min-h-[460px]">
                          <iframe
                            src={location.mapEmbed}
                            width="100%"
                            height="100%"
                            style={{ border: 0, minHeight: '460px' }}
                            allowFullScreen
                            loading="lazy"
                            referrerPolicy="no-referrer-when-downgrade"
                            className="absolute inset-0 w-full h-full rounded-lg"
                          ></iframe>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              </TabsContent>
            ))}
          </Tabs>
        </motion.div>

        {/* CTA Section */}
        <motion.div 
          className="mt-16 text-center bg-white rounded-2xl p-8 shadow-lg"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <motion.h3 
            className="text-2xl font-bold text-gray-900 mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            viewport={{ once: true }}
          >
            Can't Decide Which Location?
          </motion.h3>
          <motion.p 
            className="text-gray-600 mb-6 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            viewport={{ once: true }}
          >
            All our locations offer the same exceptional care and comprehensive services. 
            Choose the one most convenient for you, or call us to discuss which location 
            might be best for your specific needs.
          </motion.p>
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            viewport={{ once: true }}
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button size="lg" className="bg-primary hover:bg-secondary">
                Book at Any Location
              </Button>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white">
                Call (778) 340-2897
              </Button>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}