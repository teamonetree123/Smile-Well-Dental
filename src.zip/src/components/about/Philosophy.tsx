import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { CheckCircle } from 'lucide-react';

export function Philosophy() {
  const philosophyPoints = [
    'Prevention first: cleanings, gum health, remineralization, sealants',
    'Conservative, tooth-preserving restorative care',
    'Whole-smile planning: bite, jaw joints (TMJ), function, and aesthetics',
    'Modern tech used thoughtfully—digital X-rays, 3D scanning, intraoral cameras',
    'Comfort and safety: gentle anesthesia, sedation options, strict sterilization'
  ];

  const differentiators = [
    'Comprehensive care under one roof: preventive, general, restorative, implants, orthodontics, cosmetic, emergency',
    'Flexible scheduling and clear fees—no surprise billing',
    'Direct insurance billing and help maximizing benefits',
    'Accessible, family-friendly environment'
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
      {/* Philosophy Section */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="mb-16"
      >
        <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center pb-8">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <div className="text-center mb-4">
                <h2 className="mb-0 font-[Inter] text-[36px] font-bold">Our Philosophy</h2>
              </div>
            </motion.div>
            <motion.p 
              className="text-lg max-w-3xl mx-auto font-body"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
            >
              Great dentistry starts with prevention and clear communication. We prioritize conservative treatment, long-term oral health, and transparent options—so you always know the "why," the "how," and the cost before we begin.
            </motion.p>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {philosophyPoints.map((point, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.6 + (index * 0.1) }}
                  viewport={{ once: true }}
                  className="flex items-start space-x-3 p-4 rounded-lg bg-primary/5 border border-primary/10 hover:bg-primary/10 transition-colors duration-300"
                >
                  <CheckCircle className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                  <p className="text-sm leading-relaxed font-body">{point}</p>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* What Makes Us Different */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        viewport={{ once: true }}
      >
        <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center pb-8">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <div className="text-center mb-4">
                <h2 className="mb-0 font-[Inter] text-[36px] font-bold">What Makes Us Different</h2>
              </div>
            </motion.div>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              {differentiators.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 0.6 + (index * 0.1) }}
                  viewport={{ once: true }}
                  className="flex items-start space-x-4 p-6 rounded-lg bg-gradient-to-br from-secondary/5 to-primary/5 border border-secondary/10 hover:from-secondary/10 hover:to-primary/10 transition-all duration-300"
                >
                  <div className="w-3 h-3 bg-secondary rounded-full mt-2 flex-shrink-0" />
                  <p className="leading-relaxed font-body">{item}</p>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}