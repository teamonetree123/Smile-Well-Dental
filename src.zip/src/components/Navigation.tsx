'use client';

import Link from 'next/link';
import { Button } from './ui/button';
import { ArrowLeft, Home } from 'lucide-react';

interface NavigationProps {
  showBackButton?: boolean;
  backText?: string;
  backHref?: string;
}

export function Navigation({ 
  showBackButton = false, 
  backText = 'Back to Home',
  backHref = '/'
}: NavigationProps) {
  if (!showBackButton) return null;

  return (
    <div className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <Link href={backHref}>
          <Button variant="ghost" className="text-gray-600 hover:text-primary">
            <ArrowLeft className="h-4 w-4 mr-2" />
            {backText}
          </Button>
        </Link>
      </div>
    </div>
  );
}