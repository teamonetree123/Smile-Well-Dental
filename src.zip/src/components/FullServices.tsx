import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from './ui/carousel';
import { 
  User, 
  Activity, 
  Scissors, 
  Wrench,
  Shield,
  Sparkles,
  AlertCircle,
  Zap,
  RefreshCw,
  Heart
} from 'lucide-react';
import { motion } from 'motion/react';
import Autoplay from "embla-carousel-autoplay";

export function FullServices() {
  const services = [
    {
      icon: User,
      title: 'General Dentistry',
      description: 'Comprehensive oral health care including TMJ treatment, routine checkups, and preventive care to maintain your overall dental health.',
      gradient: 'from-primary/10 to-primary/5'
    },
    {
      icon: Activity,
      title: 'Endodontics',
      description: 'Specialized root canal therapy to save infected or damaged teeth, preserving your natural smile with advanced techniques.',
      gradient: 'from-secondary/10 to-secondary/5'
    },
    {
      icon: Scissors,
      title: 'Periodontics',
      description: 'Expert gum surgery and periodontal treatments to restore gum health and prevent tooth loss from gum disease.',
      gradient: 'from-accent/10 to-accent/5'
    },
    {
      icon: Wrench,
      title: 'Dental Implants',
      description: 'State-of-the-art dental implants to replace missing teeth with natural-looking, permanent solutions that restore function and confidence.',
      gradient: 'from-primary/10 to-primary/5'
    },
    {
      icon: Heart,
      title: 'Sedation Dentistry',
      description: 'Comfortable dental care with various sedation options to help anxious patients receive treatment in a relaxed, stress-free environment.',
      gradient: 'from-secondary/10 to-secondary/5'
    },
    {
      icon: Shield,
      title: 'Preventive Dentistry',
      description: 'Teeth cleaning, remineralization treatments, and custom sport guards to protect and maintain your oral health.',
      gradient: 'from-accent/10 to-accent/5'
    },
    {
      icon: Sparkles,
      title: 'Cosmetic Dentistry',
      description: 'Transform your smile with porcelain dental veneers, professional teeth whitening, and dental Botox for a radiant appearance.',
      gradient: 'from-primary/10 to-primary/5'
    },
    {
      icon: AlertCircle,
      title: 'Emergency Dentistry',
      description: 'Immediate dental care for urgent situations including severe pain, trauma, and dental emergencies to restore comfort quickly.',
      gradient: 'from-secondary/10 to-secondary/5'
    },
    {
      icon: Zap,
      title: 'Orthodontics',
      description: 'Comprehensive teeth straightening with braces, Invisalign, surgical orthodontics, and Twin Block appliances for perfect alignment.',
      gradient: 'from-accent/10 to-accent/5'
    },
    {
      icon: RefreshCw,
      title: 'Restorative Dentistry',
      description: 'Complete restoration services including dental fillings, inlays and onlays, crowns, composite fillings, dentures, and bridges.',
      gradient: 'from-primary/10 to-primary/5'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <motion.h2 
            className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            A Full Range of Services in Smile Well Dental
          </motion.h2>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mb-6"></div>
          </motion.div>
          
          <motion.p 
            className="text-gray-600 text-lg leading-relaxed max-w-3xl mx-auto mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            viewport={{ once: true }}
          >
            At Smile Well Dental, we specialize in enhancing your natural beauty through our 
            premium aesthetic services. Discover how our tailored treatments can give you 
            the smile of your dreams.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            viewport={{ once: true }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button 
              size="lg" 
              className="bg-primary hover:bg-secondary transition-all duration-300 px-8 shadow-lg"
            >
              Book Your Consultation
            </Button>
          </motion.div>
        </motion.div>

        {/* Services Carousel */}
        <motion.div 
          className="max-w-6xl mx-auto"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          viewport={{ once: true }}
        >
          <Carousel
            plugins={[
              Autoplay({
                delay: 4000,
                stopOnInteraction: true,
                stopOnMouseEnter: true,
              }),
            ]}
            opts={{
              align: "start",
              loop: true,
            }}
            className="w-full"
          >
            <CarouselContent className="-ml-2 md:-ml-4">
              {services.map((service, index) => (
                <CarouselItem key={index} className="pl-2 md:pl-4 basis-full sm:basis-1/2 lg:basis-1/3">
                  <div className="h-full">
                    <Card className={`h-full hover:shadow-2xl transition-all duration-300 bg-gradient-to-br ${service.gradient} border-0 shadow-lg overflow-hidden group`}>
                      <CardContent className="p-6 h-full flex flex-col relative min-h-[320px]">
                        {/* Background decoration */}
                        <div className="absolute top-0 right-0 w-16 h-16 bg-white/10 rounded-full -translate-y-4 translate-x-4 group-hover:scale-110 transition-transform duration-300" />
                        
                        {/* Icon */}
                        <div className="w-14 h-14 bg-white/80 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-4 shadow-sm relative z-10 group-hover:bg-white/90 transition-colors duration-300">
                          <service.icon className="h-7 w-7 text-primary group-hover:text-secondary transition-colors duration-300" />
                        </div>
                        
                        {/* Content */}
                        <div className="flex-1 relative z-10">
                          <h4 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-primary transition-colors duration-300">
                            {service.title}
                          </h4>
                          
                          <p className="text-gray-700 leading-relaxed text-sm">
                            {service.description}
                          </p>
                        </div>

                        {/* Hover indicator */}
                        <div className="absolute bottom-4 right-4 w-2 h-2 bg-primary rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                      </CardContent>
                    </Card>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="hidden sm:flex -left-12" />
            <CarouselNext className="hidden sm:flex -right-12" />
          </Carousel>
        </motion.div>

        {/* Bottom CTA */}
        <motion.div 
          className="text-center mt-16 p-8 bg-white rounded-3xl shadow-lg"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.4 }}
          viewport={{ once: true }}
        >
          <motion.h3 
            className="text-2xl font-bold text-gray-900 mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.5 }}
            viewport={{ once: true }}
          >
            Transform Your Smile with Comprehensive Care
          </motion.h3>
          
          <motion.p 
            className="text-gray-600 mb-8 max-w-2xl mx-auto text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.6 }}
            viewport={{ once: true }}
          >
            From routine cleanings to complete smile makeovers, our comprehensive range of services 
            ensures all your dental needs are met under one roof with the highest standards of care.
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 1.7 }}
            viewport={{ once: true }}
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                className="bg-primary hover:bg-secondary transition-all duration-300 px-8 shadow-lg"
              >
                Schedule Your Visit
              </Button>
            </motion.div>
            
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-white transition-all duration-300 px-8 shadow-sm"
              >
                Call (778) 340-2897
              </Button>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}