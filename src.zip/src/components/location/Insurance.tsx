import { motion } from 'motion/react';
import { Shield, CreditCard, DollarSign, FileText } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';

const insuranceProviders = [
  'Manulife',
  'Sun Life',
  'Great-West Life',
  'Blue Cross',
  'Desjardins',
  'Industrial Alliance',
  'Pacific Blue Cross',
  'Chambers of Commerce',
  'Green Shield',
  'Johnson Inc.',
  'Maximum Benefit',
  'ClaimSecure'
];

const paymentOptions = [
  {
    icon: CreditCard,
    title: 'Credit & Debit Cards',
    description: 'We accept all major credit and debit cards',
    details: ['Visa', 'Mastercard', 'American Express', 'Interac']
  },
  {
    icon: DollarSign,
    title: 'Flexible Payment Plans',
    description: 'Interest-free payment plans available',
    details: ['0% interest options', 'Monthly payment plans', 'Treatment financing', 'No credit checks required']
  },
  {
    icon: FileText,
    title: 'Direct Billing',
    description: 'We bill your insurance directly',
    details: ['No upfront payment', 'Instant verification', 'Maximum coverage utilization', 'Hassle-free claims']
  }
];

export function Insurance() {
  return (
    <section className="py-20 bg-gray-50/50">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <h2 className="font-heading text-gray-900">
              Insurance & <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Payment Options
              </span>
            </h2>
          </div>
          <p className="text-lg text-gray-700 font-body max-w-3xl mx-auto">
            We work with most insurance providers and offer flexible payment options to make 
            quality dental care accessible and affordable for everyone.
          </p>
        </motion.div>

        {/* Payment Options */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {paymentOptions.map((option, index) => {
            const Icon = option.icon;
            return (
              <motion.div
                key={option.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="h-full border-gray-200 hover:shadow-xl transition-all duration-300 hover:border-primary/30">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="font-body font-medium text-gray-900">{option.title}</h3>
                    </div>
                    <p className="text-gray-600 font-body text-sm mb-4">{option.description}</p>
                    <ul className="space-y-2">
                      {option.details.map((detail, detailIndex) => (
                        <li key={detailIndex} className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full flex-shrink-0"></div>
                          <span className="text-gray-600 font-body text-sm">{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Insurance Providers */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <Card className="border-gray-200">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <h3 className="font-body font-medium text-gray-900 mb-4">
                  Accepted Insurance Providers
                </h3>
                <p className="text-gray-600 font-body">
                  We work with most major insurance providers in Canada. If you don't see your provider listed, 
                  please contact us to verify coverage.
                </p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
                {insuranceProviders.map((provider, index) => (
                  <motion.div
                    key={provider}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.4, delay: index * 0.05 }}
                    viewport={{ once: true }}
                  >
                    <Badge 
                      className="w-full justify-center bg-white text-gray-700 border-gray-300 hover:bg-primary/5 hover:border-primary/30 transition-all duration-200 font-body py-2"
                    >
                      {provider}
                    </Badge>
                  </motion.div>
                ))}
              </div>


            </CardContent>
          </Card>
        </motion.div>

        {/* CDCP Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          viewport={{ once: true }}
          className="mt-12"
        >
          <Card className="border-green-200 bg-green-50/50">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="font-body font-medium text-gray-900 mb-4">
                Canadian Dental Care Plan (CDCP) Accepted
              </h3>
              <p className="text-gray-700 font-body mb-6 max-w-2xl mx-auto">
                We're proud to accept the Canadian Dental Care Plan, making quality dental care 
                more accessible to eligible Canadians. Contact us to learn more about your CDCP benefits.
              </p>
              <Badge className="bg-green-100 text-green-800 border-green-200 font-body px-4 py-2">
                Government Program Accepted
              </Badge>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}