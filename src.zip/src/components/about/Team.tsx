import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Award } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import doctorShin from 'figma:asset/a631e5c693388ece808143d8ec01f571fce9e452.png';
import doctorKwack from 'figma:asset/afe09f1357c62d3a79ca9df01dcc33c37f635c71.png';
import doctorJeong from 'figma:asset/9bd3fa17a1c814eb6f79a231be0cd03bc0c511c2.png';
import doctorZhang from 'figma:asset/4eb6a1e9577b6050a5737c4e836503a44b562233.png';

export function Team() {
  const doctors = [
    {
      name: 'Dr. Shin',
      credentials: 'DDS, MSc',
      specialty: 'Lead Dentist & Practice Owner',
      description: 'With over 15 years of experience, Dr. Shin specializes in comprehensive dental care and aesthetic dentistry, ensuring every patient receives exceptional treatment.',
      languages: ['English', 'Korean'],
      focus: ['Comprehensive Care', 'Aesthetic Dentistry', 'Practice Leadership'],
      image: doctorShin
    },
    {
      name: 'Dr. Zhang',
      credentials: 'DDS, PhD',
      specialty: 'Orthodontist & Implant Specialist',
      description: 'Dr. Zhang brings expertise in orthodontics and dental implants, combining advanced techniques with compassionate care for optimal patient outcomes.',
      languages: ['English', 'Mandarin'],
      focus: ['Orthodontics', 'Dental Implants', 'Advanced Techniques'],
      image: doctorZhang
    },
    {
      name: 'Dr. Jeong',
      credentials: 'DDS, MSc',
      specialty: 'Periodontal Specialist',
      description: 'Specializing in gum health and periodontal treatment, Dr. Jeong helps patients maintain healthy foundations for their beautiful smiles.',
      languages: ['English', 'Korean'],
      focus: ['Periodontal Care', 'Gum Health', 'Preventive Treatment'],
      image: doctorJeong
    },
    {
      name: 'Dr. Kwack',
      credentials: 'DDS, MSc',
      specialty: 'Cosmetic & Restorative Dentist',
      description: 'Dr. Kwack excels in cosmetic and restorative procedures, transforming smiles with artistic precision and cutting-edge techniques.',
      languages: ['English'],
      focus: ['Cosmetic Dentistry', 'Restorative Care', 'Smile Transformation'],
      image: doctorKwack
    }
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="text-center mb-12"
      >
        <motion.h2 
          className="mb-0 font-[Inter] text-[36px] font-bold"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
        >
          Meet Our Expert Team
        </motion.h2>
        <motion.p 
          className="text-xl text-gray-600 max-w-3xl mx-auto font-body"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
        >
          Our experienced team of dental professionals is committed to providing exceptional, personalized care for every patient.
        </motion.p>
      </motion.div>

      <div className="grid lg:grid-cols-2 xl:grid-cols-4 gap-8">
        {doctors.map((doctor, index) => (
          <motion.div
            key={doctor.name}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 + (index * 0.1) }}
            viewport={{ once: true }}
          >
            <Card className="h-full border-0 shadow-xl bg-white/90 backdrop-blur-sm hover:shadow-2xl transition-all duration-300 group">
              <CardHeader className="text-center pb-4">
                <motion.div 
                  className="w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden shadow-lg group-hover:scale-105 transition-transform duration-300"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.3 }}
                >
                  <ImageWithFallback
                    src={doctor.image}
                    alt={`${doctor.name} - ${doctor.specialty}`}
                    className="w-full h-full object-cover"
                  />
                </motion.div>
                <CardTitle className="mb-1">{doctor.name}</CardTitle>
                <p className="text-sm text-primary font-medium font-body mb-2">{doctor.credentials}</p>
                <Badge variant="secondary" className="text-sm px-3 py-1 font-body">
                  {doctor.specialty}
                </Badge>
              </CardHeader>
              <CardContent className="pt-0">
                <motion.p 
                  className="text-sm leading-relaxed mb-4 font-body"
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  transition={{ duration: 0.6, delay: 0.8 + (index * 0.1) }}
                  viewport={{ once: true }}
                >
                  {doctor.description}
                </motion.p>
                
                <div className="space-y-3">
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 1.0 + (index * 0.1) }}
                    viewport={{ once: true }}
                  >
                    <h6 className="text-sm font-semibold text-gray-700 mb-2 font-body">Languages:</h6>
                    <div className="flex flex-wrap gap-1">
                      {doctor.languages.map((lang) => (
                        <Badge key={lang} variant="outline" className="text-xs font-body">
                          {lang}
                        </Badge>
                      ))}
                    </div>
                  </motion.div>
                  
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 1.2 + (index * 0.1) }}
                    viewport={{ once: true }}
                  >
                    <h6 className="text-sm font-semibold text-gray-700 mb-2 font-body">Focus Areas:</h6>
                    <div className="flex flex-wrap gap-1">
                      {doctor.focus.map((area) => (
                        <Badge key={area} className="text-xs bg-primary/10 text-primary border-primary/20 font-body">
                          {area}
                        </Badge>
                      ))}
                    </div>
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Team CTA */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.4 }}
        viewport={{ once: true }}
        className="text-center mt-12"
      >
        <Card className="border-0 shadow-lg bg-gradient-to-r from-primary/5 to-secondary/5 p-8">
          <CardContent className="p-0">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              viewport={{ once: true }}
            >
              <Award className="h-12 w-12 text-primary mx-auto mb-4" />
              <p className="text-lg text-gray-600 mb-6 max-w-2xl mx-auto font-body">
                Our experienced team of dental professionals is dedicated to providing 
                exceptional care with the latest techniques and technologies. Each doctor brings 
                years of expertise and a commitment to patient-centered care.
              </p>
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}