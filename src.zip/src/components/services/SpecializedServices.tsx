'use client';

import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { motion } from 'motion/react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { 
  Heart,
  Target,
  Eye,
  Gem,
  Activity,
  HeadphonesIcon,
  CheckCircle
} from 'lucide-react';

export function SpecializedServices() {
  const specializedServices = [
    {
      title: "Restorative Dentistry",
      icon: Heart,
      color: "bg-accent",
      description: "When teeth are worn, broken, or missing, we rebuild function and appearance so you can chew comfortably and smile with confidence.",
      services: [
        "Crowns and bridges for strength and stability",
        "Dental implants to replace single or multiple teeth",
        "Dentures (full, partial, and implant-supported)",
        "Smile rehabilitation for complex cases"
      ]
    },
    {
      title: "Dental Implants",
      icon: Target,
      color: "bg-gradient-to-r from-primary to-secondary",
      description: "Implants replace the root of a missing tooth and support a crown, bridge, or denture. They help prevent bone loss, protect neighbouring teeth, and look and feel remarkably natural.",
      services: [
        "Single-tooth implants",
        "Multi-tooth and full-arch solutions",
        "Guided planning and coordination with specialists when indicated"
      ]
    },
    {
      title: "Orthodontics (Braces & Invisalign®)",
      icon: Eye,
      color: "bg-gradient-to-r from-secondary to-accent",
      description: "Straighter teeth are easier to clean and kinder to your bite and jaw joints. We offer options for teens and adults to align teeth discreetly and predictably.",
      services: [
        "Traditional braces for comprehensive control",
        "Invisalign® clear aligners for a low-profile look",
        "Early interceptive guidance for growing smiles"
      ]
    },
    {
      title: "Cosmetic Dentistry",
      icon: Gem,
      color: "bg-gradient-to-r from-accent to-primary",
      description: "Subtle, natural, camera-ready. We enhance without over-doing, always prioritizing tooth health and long-term function.",
      services: [
        "Porcelain veneers and conservative bonding",
        "Professional teeth whitening (in-office or take-home)",
        "Gum contouring and smile-balance refinements"
      ]
    },
    {
      title: "TMJ Treatment",
      icon: Activity,
      color: "bg-gradient-to-r from-red-500 to-orange-500",
      description: "Jaw pain, clicking, headaches, and muscle fatigue can stem from a stressed bite or clenching. After a careful evaluation, we create a plan to reduce strain and protect your teeth.",
      services: [
        "Precision night guards and bite therapy",
        "Behavioral and at-home strategies to relieve muscle tension",
        "Referral collaboration for complex TMJ disorders when needed"
      ]
    },
    {
      title: "Sedation & Comfort Options",
      icon: HeadphonesIcon,
      color: "bg-gradient-to-r from-blue-500 to-purple-500",
      description: "Your comfort matters. For anxious patients or lengthy procedures, we offer options to help you relax safely while receiving the care you need.",
      services: [
        "Local anesthesia with gentle technique",
        "Nitrous oxide (laughing gas)",
        "Oral sedation for suitable cases"
      ]
    }
  ];

  return (
    <div className="py-20 bg-gray-50/30">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl mb-6 font-heading text-gray-900">
            Advanced <span className="text-secondary">Specialty Care</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto font-body">
            Comprehensive restorative, cosmetic, and specialized treatments for complete smile transformation.
          </p>
        </motion.div>

        {/* Specialized Services Image Section */}
        <motion.div 
          className="grid lg:grid-cols-2 gap-12 items-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="relative rounded-2xl overflow-hidden shadow-xl">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1643216503879-b2c604ce6cf2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBpbXBsYW50JTIwc3VyZ2VyeXxlbnwxfHx8fDE3NTYzMDI3ODV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Advanced dental implant procedure"
              className="w-full h-[400px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-secondary/10 to-accent/10"></div>
          </div>
          <div className="relative rounded-2xl overflow-hidden shadow-xl">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1655807946138-811bb2340d34?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWV0aCUyMHdoaXRlbmluZyUyMGRlbnRhbHxlbnwxfHx8fDE3NTYzMDI3ODl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Professional teeth whitening treatment"
              className="w-full h-[400px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-accent/10 to-secondary/10"></div>
          </div>
        </motion.div>

        <div className="grid gap-8 lg:gap-12">
          {specializedServices.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="overflow-hidden border-2 border-gray-100 hover:border-secondary/30 transition-all duration-300 hover:shadow-lg">
                <CardHeader className="pb-4">
                  <div className="flex items-start gap-4">
                    <div className={`p-3 rounded-xl ${service.color} text-white shadow-lg flex-shrink-0`}>
                      <service.icon className="h-6 w-6" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-xl sm:text-2xl font-heading text-gray-900 mb-3">
                        {service.title}
                      </CardTitle>
                      <p className="text-gray-600 font-body leading-relaxed">
                        {service.description}
                      </p>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="pt-0">
                  <div className="grid sm:grid-cols-2 gap-3">
                    {service.services.map((item, itemIndex) => (
                      <div key={itemIndex} className="flex items-start gap-3">
                        <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-gray-700 font-body">{item}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}