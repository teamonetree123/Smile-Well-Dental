import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Wrench, 
  User, 
  ThumbsUp, 
  MapPin,
  CheckCircle,
  Star
} from 'lucide-react';
import { motion } from 'motion/react';

export function WhyChoose() {
  const features = [
    {
      icon: Wrench,
      title: 'Preventive Treatment',
      description: 'Smile Well Dental makes an effort for any situation to save your natural teeth and to prevent any oral diseases.',
      highlight: 'Save Natural Teeth'
    },
    {
      icon: User,
      title: 'Personalized Treatment',
      description: 'Your teeth were gone? Don\'t worry! At Smile Well Dental, we offer personalized solutions including our specialty, "Safe and Economical (SAFECO) Implants", so you can regain your confidence with beautiful artificial teeth.',
      highlight: 'SAFECO Implants'
    },
    {
      icon: ThumbsUp,
      title: 'State-of-the-Art Dentistry',
      description: 'You\'re not happy with your smile? Don\'t worry! At Smile Well Dental we can offer state-of-the-art orthodontic solutions like Invisalign, so you can regain your confidence with beautifully aligned teeth.',
      highlight: 'Invisalign Available'
    },
    {
      icon: MapPin,
      title: 'Conveniently Located in North Vancouver',
      description: 'Located in the heart of the beautiful North Shore, our office can be easily accessed from all the areas of Greater Vancouver.',
      highlight: 'Heart of North Shore'
    }
  ];

  const stats = [
    { number: '15+', label: 'Years Experience' },
    { number: '2500+', label: 'Happy Patients' },
    { number: '3', label: 'Clinic Locations' },
    { number: '100%', label: 'Satisfaction Rate' }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-white relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute inset-0 opacity-40">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-secondary/5 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Centered Header Section */}
        <div className="text-center mb-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            viewport={{ once: true }}
          >
            <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20 mb-6">
              Why Choose Us
            </Badge>
          </motion.div>

          <motion.h2 
            className="text-3xl lg:text-4xl font-bold text-gray-900 mb-8 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, delay: 0.05 }}
            viewport={{ once: true }}
          >
            Why Choose Smile Well Dental as your Dental Clinic in British Columbia
          </motion.h2>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.2, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <div className="w-24 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mb-8"></div>
          </motion.div>
          
          <motion.p 
            className="text-gray-600 text-lg leading-relaxed max-w-3xl mx-auto mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, delay: 0.15 }}
            viewport={{ once: true }}
          >
            There are many key reasons why you should make us the dental clinic you go to for regular dental appointments and emergency situations:
          </motion.p>

          {/* Stats Section */}
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
            viewport={{ once: true }}
          >
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, delay: 0.25 + (index * 0.05) }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05 }}
              >
                <div className="text-3xl lg:text-4xl font-bold text-primary mb-2">{stat.number}</div>
                <div className="text-gray-600 text-sm font-medium">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.35 + (index * 0.05) }}
              viewport={{ once: true }}
              whileHover={{ y: -8, scale: 1.02 }}
              className="group"
            >
              <Card className="h-full hover:shadow-2xl transition-all duration-500 bg-white border border-gray-200 group-hover:border-primary/20 relative overflow-hidden">
                {/* Card Background Decoration */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-primary/5 to-secondary/5 rounded-full -translate-y-8 translate-x-8 group-hover:scale-110 transition-transform duration-500"></div>
                
                <CardContent className="p-8 relative z-10">
                  <div className="flex items-start space-x-6">
                    <motion.div 
                      className="flex-shrink-0 w-16 h-16 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl flex items-center justify-center group-hover:from-primary/20 group-hover:to-secondary/20 transition-all duration-300"
                      initial={{ scale: 0, rotate: -180 }}
                      whileInView={{ scale: 1, rotate: 0 }}
                      transition={{ duration: 0.3, delay: 0.4 + (index * 0.05) }}
                      viewport={{ once: true }}
                    >
                      <feature.icon className="h-8 w-8 text-primary group-hover:scale-110 transition-transform duration-300" />
                    </motion.div>
                    
                    <div className="flex-1">
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2, delay: 0.45 + (index * 0.05) }}
                        viewport={{ once: true }}
                      >
                        <Badge 
                          variant="outline" 
                          className="border-primary/30 text-primary text-xs mb-3"
                        >
                          <Star className="h-3 w-3 mr-1" />
                          {feature.highlight}
                        </Badge>
                      </motion.div>
                      
                      <motion.h4 
                        className="text-xl font-bold text-gray-900 mb-4 group-hover:text-primary transition-colors duration-300"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2, delay: 0.5 + (index * 0.05) }}
                        viewport={{ once: true }}
                      >
                        {feature.title}
                      </motion.h4>
                      
                      <motion.p 
                        className="text-gray-600 leading-relaxed mb-4"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2, delay: 0.55 + (index * 0.05) }}
                        viewport={{ once: true }}
                      >
                        {feature.description}
                      </motion.p>

                      <motion.div
                        className="flex items-center text-primary text-sm font-medium"
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.2, delay: 0.6 + (index * 0.05) }}
                        viewport={{ once: true }}
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Professional Excellence
                      </motion.div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA Section */}
        <motion.div 
          className="text-center bg-gradient-to-r from-primary/5 to-secondary/5 rounded-3xl p-12 shadow-lg border border-primary/10"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.8 }}
          viewport={{ once: true }}
        >
          <motion.h3 
            className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, delay: 0.85 }}
            viewport={{ once: true }}
          >
            Ready to Experience Exceptional Dental Care?
          </motion.h3>
          
          <motion.p 
            className="text-gray-600 mb-8 max-w-2xl mx-auto text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, delay: 0.9 }}
            viewport={{ once: true }}
          >
            Join thousands of satisfied patients who trust Smile Well Dental for their oral health needs. 
            Book your consultation today and discover the difference.
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, delay: 0.95 }}
            viewport={{ once: true }}
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                className="bg-primary hover:bg-secondary transition-colors duration-300 px-10 py-6 text-lg shadow-lg"
              >
                Book Your Consultation
              </Button>
            </motion.div>
            
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-white transition-colors duration-300 px-10 py-6 text-lg shadow-sm"
              >
                Call (778) 340-2897
              </Button>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}