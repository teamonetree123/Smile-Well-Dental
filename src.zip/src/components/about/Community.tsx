import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Users, Heart, School, Award } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export function Community() {
  const communityInitiatives = [
    {
      icon: School,
      title: 'School Programs',
      description: 'Educational visits to local schools teaching children about oral health and prevention.',
      color: 'text-green-600'
    },
    {
      icon: Heart,
      title: 'Senior Care',
      description: 'Special programs and community outreach for senior citizens in care facilities.',
      color: 'text-red-500'
    },
    {
      icon: Award,
      title: 'Community Events',
      description: 'Active participation in local health fairs and community wellness initiatives.',
      color: 'text-blue-600'
    }
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="text-center mb-12"
      >
        <motion.h2 
          className="mb-0 font-[Inter] text-[36px] font-bold"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
        >
          Community & Values
        </motion.h2>
        <motion.p 
          className="text-xl text-gray-600 max-w-3xl mx-auto font-body"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
        >
          We're proudly local, supporting dental health initiatives and community outreach throughout BC.
        </motion.p>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-8 items-center mb-12">
        {/* Community Values */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
        >
          <Card className="border-0 shadow-xl bg-gradient-to-br from-primary/5 to-secondary/5 backdrop-blur-sm h-full">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3 mb-4">
                <motion.div
                  className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center"
                  whileHover={{ scale: 1.1, rotate: 360 }}
                  transition={{ duration: 0.6 }}
                >
                  <Users className="h-6 w-6 text-white" />
                </motion.div>
                <span>Our Community Impact</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <motion.p 
                className="text-lg leading-relaxed mb-6 font-body"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.8 }}
                viewport={{ once: true }}
              >
                We're proudly local. Our team supports school dental health initiatives and community outreach because preventive education makes a real difference—especially for kids and seniors.
              </motion.p>

              <div className="space-y-4">
                {communityInitiatives.map((initiative, index) => (
                  <motion.div
                    key={initiative.title}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.6, delay: 1.0 + (index * 0.1) }}
                    viewport={{ once: true }}
                    className="flex items-start space-x-3 p-3 rounded-lg bg-white/50 hover:bg-white/80 transition-all duration-300"
                  >
                    <initiative.icon className={`h-5 w-5 ${initiative.color} mt-1 flex-shrink-0`} />
                    <div>
                      <h6 className="font-semibold text-gray-900 font-body">{initiative.title}</h6>
                      <p className="text-sm text-gray-600 font-body">{initiative.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Community Image */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          viewport={{ once: true }}
          className="relative"
        >
          <div className="relative rounded-2xl overflow-hidden shadow-2xl">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1559757175-0eb30cd8c063?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tdW5pdHklMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc1NjMwMjc4NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Community dental health outreach and education"
              className="w-full h-[400px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent"></div>
            
            {/* Floating Stats */}
            <motion.div 
              className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg"
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 1.2 }}
              viewport={{ once: true }}
            >
              <div className="text-2xl font-bold text-primary">500+</div>
              <div className="text-xs text-gray-600 font-body">Students Educated</div>
            </motion.div>
            
            <motion.div 
              className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg"
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 1.4 }}
              viewport={{ once: true }}
            >
              <div className="text-2xl font-bold text-secondary">15+</div>
              <div className="text-xs text-gray-600 font-body">Years Community Service</div>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Community Values Statement */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.4 }}
        viewport={{ once: true }}
      >
        <Card className="border-0 shadow-lg bg-gradient-to-r from-accent/10 to-primary/10 text-center p-8">
          <CardContent className="p-0">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              viewport={{ once: true }}
            >
              <Heart className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-gray-900 mb-4">Building Healthier Communities</h3>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto font-body">
                When we invest in community dental health education, we're not just preventing cavities—we're building stronger, healthier communities for everyone.
              </p>
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}