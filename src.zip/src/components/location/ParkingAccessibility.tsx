import { motion } from 'motion/react';
import { Badge } from '../ui/badge';

export function ParkingAccessibility() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="mb-6 font-heading text-gray-900">
            <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent text-[36px] font-bold">
              Parking & Accessibility
            </span>
          </h2>
          <p className="text-lg text-gray-700 font-body max-w-3xl mx-auto">
            We've designed our facilities to be fully accessible and convenient for all patients, 
            with comprehensive parking and accessibility features at every location.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
            className="text-center"
          >

            <h3 className="font-body font-medium text-gray-900 mb-3">Free Parking</h3>
            <p className="text-gray-600 font-body text-sm mb-4">
              Complimentary parking available at all locations with convenient access to our clinics.
            </p>
            <Badge className="bg-green-100 text-green-800 border-green-200 font-body">
              All Locations
            </Badge>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-center"
          >

            <h3 className="font-body font-medium text-gray-900 mb-3">Wheelchair Access</h3>
            <p className="text-gray-600 font-body text-sm mb-4">
              Full wheelchair accessibility including ramp access, wide doorways, and accessible washrooms.
            </p>
            <Badge className="bg-blue-100 text-blue-800 border-blue-200 font-body">
              ADA Compliant
            </Badge>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            viewport={{ once: true }}
            className="text-center"
          >

            <h3 className="font-body font-medium text-gray-900 mb-3">Extended Hours</h3>
            <p className="text-gray-600 font-body text-sm mb-4">
              Evening and weekend appointments available to accommodate your busy schedule.
            </p>
            <Badge className="bg-purple-100 text-purple-800 border-purple-200 font-body">
              Flexible Timing
            </Badge>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
            className="text-center"
          >

            <h3 className="font-body font-medium text-gray-900 mb-3">Safe & Secure</h3>
            <p className="text-gray-600 font-body text-sm mb-4">
              Well-lit parking areas with security monitoring for your peace of mind.
            </p>
            <Badge className="bg-orange-100 text-orange-800 border-orange-200 font-body">
              24/7 Security
            </Badge>
          </motion.div>
        </div>

       
      </div>
    </section>
  );
}