import { motion } from 'motion/react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';

const emergencyServices = [
  'Severe toothache relief',
  'Broken or chipped teeth',
  'Lost fillings or crowns',
  'Dental trauma and injuries',
  'Swollen or bleeding gums',
  'Knocked-out teeth',
  'Abscessed teeth',
  'Lost or broken dentures'
];

const locations = [
  {
    name: 'North Vancouver',
    phone: '(778) 340-2897',
    after_hours: '(778) 340-2897'
  },
  {
    name: 'Surrey',
    phone: '(778) 877-3493',
    after_hours: '(778) 877-3493'
  },
  {
    name: 'Langley',
    phone: '(604) 546-2828',
    after_hours: '(604) 546-2828'
  }
];

export function EmergencyCare() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-heading text-gray-900 mb-6">
            <span className="bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent text-[36px]">
              Emergency Dental Care
            </span>
          </h2>
          <p className="text-lg text-gray-700 font-body max-w-3xl mx-auto">
            Dental emergencies can happen at any time. We provide same-day emergency appointments 
            and after-hours care to ensure you get the relief you need when you need it most.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Emergency Services */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="font-body font-medium text-gray-900 mb-6">We Treat These Emergencies</h3>
            <div className="grid sm:grid-cols-2 gap-3">
              {emergencyServices.map((service, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  viewport={{ once: true }}
                  className="flex items-center gap-2"
                >
                  <div className="w-2 h-2 bg-red-500 rounded-full flex-shrink-0"></div>
                  <span className="text-gray-700 font-body text-sm">{service}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Emergency Process */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="font-body font-medium text-gray-900 mb-6">How It Works</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-medium">
                  1
                </div>
                <div>
                  <h4 className="font-body font-medium text-gray-900 mb-1">Call Immediately</h4>
                  <p className="text-gray-600 font-body text-sm">
                    Contact your nearest location's emergency line for immediate assistance.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-medium">
                  2
                </div>
                <div>
                  <h4 className="font-body font-medium text-gray-900 mb-1">Quick Assessment</h4>
                  <p className="text-gray-600 font-body text-sm">
                    Our staff will assess your situation and provide immediate guidance.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-medium">
                  3
                </div>
                <div>
                  <h4 className="font-body font-medium text-gray-900 mb-1">Same-Day Treatment</h4>
                  <p className="text-gray-600 font-body text-sm">
                    We'll schedule you for the earliest available appointment, often same-day.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Emergency Contact Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <h3 className="font-body font-medium text-gray-900 text-center mb-8">
            Emergency Contact Numbers
          </h3>
          <div className="grid md:grid-cols-3 gap-6">
            {locations.map((location, index) => (
              <motion.div
                key={location.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 + (index * 0.1) }}
                viewport={{ once: true }}
              >
                <Card className="border-red-200 hover:shadow-xl transition-all duration-300">
                  <CardContent className="p-6 text-center">
                    <h4 className="font-body font-medium text-gray-900 mb-4">{location.name}</h4>
                    
                    <div className="space-y-3">
                      <div>
                        <Badge className="bg-green-100 text-green-800 border-green-200 font-body mb-2">
                          Emergency Line
                        </Badge>
                        <div>
                          <a 
                            href={`tel:${location.phone.replace(/[^0-9]/g, '')}`}
                            className="text-primary hover:text-secondary transition-colors font-body font-medium text-lg"
                          >
                            {location.phone}
                          </a>
                        </div>
                      </div>
                      
                      <div>
                        <Badge className="bg-orange-100 text-orange-800 border-orange-200 font-body mb-2">
                          After Hours
                        </Badge>
                        <div>
                          <a 
                            href={`tel:${location.after_hours.replace(/[^0-9]/g, '')}`}
                            className="text-gray-700 hover:text-primary transition-colors font-body font-medium"
                          >
                            {location.after_hours}
                          </a>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <Button 
            size="lg" 
            className="bg-red-600 hover:bg-red-700 text-white font-body px-8 py-4"
          >
            Call Emergency Line Now
          </Button>
          <p className="text-gray-600 font-body text-sm mt-4">
            Available 24/7 for dental emergencies
          </p>
        </motion.div>
      </div>
    </section>
  );
}