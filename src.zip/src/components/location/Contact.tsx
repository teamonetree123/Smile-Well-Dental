import { motion } from 'motion/react';
import { Phone, Mail, Clock, MapPin, Calendar } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';

const locations = [
  {
    name: 'North Vancouver',
    address: 'Suite #202, 814 15th St West',
    city: 'North Vancouver, BC V7M 1T2',
    phone: '(778) 340-2897',
    email: 'northvan@smilewelldental.ca',
    hours: 'Mon-Fri: 8:00 AM - 6:00 PM, Sat: 9:00 AM - 4:00 PM'
  },
  {
    name: 'Surrey',
    address: '15243 91 Ave #2',
    city: 'Surrey, BC V3R 8P8',
    phone: '(778) 877-3493',
    email: 'surrey@smilewelldental.ca',
    hours: 'Mon-Fri: 8:00 AM - 6:00 PM, Sat: 9:00 AM - 4:00 PM'
  },
  {
    name: 'Langley',
    address: 'A125 & A130 20487 65 Ave',
    city: 'Langley, BC V2Y 3J7',
    phone: '(604) 546-2828',
    email: 'langley@smilewelldental.ca',
    hours: 'Mon-Fri: 8:00 AM - 6:00 PM, Sat: 9:00 AM - 4:00 PM'
  }
];

export function Contact() {
  return (
    <section className="py-20 bg-gray-50/50">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="mb-6 font-heading text-gray-900">
            Ready to <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Schedule Your Visit?
            </span>
          </h2>
          <p className="text-lg text-gray-700 font-body max-w-3xl mx-auto">
            Contact your preferred location to book an appointment or ask any questions. 
            Our friendly staff is here to help you get the dental care you need.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {locations.map((location, index) => (
            <motion.div
              key={location.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full border-gray-200 hover:shadow-xl transition-all duration-300 hover:border-primary/30">
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <MapPin className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="font-body font-medium text-gray-900 mb-2">{location.name}</h3>
                    <div className="text-gray-600 font-body text-sm space-y-1">
                      <p>{location.address}</p>
                      <p>{location.city}</p>
                    </div>
                  </div>

                  <div className="space-y-4 mb-8">
                    <div className="flex items-center gap-3">
                      <Phone className="h-5 w-5 text-primary flex-shrink-0" />
                      <a 
                        href={`tel:${location.phone.replace(/[^0-9]/g, '')}`}
                        className="text-primary hover:text-secondary transition-colors font-body font-medium"
                      >
                        {location.phone}
                      </a>
                    </div>

                    <div className="flex items-center gap-3">
                      <Mail className="h-5 w-5 text-primary flex-shrink-0" />
                      <a 
                        href={`mailto:${location.email}`}
                        className="text-primary hover:text-secondary transition-colors font-body text-sm"
                      >
                        {location.email}
                      </a>
                    </div>

                    <div className="flex items-start gap-3">
                      <Clock className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <p className="text-gray-600 font-body text-sm">{location.hours}</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Button 
                      className="w-full bg-primary hover:bg-secondary text-white font-body"
                      size="lg"
                    >
                      <Calendar className="mr-2 h-4 w-4" />
                      Book Appointment
                    </Button>
                    <Button 
                      variant="outline"
                      className="w-full border-primary text-primary hover:bg-primary hover:text-white font-body"
                      size="lg"
                    >
                      <Phone className="mr-2 h-4 w-4" />
                      Call Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* General Contact Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <Card className="border-primary/20 bg-gradient-to-r from-primary/5 to-secondary/5">
            <CardContent className="p-8 text-center">
              <h3 className="font-body font-medium text-gray-900 mb-6">
                Questions? We're Here to Help
              </h3>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div>
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Phone className="h-6 w-6 text-primary" />
                  </div>
                  <h4 className="font-body font-medium text-gray-900 mb-2">Call Any Location</h4>
                  <p className="text-gray-600 font-body text-sm">
                    Speak directly with our friendly staff
                  </p>
                </div>
                
                <div>
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Mail className="h-6 w-6 text-primary" />
                  </div>
                  <h4 className="font-body font-medium text-gray-900 mb-2">Send an Email</h4>
                  <p className="text-gray-600 font-body text-sm">
                    Get answers to your questions
                  </p>
                </div>
                
                <div>
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Calendar className="h-6 w-6 text-primary" />
                  </div>
                  <h4 className="font-body font-medium text-gray-900 mb-2">Online Booking</h4>
                  <p className="text-gray-600 font-body text-sm">
                    Schedule appointments 24/7
                  </p>
                </div>
                
                <div>
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Clock className="h-6 w-6 text-primary" />
                  </div>
                  <h4 className="font-body font-medium text-gray-900 mb-2">Emergency Care</h4>
                  <p className="text-gray-600 font-body text-sm">
                    Same-day emergency appointments
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  className="bg-primary hover:bg-secondary text-white font-body px-8"
                >
                  <Calendar className="mr-2 h-5 w-5" />
                  Book Your Appointment Today
                </Button>
                <Button 
                  variant="outline"
                  size="lg" 
                  className="border-primary text-primary hover:bg-primary hover:text-white font-body px-8"
                >
                  <Phone className="mr-2 h-5 w-5" />
                  Call for Emergency Care
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}