'use client';

import { Button } from '../ui/button';
import { motion } from 'motion/react';
import { 
  Calendar,
  Phone
} from 'lucide-react';

export function Contact() {
  return (
    <div className="py-20">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Call to Action */}
        <motion.div 
          className="text-center py-20 bg-gradient-to-r from-primary to-secondary text-white rounded-2xl mb-16"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl mb-6 font-heading text-[36px]">
              Ready to Book?
            </h2>
            <p className="text-lg sm:text-xl mb-8 max-w-3xl mx-auto font-body opacity-90">
              Let's make your next visit the best one yet. We serve patients across BC and welcome families, professionals, and seniors alike.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                className="bg-white text-primary hover:bg-gray-100 shadow-lg hover:shadow-xl transition-all duration-300 px-8 py-6 text-lg font-body"
              >
                <Calendar className="mr-2 h-5 w-5" />
                Request Appointment Online
              </Button>
              <Button 
                size="lg" 
                className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-primary transition-all duration-300 px-8 py-6 text-lg font-medium shadow-none"
              >
                <Phone className="mr-2 h-5 w-5" />
                Call (778) 340-2897
              </Button>
            </div>
          </motion.div>
        </motion.div>

        {/* Final Section */}
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl sm:text-3xl font-heading text-gray-900 mb-4">
            Experience the Smile Well Difference
          </h3>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto font-body">
            Join thousands of satisfied patients who trust us with their dental care. Contact us today to schedule your visit.
          </p>
          <Button 
            size="lg" 
            className="bg-gradient-to-r from-primary to-secondary hover:from-secondary hover:to-primary text-white shadow-lg hover:shadow-xl transition-all duration-300 px-8 py-6 text-lg font-body"
          >
            <Calendar className="mr-2 h-5 w-5" />
            Schedule Your Visit Today
          </Button>
        </motion.div>
      </div>
    </div>
  );
}