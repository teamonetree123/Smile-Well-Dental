'use client';

import { Card } from '../ui/card';
import { motion } from 'motion/react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { 
  Microscope,
  Lightbulb,
  CreditCard
} from 'lucide-react';

export function Technology() {
  const technologySections = [
    {
      title: "Our Technology",
      icon: Microscope,
      color: "primary",
      description: "Modern tools improve accuracy, comfort, and results. Depending on your needs, your visit may include digital X-rays, intraoral cameras, and 3D digital scanning for mess-free impressions."
    },
    {
      title: "What to Expect",
      icon: Lightbulb,
      color: "secondary",
      description: "We listen first. You'll get clear options, transparent fees, and a treatment plan that respects your timeline and budget. We never pressure—ever."
    },
    {
      title: "Insurance & Financing",
      icon: CreditCard,
      color: "accent",
      description: "We work with most major plans and will help you maximize benefits. Flexible payment solutions are available for larger treatments—ask our team for details."
    }
  ];

  return (
    <div className="py-20">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl mb-6 font-heading text-gray-900">
            Modern Technology & <span className="text-accent">Patient Experience</span>
          </h2>
        </motion.div>

        {/* Technology Image */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="relative rounded-2xl overflow-hidden shadow-xl max-w-4xl mx-auto">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0ZWNobm9sb2d5JTIwZXF1aXBtZW50fGVufDF8fHx8MTc1NjMwMjc4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Modern dental technology and equipment"
              className="w-full h-[500px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary/20 via-transparent to-accent/10"></div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {technologySections.map((section, index) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="h-full text-center p-6 hover:shadow-lg transition-all duration-300 flex flex-col items-center justify-center">
                <div className={`inline-flex items-center justify-center w-16 h-16 bg-${section.color}/10 rounded-full mb-4`}>
                  <section.icon className={`h-8 w-8 text-${section.color}`} />
                </div>
                <h3 className="text-xl font-heading text-gray-900 mb-4">{section.title}</h3>
                <p className="text-gray-600 font-body leading-relaxed">{section.description}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}