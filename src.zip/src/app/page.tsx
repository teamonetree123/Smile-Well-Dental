import { Header } from '../components/Header';
import { Hero } from '../components/Hero';
import { Services } from '../components/Services';
import { CDCP } from '../components/CDCP';
import { About } from '../components/About';
import { Location } from '../components/Location';
import { Contact } from '../components/Contact';
import { Footer } from '../components/Footer';
import { MobileBottomNav } from '../components/MobileBottomNav';
import { AnimatedBackground } from '../components/AnimatedBackground';

export default function Home() {
  return (
    <div className="min-h-screen bg-white relative">
      {/* Animated Background - positioned behind all content */}
      <AnimatedBackground />
      
      {/* All content with relative positioning to appear above background */}
      <div className="relative z-10">
        <Header />
        <main>
          <section id="hero">
            <Hero />
          </section>
          <section id="services">
            <Services />
          </section>
          <section id="cdcp">
            <CDCP />
          </section>
          <section id="about">
            <About />
          </section>
          <section id="location">
            <Location />
          </section>
          <section id="contact">
            <Contact />
          </section>
        </main>
        <Footer />
        <MobileBottomNav />
      </div>
    </div>
  );
}