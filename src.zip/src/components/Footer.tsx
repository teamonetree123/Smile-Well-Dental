import { MapPin, Phone, Mail, Clock, Facebook, Instagram, Twitter } from 'lucide-react';
import { Button } from './ui/button';
import { motion } from 'motion/react';
import logoImage from 'figma:asset/08fcabea942c4f998249bf7334abda32e62d4fb9.png';

export function Footer() {
  const locations = [
    {
      name: 'North Vancouver',
      address: 'Suite #202, 814 15th St West',
      city: 'North Vancouver, BC',
      phone: '(778) 340-2897',
      hours: 'Mon-Fri: 8AM-5PM',
      services: ['General Dentistry', 'Cosmetic Dentistry', 'Emergency Care']
    },
    {
      name: 'Surrey',
      address: '15243 91 Ave #2',
      city: 'Surrey, BC',
      phone: '(778) 877-3493',
      hours: 'Mon-Fri: 8AM-5PM',
      services: ['Dental Implants', 'Orthodontics', 'Preventive Care']
    },
    {
      name: 'Langley',
      address: 'A125 & A130 20487 65 Ave',
      city: 'Langley, BC',
      phone: '(604) 546-2828',
      hours: 'Mon-Fri: 8AM-5PM',
      services: ['CDCP Services', 'Family Dentistry', 'Restorative Care']
    }
  ];

  const services = [
    'Preventive Dentistry',
    'Cosmetic Dentistry',
    'Dental Implants',
    'Orthodontics',
    'Emergency Care',
    'CDCP Services'
  ];

  const quickLinks = [
    'About Us',
    'Services',
    'Our Team',
    'Locations',
    'Contact',
    'Book Appointment'
  ];

  const socialIcons = [
    { icon: Facebook, label: 'Facebook' },
    { icon: Instagram, label: 'Instagram' },
    { icon: Twitter, label: 'Twitter' }
  ];

  const contactInfo = [
    {
      icon: Phone,
      label: 'Main Line',
      value: '(778) 340-2897',
      subtext: 'North Vancouver'
    },
    {
      icon: Clock,
      label: 'Hours',
      value: ['Mon/Wed/Fri: 8:00 AM – 4:30 PM', 'Tuesday: 8:00 AM – 12:00 PM']
    },
    {
      icon: Mail,
      label: 'Email',
      value: 'info@smilewell.ca'
    }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <motion.div 
            className="space-y-6"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div>
              <motion.div 
                className="flex items-center space-x-3 mb-4"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <motion.img 
                  src={logoImage}
                  alt="Smile Well Dental"
                  className="h-16 w-auto"
                  initial={{ scale: 0, rotate: -180 }}
                  whileInView={{ scale: 1, rotate: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 }}
                  viewport={{ once: true }}
                />
                <div>

                </div>
              </motion.div>
              <motion.p 
                className="text-gray-300 text-sm leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                viewport={{ once: true }}
              >
                Compassionate, comprehensive, and community-focused dental care across BC. 
                Experience award-winning dentistry with modern facilities and flexible scheduling.
              </motion.p>
            </div>
            
            {/* Social Links */}
            <motion.div 
              className="flex space-x-4"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              viewport={{ once: true }}
            >
              {socialIcons.map((social, index) => (
                <motion.div
                  key={social.label}
                  initial={{ opacity: 0, scale: 0 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.7 + (index * 0.1) }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white p-2">
                    <social.icon className="h-5 w-5" />
                  </Button>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <motion.h4 
              className="text-lg font-semibold mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
            >
              Quick Links
            </motion.h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <motion.li 
                  key={link}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: 0.5 + (index * 0.05) }}
                  viewport={{ once: true }}
                >
                  <motion.a 
                    href={`#${link.toLowerCase().replace(/\s+/g, '-')}`}
                    className="text-gray-300 hover:text-primary transition-colors duration-200 text-sm"
                    whileHover={{ x: 5 }}
                  >
                    {link}
                  </motion.a>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          {/* Services */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <motion.h4 
              className="text-lg font-semibold mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              viewport={{ once: true }}
            >
              Our Services
            </motion.h4>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <motion.li 
                  key={service}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: 0.7 + (index * 0.05) }}
                  viewport={{ once: true }}
                >
                  <motion.a 
                    href="#services"
                    className="text-gray-300 hover:text-primary transition-colors duration-200 text-sm"
                    whileHover={{ x: 5 }}
                  >
                    {service}
                  </motion.a>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            viewport={{ once: true }}
          >
            <motion.h4 
              className="text-lg font-semibold mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.8 }}
              viewport={{ once: true }}
            >
              Contact Information
            </motion.h4>
            <div className="space-y-4">
              {contactInfo.map((contact, index) => (
                <motion.div 
                  key={contact.label}
                  className="flex items-start space-x-3"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.9 + (index * 0.1) }}
                  viewport={{ once: true }}
                >
                  <motion.div
                    initial={{ scale: 0, rotate: -180 }}
                    whileInView={{ scale: 1, rotate: 0 }}
                    transition={{ duration: 0.5, delay: 1.0 + (index * 0.1) }}
                    viewport={{ once: true }}
                  >
                    <contact.icon className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                  </motion.div>
                  <div>
                    <p className="text-gray-300 text-sm">{contact.label}</p>
                    {Array.isArray(contact.value) ? (
                      contact.value.map((line, lineIndex) => (
                        <p key={lineIndex} className="text-white text-sm">{line}</p>
                      ))
                    ) : (
                      <p className="text-white font-medium">{contact.value}</p>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Locations */}
        <motion.div 
          className="border-t border-gray-800 mt-12 pt-8"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <motion.h4 
            className="text-lg font-semibold mb-6 text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            viewport={{ once: true }}
          >
            Our Locations
          </motion.h4>
          <div className="grid md:grid-cols-3 gap-6">
            {locations.map((location, index) => (
              <motion.div 
                key={index} 
                className="text-center p-6 rounded-lg bg-gray-800/50 border border-gray-700/50 hover:border-primary/30 transition-all duration-300"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.7 + (index * 0.1) }}
                viewport={{ once: true }}
                whileHover={{ y: -5, scale: 1.02 }}
              >
                <motion.div
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.8 + (index * 0.1) }}
                  viewport={{ once: true }}
                >
                  <MapPin className="h-6 w-6 text-primary mx-auto mb-3" />
                </motion.div>
                
                <h5 className="font-semibold text-primary mb-3 text-lg">{location.name}</h5>
                
                <div className="space-y-2 text-sm text-gray-300 mb-4">
                  <p className="flex items-center justify-center space-x-2">
                    <span>{location.address}</span>
                  </p>
                  <p>{location.city}</p>
                  
                  <div className="flex items-center justify-center space-x-2 text-white font-medium">
                    <Phone className="h-4 w-4 text-primary" />
                    <span>{location.phone}</span>
                  </div>
                  
                  <div className="flex items-center justify-center space-x-2 text-gray-400">
                    <Clock className="h-4 w-4 text-secondary" />
                    <span>{location.hours}</span>
                  </div>
                </div>

                {/* Services Submenu */}
                <div className="border-t border-gray-700/50 pt-3">
                  <p className="text-xs text-gray-400 mb-2">Specializing in:</p>
                  <div className="flex flex-wrap justify-center gap-1">
                    {location.services.map((service, serviceIndex) => (
                      <span
                        key={serviceIndex}
                        className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full border border-primary/20"
                      >
                        {service}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Call to Action Button */}
                <motion.div
                  className="mt-4"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    size="sm" 
                    className="bg-primary/10 text-primary border border-primary/30 hover:bg-primary hover:text-white transition-all duration-300 w-full"
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    Call Now
                  </Button>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Bottom Bar */}
        <motion.div 
          className="border-t border-gray-800 mt-12 pt-8"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          viewport={{ once: true }}
        >
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <motion.div 
              className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-6 text-sm text-gray-400"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.7 }}
              viewport={{ once: true }}
            >
              <p>&copy; 2024 Smile Well Dental. All rights reserved.</p>
              <div className="flex space-x-4">
                {['Privacy Policy', 'Terms of Service', 'CDCP Information'].map((link, index) => (
                  <motion.a 
                    key={link}
                    href="#" 
                    className="hover:text-primary transition-colors duration-200"
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.8 + (index * 0.05) }}
                    viewport={{ once: true }}
                    whileHover={{ y: -2 }}
                  >
                    {link}
                  </motion.a>
                ))}
              </div>
            </motion.div>
            <motion.div 
              className="flex items-center space-x-2 text-sm text-gray-400"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.9 }}
              viewport={{ once: true }}
            >
              <span>CDCP Supported</span>
              <motion.div 
                className="w-2 h-2 bg-primary rounded-full"
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                transition={{ duration: 0.4, delay: 1.0 }}
                viewport={{ once: true }}
                animate={{ 
                  scale: [1, 1.2, 1],
                  opacity: [1, 0.8, 1]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: 2
                }}
              />
              <span>Award-Winning Care</span>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </footer>
  );
}