import { useState, useEffect } from 'react';
import { 
  Home, 
  Stethoscope, 
  Info, 
  MapPin, 
  Calendar 
} from 'lucide-react';

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  sectionId: string;
}

const navItems: NavItem[] = [
  {
    id: 'home',
    label: 'Home',
    icon: Home,
    sectionId: 'hero'
  },
  {
    id: 'services',
    label: 'Services',
    icon: Stethoscope,
    sectionId: 'services'
  },
  {
    id: 'about',
    label: 'About',
    icon: Info,
    sectionId: 'about'
  },
  {
    id: 'location',
    label: 'Location',
    icon: MapPin,
    sectionId: 'location'
  },
  {
    id: 'contact',
    label: 'Book',
    icon: Calendar,
    sectionId: 'contact'
  }
];

interface MobileBottomNavProps {
  onNavigateToHome?: () => void;
  onNavigateToServices?: () => void;
  onNavigateToAbout?: () => void;
  onNavigateToLocation?: () => void;
}

export function MobileBottomNav({ onNavigateToHome, onNavigateToServices, onNavigateToAbout, onNavigateToLocation }: MobileBottomNavProps = {}) {
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      const sections = navItems.map(item => item.sectionId);
      const scrollPosition = window.scrollY + 100;

      for (const sectionId of sections) {
        const element = document.getElementById(sectionId);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(navItems.find(item => item.sectionId === sectionId)?.id || 'home');
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    // Handle services page navigation
    if (sectionId === 'services') {
      onNavigateToServices?.();
      return;
    }
    
    // Handle about page navigation
    if (sectionId === 'about') {
      onNavigateToAbout?.();
      return;
    }
    
    // Handle location page navigation
    if (sectionId === 'location') {
      onNavigateToLocation?.();
      return;
    }
    
    // Handle home navigation
    if (sectionId === 'hero') {
      onNavigateToHome?.();
      return;
    }
    
    const element = document.getElementById(sectionId);
    if (element) {
      const offsetTop = element.offsetTop - 80; // Account for header height
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden">
      <div className="bg-white border-t border-gray-200 shadow-lg">
        <div className="flex items-center justify-around px-2 py-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.sectionId)}
                className={`flex flex-col items-center justify-center min-w-0 flex-1 py-2 px-1 rounded-lg transition-all duration-200 ${
                  isActive 
                    ? 'text-white' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
                style={isActive ? { backgroundColor: '#00B4D8' } : {}}
              >
                <Icon 
                  className="h-5 w-5 mb-1" 
                  strokeWidth={isActive ? 2.5 : 2}
                />
                <span className="text-xs font-medium leading-tight">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}