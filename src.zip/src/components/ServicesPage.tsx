'use client';

import { Hero } from './services/Hero';
import { CoreServices } from './services/CoreServices';
import { SpecializedServices } from './services/SpecializedServices';
import { Technology } from './services/Technology';
import { FAQ } from './services/FAQ';
import { Contact } from './services/Contact';
import { motion, useScroll, useTransform, useSpring } from 'motion/react';
import { useRef, useState, useEffect } from 'react';

interface ServicesPageProps {
  onBackToHome: () => void;
}

export function ServicesPage({ onBackToHome }: ServicesPageProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [windowHeight, setWindowHeight] = useState(0);
  const [activeSection, setActiveSection] = useState('hero');
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  useEffect(() => {
    setWindowHeight(window.innerHeight);
    const handleResize = () => setWindowHeight(window.innerHeight);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Track active section based on scroll position
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['hero', 'core-services', 'specialized-services', 'technology', 'faq', 'contact'];
      const scrollPosition = window.scrollY + window.innerHeight / 2;

      for (const sectionId of sections) {
        const element = document.getElementById(sectionId);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Hero parallax effects
  const heroParallax = useTransform(scrollYProgress, [0, 0.3], ["0%", "-15%"]);
  const smoothHeroParallax = useSpring(heroParallax, { stiffness: 500, damping: 20 });

  return (
    <div ref={containerRef} className="relative bg-gradient-to-br from-white via-gray-50/30 to-blue-50/20 min-h-screen">
      {/* All content with relative positioning */}
      <div className="relative z-10">
        <main className="relative pt-20">
          
          {/* Hero Section - Keep parallax effect */}
          <motion.section 
            id="hero"
            className="relative"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.15 }}
          >
            <motion.div
              style={{ 
                y: smoothHeroParallax,
                opacity: useTransform(scrollYProgress, [0, 0.3], [1, 0.3])
              }}
            >
              <Hero />
            </motion.div>
          </motion.section>

          {/* Core Services Section */}
          <motion.section 
            id="core-services"
            className="relative py-20 bg-white"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.1, ease: "easeOut" }}
            viewport={{ once: true, margin: "200px" }}
          >
            <CoreServices />
          </motion.section>

          {/* Specialized Services Section */}
          <motion.section 
            id="specialized-services"
            className="relative py-20 bg-gray-50/50"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.1, ease: "easeOut" }}
            viewport={{ once: true, margin: "200px" }}
          >
            <SpecializedServices />
          </motion.section>

          {/* Technology & Expectations Section */}
          <motion.section 
            id="technology"
            className="relative py-20 bg-white"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.1, ease: "easeOut" }}
            viewport={{ once: true, margin: "200px" }}
          >
            <Technology />
          </motion.section>

          {/* FAQ Section */}
          <motion.section 
            id="faq"
            className="relative py-20 bg-gray-50/50"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.1, ease: "easeOut" }}
            viewport={{ once: true, margin: "200px" }}
          >
            <FAQ />
          </motion.section>

          {/* Contact/CTA Section */}
          <motion.section 
            id="contact"
            className="relative py-20 bg-white"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.1, ease: "easeOut" }}
            viewport={{ once: true, margin: "200px" }}
          >
            <Contact />
          </motion.section>
        </main>
      </div>

      {/* Simple Scroll Progress Indicator */}
      <motion.div 
        className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-secondary to-accent z-[100] origin-left shadow-lg"
        style={{ scaleX: scrollYProgress }}
      />

      {/* Section Indicator Dots */}
      <div className="fixed right-6 top-1/2 transform -translate-y-1/2 space-y-3 z-[100] hidden lg:block">
        {[
          { name: 'Hero', href: '#hero', id: 'hero' },
          { name: 'Core Services', href: '#core-services', id: 'core-services' },
          { name: 'Specialized', href: '#specialized-services', id: 'specialized-services' },
          { name: 'Technology', href: '#technology', id: 'technology' },
          { name: 'FAQ', href: '#faq', id: 'faq' },
          { name: 'Contact', href: '#contact', id: 'contact' }
        ].map((section, index) => {
          const isActive = activeSection === section.id;

          return (
            <motion.a
              key={section.name}
              href={section.href}
              className={`block rounded-full transition-all duration-300 cursor-pointer border-2 shadow-lg backdrop-blur-sm ${
                isActive 
                  ? 'w-4 h-4 bg-primary/60 border-primary/90' 
                  : 'w-3 h-3 bg-primary/25 border-primary/50'
              }`}
              whileHover={{ 
                scale: 1.4, 
                backgroundColor: '#00B4D8',
                boxShadow: "0 0 12px rgba(0, 180, 216, 0.5)"
              }}
              whileTap={{ scale: 0.9 }}
              title={section.name}
            />
          );
        })}
      </div>

      {/* Floating Scroll to Top */}
      <motion.a
        href="#hero"
        className="fixed bottom-6 right-6 w-12 h-12 bg-primary/90 rounded-full flex items-center justify-center text-white shadow-2xl cursor-pointer z-[100] backdrop-blur-sm lg:bottom-8 lg:right-8 lg:w-14 lg:h-14"
        initial={{ opacity: 0, scale: 0 }}
        style={{
          opacity: useTransform(scrollYProgress, [0.1, 0.15], [0, 1]),
          scale: useTransform(scrollYProgress, [0.1, 0.15], [0, 1])
        }}
        whileHover={{ 
          scale: 1.1,
          boxShadow: "0 20px 40px rgba(0, 180, 216, 0.6)"
        }}
        whileTap={{ scale: 0.9 }}
      >
        <motion.div
          animate={{ y: [-1, 1, -1] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="text-sm lg:text-lg font-bold"
        >
          ↑
        </motion.div>
      </motion.a>
    </div>
  );
}